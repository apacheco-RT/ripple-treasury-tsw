import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import Home from "@/pages/Home";
import Landing from "@/pages/Landing";
import ResearchReport from "@/pages/ResearchReport";
import AnnotatedSpecs from "@/pages/AnnotatedSpecs";
import Prototype from "@/pages/Prototype";
import ExportReport from "@/pages/ExportReport";
import FraudRulesConfig from "@/pages/FraudRulesConfig";
import FraudReports from "@/pages/FraudReports";
import NotFound from "@/pages/not-found";

function Router() {
  return (
    <Switch>
      <Route path="/" component={Landing} />
      <Route path="/research" component={ResearchReport} />
      <Route path="/specs" component={AnnotatedSpecs} />
      <Route path="/prototype" component={Prototype} />
      <Route path="/export" component={ExportReport} />
      <Route path="/strategy" component={Home} />
      <Route path="/fraud-rules" component={FraudRulesConfig} />
      <Route path="/fraud-reports" component={FraudReports} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <Router />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
