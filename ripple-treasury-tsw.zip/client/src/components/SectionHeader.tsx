import { ReactNode } from "react";
import { motion } from "framer-motion";

interface SectionHeaderProps {
  icon?: ReactNode;
  title: string;
  subtitle?: string;
}

export function SectionHeader({ icon, title, subtitle }: SectionHeaderProps) {
  return (
    <div className="mb-10 relative">
      <div className="flex items-center gap-3 mb-2">
        {icon && <div className="text-blue-400">{icon}</div>}
        <h2 className="text-3xl font-bold text-white m-0 tracking-tight">{title}</h2>
      </div>
      {subtitle && (
        <p className="text-lg text-slate-400 max-w-2xl">{subtitle}</p>
      )}
      <div className="absolute -bottom-4 left-0 w-24 h-1 bg-gradient-to-r from-blue-500 to-teal-500 rounded-full opacity-80" />
    </div>
  );
}
