import { Link, useLocation } from "wouter";
import { useState } from "react";
import { Sun, Moon, Settings2, X, ArrowRight } from "lucide-react";
import { useTheme } from "@/hooks/use-theme";
import { AnimatePresence, motion } from "framer-motion";

function RippleTreasuryLogo({ className }: { className?: string }) {
  return (
    <img src="/logo.svg" alt="Ripple Treasury" className={className} />
  );
}

const navLinks = [
  { href: "/", label: "Hub" },
  { href: "/research", label: "Research Report" },
  { href: "/specs", label: "Annotated Specs" },
];

const prototypeFeatures = [
  { key: "rlusdStrip", label: "RLUSD Eligible Strip", description: "Highlight transactions eligible for instant RLUSD settlement" },
  { key: "stablecoinRail", label: "Stablecoin Payment Rail", description: "Show stablecoin option in payment rail selection dialog" },
  { key: "selectPaymentRail", label: "Select Payment Rail Button", description: "Enable payment rail selection for RLUSD-eligible transactions" },
  { key: "riskColumn", label: "Risk Column", description: "Show inline risk score column in the transaction details table" },
];

export function PageNav() {
  const [location, navigate] = useLocation();
  const { theme, toggle } = useTheme();
  const [showConfigModal, setShowConfigModal] = useState(false);
  const [featureToggles, setFeatureToggles] = useState<Record<string, boolean>>({
    rlusdStrip: false,
    stablecoinRail: false,
    selectPaymentRail: false,
    riskColumn: false,
  });

  const toggleFeature = (key: string) => {
    setFeatureToggles(prev => ({ ...prev, [key]: !prev[key] }));
  };

  const launchPrototype = () => {
    const params = new URLSearchParams();
    Object.entries(featureToggles).forEach(([key, val]) => {
      if (!val) params.set(key, "0");
    });
    const qs = params.toString();
    setShowConfigModal(false);
    navigate(`/prototype${qs ? `?${qs}` : ""}`);
  };

  return (
    <>
      <header className="fixed top-0 left-0 right-0 z-50 glass-header">
        <div className="w-full px-4">
          <div className="flex items-center h-16">
            <Link href="/" className="flex items-center group cursor-pointer shrink-0 mr-4">
              <RippleTreasuryLogo className="h-7 w-auto brightness-0 opacity-80 group-hover:opacity-100 transition-opacity" />
            </Link>

            <nav className="flex items-center justify-evenly flex-1">
              {navLinks.map(({ href, label }) => {
                const isActive = location === href;
                return (
                  <Link
                    key={href}
                    href={href}
                    className={`px-4 py-2 rounded-lg text-sm font-medium whitespace-nowrap transition-all duration-200 cursor-pointer
                      ${isActive
                        ? "bg-blue-500/15 text-blue-400 border border-blue-500/25"
                        : "text-slate-400 hover:text-slate-200 hover:bg-white/5"
                      }`}
                  >
                    {label}
                  </Link>
                );
              })}
              <button
                onClick={() => setShowConfigModal(true)}
                className={`px-4 py-2 rounded-lg text-sm font-medium whitespace-nowrap transition-all duration-200 cursor-pointer
                  ${location.startsWith("/prototype")
                    ? "bg-blue-500/15 text-blue-400 border border-blue-500/25"
                    : "text-slate-400 hover:text-slate-200 hover:bg-white/5"
                  }`}
              >
                Prototype
              </button>
            </nav>

            <div className="flex items-center gap-3 shrink-0 ml-4">
              <button
                onClick={toggle}
                title={theme === "dark" ? "Switch to light mode" : "Switch to dark mode"}
                className="p-2 rounded-lg transition-all duration-200 text-slate-400 hover:text-slate-600 hover:bg-black/5 border border-transparent hover:border-slate-200/20"
              >
                {theme === "dark"
                  ? <Sun className="w-4 h-4" />
                  : <Moon className="w-4 h-4" />}
              </button>

              <div className="flex items-center gap-2 px-3 py-1.5 rounded-full bg-rose-500/10 border border-rose-500/20 text-rose-400 text-xs font-semibold uppercase tracking-wide whitespace-nowrap">
                <span className="w-1.5 h-1.5 rounded-full bg-rose-400 animate-pulse" />
                6 HIGH severity
              </div>
            </div>
          </div>
        </div>
      </header>

      <AnimatePresence>
        {showConfigModal && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[100] flex items-center justify-center bg-black/60 backdrop-blur-sm"
            onClick={() => setShowConfigModal(false)}
          >
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 12 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 12 }}
              transition={{ duration: 0.2 }}
              onClick={(e) => e.stopPropagation()}
              className="w-full max-w-md mx-4 bg-[#0f213e] border border-slate-700/60 rounded-2xl shadow-2xl overflow-hidden"
            >
              <div className="flex items-center justify-between px-6 py-4 border-b border-slate-700/40">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-purple-600 to-purple-800 flex items-center justify-center">
                    <Settings2 className="w-5 h-5 text-white" />
                  </div>
                  <div>
                    <h2 className="text-lg font-bold text-white m-0">Configure Prototype</h2>
                    <p className="text-xs text-slate-400 m-0">Toggle features before launching</p>
                  </div>
                </div>
                <button
                  onClick={() => setShowConfigModal(false)}
                  className="p-2 rounded-lg text-slate-400 hover:text-white hover:bg-white/5 transition-colors focus:outline-none"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              <div className="px-6 py-5 space-y-3">
                {prototypeFeatures.map((feature) => (
                  <div
                    key={feature.key}
                    className={`flex items-center justify-between p-4 rounded-xl border transition-all ${
                      featureToggles[feature.key]
                        ? "border-teal-500/30 bg-teal-500/5"
                        : "border-slate-700/40 bg-[#0a1628]"
                    }`}
                  >
                    <div className="flex-1 min-w-0 mr-4">
                      <span className="text-sm font-semibold text-white block">{feature.label}</span>
                      <span className="text-xs text-slate-400 block mt-0.5">{feature.description}</span>
                    </div>
                    <button
                      role="switch"
                      aria-checked={featureToggles[feature.key]}
                      onClick={() => toggleFeature(feature.key)}
                      className={`relative inline-flex h-6 w-11 shrink-0 rounded-full border-2 transition-colors focus:outline-none ${
                        featureToggles[feature.key]
                          ? "bg-teal-500 border-teal-500"
                          : "bg-slate-600 border-slate-600"
                      }`}
                    >
                      <span
                        className={`pointer-events-none block h-4 w-4 rounded-full bg-white shadow transition-transform mt-[1px] ${
                          featureToggles[feature.key] ? "translate-x-[21px]" : "translate-x-[2px]"
                        }`}
                      />
                    </button>
                  </div>
                ))}
              </div>

              <div className="px-6 py-4 border-t border-slate-700/40 flex items-center justify-between">
                <span className="text-xs text-slate-500">
                  {Object.values(featureToggles).filter(Boolean).length} of {prototypeFeatures.length} features enabled
                </span>
                <button
                  onClick={launchPrototype}
                  className="px-5 py-2.5 bg-gradient-to-r from-purple-600 to-purple-700 hover:from-purple-500 hover:to-purple-600 text-white text-sm font-semibold rounded-xl transition-all shadow-lg hover:shadow-purple-500/20 flex items-center gap-2 focus:outline-none"
                >
                  Launch Prototype
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
