import { AlertCircle } from "lucide-react";
import { Link } from "wouter";

export default function NotFound() {
  return (
    <div className="min-h-screen w-full flex items-center justify-center bg-[hsl(var(--navy-dark))]">
      <div className="w-full max-w-md mx-4 bg-[#0f213e] rounded-2xl border border-slate-800 p-8 text-center">
        <AlertCircle className="h-10 w-10 text-rose-400 mx-auto mb-4" />
        <h1 className="text-2xl font-bold text-white mb-2">404 Page Not Found</h1>
        <p className="text-sm text-slate-400 mb-6">
          The page you're looking for doesn't exist or has been moved.
        </p>
        <Link
          href="/"
          className="inline-flex items-center gap-2 px-5 py-2.5 rounded-lg bg-gradient-to-r from-teal-600 to-blue-700 hover:from-teal-500 hover:to-blue-600 text-white font-semibold text-sm transition-all"
        >
          Back to Home
        </Link>
      </div>
    </div>
  );
}
