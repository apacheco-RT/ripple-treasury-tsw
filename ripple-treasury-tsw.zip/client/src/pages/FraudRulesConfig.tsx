import { useState } from "react";
import { ChevronDown, ChevronRight, ShieldCheck, Shield, Globe, Clock, Copy, AlertTriangle, Zap, AlertCircle } from "lucide-react";
import AppNav from "@/components/AppNav";

// ── Types ─────────────────────────────────────────────────────────────────────
interface RuleConfig {
  id: string;
  name: string;
  description: string;
  icon: React.ElementType;
  iconColor: string;
  enabled: boolean;
  riskWeight: number;
  workflowAction: string;
  tab: "detection" | "anomaly";
}

// ── Mock rule state ────────────────────────────────────────────────────────────
const INITIAL_RULES: RuleConfig[] = [
  {
    id: "first-time-payee",
    name: "First-Time Payee Check",
    description: "Flag payments to payees that have never received funds from this entity before.",
    icon: ShieldCheck,
    iconColor: "text-teal-400",
    enabled: true,
    riskWeight: 35,
    workflowAction: "review",
    tab: "detection",
  },
  {
    id: "high-risk-countries",
    name: "High-Risk Country Filter",
    description: "Automatically flag transactions destined for OFAC-sanctioned or high-risk jurisdictions.",
    icon: Globe,
    iconColor: "text-red-400",
    enabled: true,
    riskWeight: 85,
    workflowAction: "block",
    tab: "detection",
  },
  {
    id: "amount-outlier",
    name: "Amount Outlier Detection",
    description: "Detect payments that are statistically anomalous relative to historical averages for the payee or account.",
    icon: AlertTriangle,
    iconColor: "text-amber-400",
    enabled: true,
    riskWeight: 60,
    workflowAction: "review",
    tab: "anomaly",
  },
  {
    id: "velocity-check",
    name: "Velocity Check",
    description: "Flag entities that exceed a defined number of transactions or total value within a rolling time window.",
    icon: Zap,
    iconColor: "text-purple-400",
    enabled: true,
    riskWeight: 70,
    workflowAction: "review",
    tab: "detection",
  },
  {
    id: "off-hours",
    name: "Off-Hours Transaction Alert",
    description: "Flag transactions submitted outside of normal business hours for additional scrutiny.",
    icon: Clock,
    iconColor: "text-blue-400",
    enabled: false,
    riskWeight: 20,
    workflowAction: "flag",
    tab: "anomaly",
  },
  {
    id: "duplicate-payment",
    name: "Duplicate Payment Detection",
    description: "Identify potential duplicate payments with matching payee, amount, and reference within a lookback window.",
    icon: Copy,
    iconColor: "text-orange-400",
    enabled: true,
    riskWeight: 75,
    workflowAction: "hold",
    tab: "detection",
  },
];

const WORKFLOW_OPTIONS = [
  { value: "flag",   label: "Flag for Review" },
  { value: "review", label: "Route to Reviewer" },
  { value: "hold",   label: "Hold Payment" },
  { value: "block",  label: "Block Payment" },
];

// ── Rule card inline configs ───────────────────────────────────────────────────

function FirstTimePayeeConfig({ enabled }: { enabled: boolean }) {
  const [lookback, setLookback] = useState("90");
  const [minTxns,  setMinTxns]  = useState("3");
  if (!enabled) return null;
  return (
    <div className="mt-4 grid grid-cols-2 gap-4 p-4 bg-[#0a1628] rounded-lg border border-[#1a3455]">
      <div>
        <label className="block text-[10px] text-slate-500 uppercase tracking-wider mb-1">Lookback Period (days)</label>
        <select
          value={lookback}
          onChange={e => setLookback(e.target.value)}
          className="w-full bg-[#162a47] border border-[#1a3455] text-slate-300 text-xs rounded px-2 py-1.5 focus:outline-none focus:ring-1 focus:ring-orange-500/40"
        >
          {["30","60","90","180","365"].map(v => <option key={v} value={v}>{v} days</option>)}
        </select>
      </div>
      <div>
        <label className="block text-[10px] text-slate-500 uppercase tracking-wider mb-1">Min. Previous Transactions</label>
        <select
          value={minTxns}
          onChange={e => setMinTxns(e.target.value)}
          className="w-full bg-[#162a47] border border-[#1a3455] text-slate-300 text-xs rounded px-2 py-1.5 focus:outline-none focus:ring-1 focus:ring-orange-500/40"
        >
          {["1","2","3","5","10"].map(v => <option key={v} value={v}>{v} transaction{v!=="1"?"s":""}</option>)}
        </select>
      </div>
    </div>
  );
}

function AmountOutlierConfig({ enabled }: { enabled: boolean }) {
  const [threshold, setThreshold] = useState("200");
  const [baseline,  setBaseline]  = useState("90");
  if (!enabled) return null;
  return (
    <div className="mt-4 grid grid-cols-2 gap-4 p-4 bg-[#0a1628] rounded-lg border border-[#1a3455]">
      <div>
        <label className="block text-[10px] text-slate-500 uppercase tracking-wider mb-1">Outlier Threshold (%)</label>
        <input
          type="number"
          value={threshold}
          onChange={e => setThreshold(e.target.value)}
          min="50"
          max="1000"
          className="w-full bg-[#162a47] border border-[#1a3455] text-slate-300 text-xs rounded px-2 py-1.5 focus:outline-none focus:ring-1 focus:ring-orange-500/40"
        />
        <p className="text-[10px] text-slate-500 mt-1">Flag if amount exceeds avg by this %</p>
      </div>
      <div>
        <label className="block text-[10px] text-slate-500 uppercase tracking-wider mb-1">Baseline Window (days)</label>
        <select
          value={baseline}
          onChange={e => setBaseline(e.target.value)}
          className="w-full bg-[#162a47] border border-[#1a3455] text-slate-300 text-xs rounded px-2 py-1.5 focus:outline-none focus:ring-1 focus:ring-orange-500/40"
        >
          {["30","60","90","180"].map(v => <option key={v} value={v}>Last {v} days</option>)}
        </select>
      </div>
    </div>
  );
}

function VelocityCheckConfig({ enabled }: { enabled: boolean }) {
  const [maxTxns, setMaxTxns]   = useState("10");
  const [maxAmt,  setMaxAmt]    = useState("50000");
  const [window,  setWindow]    = useState("24");
  if (!enabled) return null;
  return (
    <div className="mt-4 grid grid-cols-3 gap-4 p-4 bg-[#0a1628] rounded-lg border border-[#1a3455]">
      <div>
        <label className="block text-[10px] text-slate-500 uppercase tracking-wider mb-1">Max Transactions</label>
        <input type="number" value={maxTxns} onChange={e => setMaxTxns(e.target.value)} min="1"
          className="w-full bg-[#162a47] border border-[#1a3455] text-slate-300 text-xs rounded px-2 py-1.5 focus:outline-none focus:ring-1 focus:ring-orange-500/40" />
      </div>
      <div>
        <label className="block text-[10px] text-slate-500 uppercase tracking-wider mb-1">Max Total ($)</label>
        <input type="number" value={maxAmt} onChange={e => setMaxAmt(e.target.value)} min="0"
          className="w-full bg-[#162a47] border border-[#1a3455] text-slate-300 text-xs rounded px-2 py-1.5 focus:outline-none focus:ring-1 focus:ring-orange-500/40" />
      </div>
      <div>
        <label className="block text-[10px] text-slate-500 uppercase tracking-wider mb-1">Rolling Window (hrs)</label>
        <select value={window} onChange={e => setWindow(e.target.value)}
          className="w-full bg-[#162a47] border border-[#1a3455] text-slate-300 text-xs rounded px-2 py-1.5 focus:outline-none focus:ring-1 focus:ring-orange-500/40">
          {["1","4","8","12","24","48"].map(v => <option key={v} value={v}>{v}h</option>)}
        </select>
      </div>
    </div>
  );
}

function HighRiskCountriesConfig({ enabled }: { enabled: boolean }) {
  const [mode, setMode] = useState<"ofac" | "custom">("ofac");
  const COUNTRIES = ["Iran","North Korea","Russia","Cuba","Syria","Venezuela","Belarus","Myanmar"];
  const [selected, setSelected] = useState(new Set(["Iran","North Korea","Syria"]));
  const toggle = (c: string) => setSelected(prev => {
    const s = new Set(prev);
    s.has(c) ? s.delete(c) : s.add(c);
    return s;
  });
  if (!enabled) return null;
  return (
    <div className="mt-4 p-4 bg-[#0a1628] rounded-lg border border-[#1a3455] space-y-3">
      <div className="flex gap-3">
        {(["ofac","custom"] as const).map(m => (
          <button key={m} onClick={() => setMode(m)}
            className={`px-3 py-1.5 rounded text-xs font-medium transition-colors ${mode===m ? "bg-orange-500/20 text-orange-400 ring-1 ring-orange-500/30" : "bg-[#162a47] text-slate-400 hover:text-slate-200"}`}>
            {m === "ofac" ? "OFAC Auto-Sync" : "Custom List"}
          </button>
        ))}
      </div>
      {mode === "custom" && (
        <div className="flex flex-wrap gap-2 mt-2">
          {COUNTRIES.map(c => (
            <button key={c} onClick={() => toggle(c)}
              className={`px-2 py-1 rounded text-xs transition-colors ${selected.has(c) ? "bg-red-500/20 text-red-400 ring-1 ring-red-500/30" : "bg-[#162a47] text-slate-400 hover:text-slate-200"}`}>
              {c}
            </button>
          ))}
        </div>
      )}
      {mode === "ofac" && (
        <p className="text-[11px] text-slate-500">Automatically synced with OFAC SDN list. Last updated: 2026-02-24.</p>
      )}
    </div>
  );
}

function OffHoursConfig({ enabled }: { enabled: boolean }) {
  const [start, setStart] = useState("07:00");
  const [end,   setEnd]   = useState("19:00");
  const [tz,    setTz]    = useState("America/Chicago");
  if (!enabled) return null;
  return (
    <div className="mt-4 grid grid-cols-3 gap-4 p-4 bg-[#0a1628] rounded-lg border border-[#1a3455]">
      <div>
        <label className="block text-[10px] text-slate-500 uppercase tracking-wider mb-1">Business Hours Start</label>
        <input type="time" value={start} onChange={e => setStart(e.target.value)}
          className="w-full bg-[#162a47] border border-[#1a3455] text-slate-300 text-xs rounded px-2 py-1.5 focus:outline-none focus:ring-1 focus:ring-orange-500/40" />
      </div>
      <div>
        <label className="block text-[10px] text-slate-500 uppercase tracking-wider mb-1">Business Hours End</label>
        <input type="time" value={end} onChange={e => setEnd(e.target.value)}
          className="w-full bg-[#162a47] border border-[#1a3455] text-slate-300 text-xs rounded px-2 py-1.5 focus:outline-none focus:ring-1 focus:ring-orange-500/40" />
      </div>
      <div>
        <label className="block text-[10px] text-slate-500 uppercase tracking-wider mb-1">Timezone</label>
        <select value={tz} onChange={e => setTz(e.target.value)}
          className="w-full bg-[#162a47] border border-[#1a3455] text-slate-300 text-xs rounded px-2 py-1.5 focus:outline-none focus:ring-1 focus:ring-orange-500/40">
          <option value="America/New_York">US Eastern</option>
          <option value="America/Chicago">US Central</option>
          <option value="America/Denver">US Mountain</option>
          <option value="America/Los_Angeles">US Pacific</option>
          <option value="Europe/London">Europe/London</option>
          <option value="UTC">UTC</option>
        </select>
      </div>
    </div>
  );
}

function DuplicatePaymentConfig({ enabled }: { enabled: boolean }) {
  const [lookback, setLookback] = useState("7");
  const [matchFields, setMatchFields] = useState(new Set(["payee","amount","reference"]));
  const toggle = (f: string) => setMatchFields(prev => {
    const s = new Set(prev);
    s.has(f) ? s.delete(f) : s.add(f);
    return s;
  });
  if (!enabled) return null;
  const fields = [
    { id:"payee",     label:"Payee" },
    { id:"amount",    label:"Amount" },
    { id:"reference", label:"Reference" },
    { id:"account",   label:"Account" },
    { id:"bank",      label:"Bank" },
  ];
  return (
    <div className="mt-4 p-4 bg-[#0a1628] rounded-lg border border-[#1a3455] space-y-3">
      <div>
        <label className="block text-[10px] text-slate-500 uppercase tracking-wider mb-2">Match Fields</label>
        <div className="flex flex-wrap gap-2">
          {fields.map(f => (
            <button key={f.id} onClick={() => toggle(f.id)}
              className={`px-2.5 py-1 rounded text-xs font-medium transition-colors ${matchFields.has(f.id) ? "bg-orange-500/20 text-orange-400 ring-1 ring-orange-500/30" : "bg-[#162a47] text-slate-400 hover:text-slate-200"}`}>
              {f.label}
            </button>
          ))}
        </div>
      </div>
      <div className="w-40">
        <label className="block text-[10px] text-slate-500 uppercase tracking-wider mb-1">Lookback Window (days)</label>
        <select value={lookback} onChange={e => setLookback(e.target.value)}
          className="w-full bg-[#162a47] border border-[#1a3455] text-slate-300 text-xs rounded px-2 py-1.5 focus:outline-none focus:ring-1 focus:ring-orange-500/40">
          {["1","3","7","14","30"].map(v => <option key={v} value={v}>{v} {v==="1"?"day":"days"}</option>)}
        </select>
      </div>
    </div>
  );
}

// ── Rule card ─────────────────────────────────────────────────────────────────
function RuleCard({ rule, onUpdate }: {
  rule: RuleConfig;
  onUpdate: (id: string, patch: Partial<RuleConfig>) => void;
}) {
  const [expanded, setExpanded] = useState(false);
  const Icon = rule.icon;

  const riskColor =
    rule.riskWeight >= 70 ? "text-red-400 bg-red-500/10 ring-red-500/20" :
    rule.riskWeight >= 40 ? "text-amber-400 bg-amber-500/10 ring-amber-500/20" :
                            "text-emerald-400 bg-emerald-500/10 ring-emerald-500/20";

  const InlineConfig = () => {
    switch (rule.id) {
      case "first-time-payee":   return <FirstTimePayeeConfig   enabled={rule.enabled} />;
      case "amount-outlier":     return <AmountOutlierConfig     enabled={rule.enabled} />;
      case "velocity-check":     return <VelocityCheckConfig     enabled={rule.enabled} />;
      case "high-risk-countries":return <HighRiskCountriesConfig enabled={rule.enabled} />;
      case "off-hours":          return <OffHoursConfig          enabled={rule.enabled} />;
      case "duplicate-payment":  return <DuplicatePaymentConfig  enabled={rule.enabled} />;
      default:                   return null;
    }
  };

  return (
    <div className={`rounded-xl border transition-all ${rule.enabled ? "border-[#1a3455] bg-[#162a47]" : "border-[#1a3455]/50 bg-[#0d1c30] opacity-60"}`}>
      {/* Card header */}
      <div
        className="flex items-center gap-4 px-5 py-4 cursor-pointer"
        onClick={(e) => {
          if ((e.target as HTMLElement).closest("select, button[role='switch']")) return;
          setExpanded(o => !o);
        }}
        role="button"
        aria-label={expanded ? `Collapse ${rule.name}` : `Expand ${rule.name}`}
      >
        <div className="w-9 h-9 rounded-lg flex items-center justify-center bg-[#0a1628] shrink-0">
          <Icon className={`w-4.5 h-4.5 ${rule.iconColor}`} />
        </div>
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 flex-wrap">
            <span className="text-sm font-semibold text-white">{rule.name}</span>
            <span className={`inline-flex items-center px-1.5 py-0.5 rounded text-[10px] font-bold ring-1 ${riskColor}`}>
              Risk {rule.riskWeight}
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-0.5 leading-relaxed">{rule.description}</p>
        </div>

        {/* Workflow action select */}
        <select
          value={rule.workflowAction}
          onChange={e => onUpdate(rule.id, { workflowAction: e.target.value })}
          onClick={e => e.stopPropagation()}
          className="bg-[#0d1c30] border border-[#1a3455] text-slate-300 text-xs rounded px-2 py-1.5 focus:outline-none shrink-0 w-36"
        >
          {WORKFLOW_OPTIONS.map(opt => (
            <option key={opt.value} value={opt.value}>{opt.label}</option>
          ))}
        </select>

        {/* Toggle */}
        <button
          role="switch"
          aria-checked={rule.enabled}
          onClick={(e) => { e.stopPropagation(); onUpdate(rule.id, { enabled: !rule.enabled }); }}
          className={`relative inline-flex h-5 w-9 shrink-0 rounded-full border-2 transition-colors focus:outline-none ${
            rule.enabled ? "bg-orange-500 border-orange-500" : "bg-slate-600 border-slate-600"
          }`}
        >
          <span
            className={`pointer-events-none block h-3.5 w-3.5 rounded-full bg-white shadow transition-transform ${
              rule.enabled ? "translate-x-4" : "translate-x-0.5"
            }`}
            style={{ marginTop: "1px" }}
          />
        </button>

        {/* Expand chevron — WCAG 2.2 minimum 24x24 touch target */}
        <button
          type="button"
          onClick={(e) => { e.stopPropagation(); setExpanded(o => !o); }}
          aria-expanded={expanded}
          aria-label={expanded ? `Collapse ${rule.name}` : `Expand ${rule.name}`}
          className="flex items-center justify-center w-8 h-8 min-w-[24px] min-h-[24px] shrink-0 rounded-md text-slate-500 hover:text-slate-300 hover:bg-white/5 transition-colors focus:outline-none"
        >
          {expanded ? <ChevronDown className="w-4 h-4" /> : <ChevronRight className="w-4 h-4" />}
        </button>
      </div>

      {/* Expanded config */}
      {expanded && (
        <div className="px-5 pb-5 border-t border-[#1a3455]">
          <div className="pt-4">
            <div className="flex items-center gap-4 mb-3">
              <div className="flex-1">
                <label className="block text-[10px] text-slate-500 uppercase tracking-wider mb-1">Risk Weight</label>
                <div className="flex items-center gap-3">
                  <input
                    type="range"
                    min="0"
                    max="100"
                    value={rule.riskWeight}
                    onChange={e => onUpdate(rule.id, { riskWeight: Number(e.target.value) })}
                    className="flex-1 accent-orange-500"
                  />
                  <span className={`text-sm font-bold w-8 text-right ${riskColor.split(" ")[0]}`}>
                    {rule.riskWeight}
                  </span>
                </div>
              </div>
            </div>
            <InlineConfig />
          </div>
        </div>
      )}
    </div>
  );
}

// ── Page ──────────────────────────────────────────────────────────────────────
export default function FraudRulesConfig() {
  const [activeTab, setActiveTab] = useState<"detection" | "anomaly">("detection");
  const [rules, setRules] = useState(INITIAL_RULES);
  const [isDirty, setIsDirty] = useState(false);
  const [saved, setSaved] = useState(false);

  const updateRule = (id: string, patch: Partial<RuleConfig>) => {
    setRules(prev => prev.map(r => r.id === id ? { ...r, ...patch } : r));
    setSaved(false);
    setIsDirty(true);
  };

  const handleSave = () => {
    setIsDirty(false);
    setSaved(true);
    setTimeout(() => setSaved(false), 2000);
  };

  const visibleRules = rules.filter(r => r.tab === activeTab);
  const enabledCount = visibleRules.filter(r => r.enabled).length;

  return (
    <div className="min-h-screen flex flex-col bg-[#0f1e35] text-white">
      <AppNav />

      {/* Breadcrumb */}
      <nav aria-label="Breadcrumb" className="breadcrumb-bar bg-[#0d1c30] border-b border-[#1a3455] px-6 py-3 flex items-center gap-2 text-xs shrink-0">
        <span className="text-white/50 font-medium">Anti Fraud</span>
        <ChevronRight className="w-3 h-3 text-white/30" />
        <span className="text-white/50 font-medium">Setup</span>
        <ChevronRight className="w-3 h-3 text-white/30" />
        <span className="text-white/90 font-semibold" aria-current="page">GSmart Fraud Rules</span>
      </nav>

      <main id="main-content" className="flex-1 p-6 space-y-6 overflow-y-auto">
        {/* Page header */}
        <div className="flex items-center justify-between">
          <div>
            <div className="flex items-center gap-3 mb-1">
              <div className="w-8 h-8 rounded-lg bg-orange-500/20 flex items-center justify-center">
                <Shield className="w-4 h-4 text-orange-400" />
              </div>
              <h1 className="text-xl font-bold text-white tracking-tight">Fraud Protection Configuration</h1>
            </div>
            <p className="text-xs text-slate-400 ml-11">
              Configure detection rules, risk weights, and workflow actions for automated fraud screening.
            </p>
          </div>
          <div className="flex items-center gap-3">
            {saved && (
              <span className="text-xs text-orange-400 font-medium flex items-center gap-1.5">
                <ShieldCheck className="w-3.5 h-3.5" /> Saved
              </span>
            )}
            <button
              onClick={handleSave}
              className="px-4 py-2 bg-orange-500 hover:bg-orange-400 text-white text-xs font-semibold rounded-lg transition-colors focus:outline-none focus:ring-2 focus:ring-orange-500/50"
            >
              Save Configuration
            </button>
          </div>
        </div>

        {/* Info banner */}
        <div className="flex items-start gap-3 px-4 py-3 bg-orange-500/[0.12] border border-orange-500/30 rounded-xl">
          <AlertCircle className="w-4 h-4 text-orange-400 mt-0.5 shrink-0" />
          <p className="text-xs text-orange-300 leading-relaxed">
            Rules are evaluated in order during payment processing. Risk weights accumulate — transactions exceeding
            the entity threshold are routed to the configured workflow action.
          </p>
        </div>

        {/* Tabs */}
        <div className="flex items-center gap-1 bg-[#0a1628] rounded-xl p-1 w-fit border border-[#1a3455]">
          {(["detection", "anomaly"] as const).map(tab => (
            <button
              key={tab}
              onClick={() => setActiveTab(tab)}
              className={`px-4 py-2 rounded-lg text-xs font-semibold transition-all ${
                activeTab === tab
                  ? "bg-orange-500 text-white shadow"
                  : "text-slate-400 hover:text-slate-200"
              }`}
            >
              {tab === "detection" ? "Detection Rules" : "Anomaly Detection"}
              <span className={`ml-1.5 text-[10px] px-1.5 py-0.5 rounded-full ${
                activeTab === tab ? "bg-white/20" : "bg-[#162a47]"
              }`}>
                {rules.filter(r => r.tab === tab && r.enabled).length}/{rules.filter(r => r.tab === tab).length}
              </span>
            </button>
          ))}
        </div>

        {/* Active count summary */}
        <div className="flex items-center gap-2 text-xs text-slate-500">
          <ShieldCheck className="w-3.5 h-3.5 text-orange-500" />
          <span>
            <span className="text-orange-400 font-semibold">{enabledCount}</span> of{" "}
            <span className="text-slate-300 font-semibold">{visibleRules.length}</span> rules active
          </span>
        </div>

        {/* Rule cards */}
        <div className="space-y-3">
          {visibleRules.map(rule => (
            <RuleCard key={rule.id} rule={rule} onUpdate={updateRule} />
          ))}
        </div>

        {/* Sticky unsaved-changes bar */}
        {isDirty && (
          <div className="sticky bottom-0 -mx-6 -mb-6 mt-4 px-6 py-3 bg-[#0a1628]/95 backdrop-blur-sm border-t border-[#1a3455] flex items-center justify-between z-10">
            <div className="flex items-center gap-2 text-xs text-amber-400">
              <AlertCircle className="w-3.5 h-3.5 shrink-0" />
              <span>Unsaved changes</span>
            </div>
            <button
              onClick={handleSave}
              className="px-4 py-1.5 bg-orange-500 hover:bg-orange-400 text-white text-xs font-semibold rounded-lg transition-colors focus:outline-none focus:ring-2 focus:ring-orange-500/50"
            >
              Save Configuration
            </button>
          </div>
        )}
      </main>

      <footer className="shrink-0 py-2 px-4 border-t border-slate-800/60 bg-[#0f1e35] flex items-center justify-between">
        <span className="text-[11px] text-slate-400">©2026 G TREASURY SS, LLC. All rights reserved · 26.1.0421</span>
        <span className="text-[11px] text-slate-400">Anti Fraud · GSmart Rules · Feb 2026</span>
      </footer>
    </div>
  );
}
