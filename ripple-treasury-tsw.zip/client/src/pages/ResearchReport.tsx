import { motion } from "framer-motion";
import { FileSearch, AlertTriangle, AlertCircle, Info, Monitor, Layers, Filter, Table2, ShieldAlert, Columns3, ArrowUpDown, RotateCw, Trash2, Bug, ListFilter, HelpCircle, BookmarkCheck } from "lucide-react";
import { PageNav } from "@/components/PageNav";

const fadeInUp = {
  hidden: { opacity: 0, y: 20 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.5 } },
};

const stagger = {
  hidden: { opacity: 0 },
  visible: { opacity: 1, transition: { staggerChildren: 0.08 } },
};

// ── Severity badge ─────────────────────────────────────────────────────────
function SeverityBadge({ level }: { level: "HIGH" | "MEDIUM" | "LOW" }) {
  const map = {
    HIGH:   { bg: "bg-rose-500/15",    border: "border-rose-500/30",   text: "text-rose-400",   icon: <AlertTriangle className="w-3 h-3" /> },
    MEDIUM: { bg: "bg-amber-500/15",   border: "border-amber-500/30",  text: "text-amber-400",  icon: <AlertCircle   className="w-3 h-3" /> },
    LOW:    { bg: "bg-emerald-500/15", border: "border-emerald-500/30",text: "text-emerald-400",icon: <Info          className="w-3 h-3" /> },
  };
  const s = map[level];
  return (
    <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-md text-xs font-bold border ${s.bg} ${s.border} ${s.text}`}>
      {s.icon}{level}
    </span>
  );
}

// ── Feasibility badge ──────────────────────────────────────────────────────
function FeasBadge({ level }: { level: "LOW EFFORT" | "MED EFFORT" | "HIGH EFFORT" }) {
  const map = {
    "LOW EFFORT":  "bg-emerald-500/10 border-emerald-500/20 text-emerald-400",
    "MED EFFORT":  "bg-amber-500/10   border-amber-500/20   text-amber-400",
    "HIGH EFFORT": "bg-rose-500/10    border-rose-500/20    text-rose-400",
  };
  return (
    <span className={`inline-flex items-center px-2 py-0.5 rounded-md text-xs font-semibold border ${map[level]}`}>
      {level}
    </span>
  );
}

// ── Heuristic findings data ────────────────────────────────────────────────
const heuristics = [
  {
    id: "H1", name: "Visibility of System Status",
    finding: "Payment status shows a single static label with no lifecycle position, no time-in-state, and no blocking reason.",
    screen: "Results",
    severity: "HIGH" as const,
    impact: "Approvers cannot diagnose delays or predict when a payment will complete.",
  },
  {
    id: "H2", name: "Match Between System & Real World",
    finding: "Column headers use internal shorthand — \"Paym Ref\", \"Acct Verification\", \"SWIFT Ref\" — that approvers may not recognise.",
    screen: "Results",
    severity: "MEDIUM" as const,
    impact: "Users misread or skip columns, reducing trust in the data shown.",
  },
  {
    id: "H3", name: "User Control & Freedom",
    finding: "Filter form has no Clear All or per-field reset. Approval queue has no prioritisation or triage — users cannot jump to urgent items.",
    screen: "Both",
    severity: "HIGH" as const,
    impact: "Friction for frequent users who re-enter the same filters daily. No sense of control over the data shown.",
  },
  {
    id: "H4", name: "Consistency & Standards",
    finding: "Mix of UI patterns between the filter form and results table. Status labels inconsistent across Process Flow vs. table column (e.g. \"Needs Approval\" vs \"Pending\").",
    screen: "Both",
    severity: "MEDIUM" as const,
    impact: "Users must learn two mental models for the same state. Inconsistency erodes confidence.",
  },
  {
    id: "H5", name: "Error Prevention",
    finding: "Bulk selection + approve has no fraud-awareness confirmation. High-risk payments can be batch-approved silently with no warning gate.",
    screen: "Results",
    severity: "HIGH" as const,
    impact: "Financial loss risk. Regulatory exposure. One click can approve flagged AML transactions.",
  },
  {
    id: "H6", name: "Recognition Over Recall",
    finding: "14 visible columns with no priority hierarchy — every row looks equally important. No visual triage or attention signal for urgent payments.",
    screen: "Results",
    severity: "HIGH" as const,
    impact: "Critical items (overdue, high-risk) are buried in 9,177 rows of uniform data.",
  },
  {
    id: "H7", name: "Flexibility & Efficiency of Use",
    finding: "No saved filter presets for power users. No keyboard shortcut for Search. No multi-select within filters.",
    screen: "Filter",
    severity: "MEDIUM" as const,
    impact: "High-frequency approvers waste time repeating filter setup every session.",
  },
  {
    id: "H8", name: "Aesthetic & Minimalist Design",
    finding: "Table shows 14 columns by default, forcing horizontal scroll. 9,177 rows with no visual hierarchy — urgency is invisible.",
    screen: "Results",
    severity: "HIGH" as const,
    impact: "Cognitive overload. Exceptions aren\'t caught early. Every row competes for attention equally.",
  },
  {
    id: "H9", name: "Help Users Recognise, Diagnose & Recover from Errors",
    finding: "\"AML Possible Matches\" appears as a static Process Flow label — no score, no reason for the flag, no next action guidance.",
    screen: "Results",
    severity: "HIGH" as const,
    impact: "Approvers don\'t know what triggered the flag or what to do. AML flags become noise and get ignored.",
  },
  {
    id: "H10", name: "Help & Documentation",
    finding: "No tooltips on column headers, no explanation of risk score methodology, no onboarding for new users, no empty-state guidance.",
    screen: "Both",
    severity: "LOW" as const,
    impact: "Higher support load for CS team. New approver onboarding takes longer without in-app guidance.",
  },
];

// ── Customer backlog items ─────────────────────────────────────────────────
const backlog = [
  {
    item: "Add Transaction Number as filter",
    screen: "Filter",
    type: "Enhancement",
    effort: "LOW EFFORT" as const,
    impact: "HIGH" as const,
    note: "Direct customer request. Allows searching for a specific transaction instantly.",
  },
  {
    item: "Need a refresh button",
    screen: "Results",
    type: "Enhancement",
    effort: "LOW EFFORT" as const,
    impact: "MEDIUM" as const,
    note: "Approvers work in real-time. Without refresh, data staleness causes re-loading the whole page.",
  },
  {
    item: "Ability to add/remove columns (model group). Inconsistency between statuses.",
    screen: "Results",
    type: "Enhancement",
    effort: "MED EFFORT" as const,
    impact: "HIGH" as const,
    note: "Aligns with H6 & H8 — reduces 14-column overload. Status inconsistency is a separate bug.",
  },
  {
    item: "Add bulk void button (like existing bulk View/Approve)",
    screen: "Results",
    type: "Enhancement",
    effort: "LOW EFFORT" as const,
    impact: "MEDIUM" as const,
    note: "Parity with existing bulk actions. Missing for common workflow where approver needs to reject in bulk.",
  },
  {
    item: "More robust filtering — allow multi filters, multi selection within one filter, add ACCOUNT TREE as filter",
    screen: "Filter",
    type: "Enhancement",
    effort: "HIGH EFFORT" as const,
    impact: "HIGH" as const,
    note: "Matches H7. Power user need. Account Tree is a commonly used hierarchy filter in other modules.",
  },
  {
    item: "Filter by Legal Entity Company does not work properly — search/select autopopulates ID but user must manually type entity name",
    screen: "Filter",
    type: "Bug / Enhancement",
    effort: "LOW EFFORT" as const,
    impact: "HIGH" as const,
    note: "Defect causing filter to fail silently. Blocker for approvers who manage multiple entities.",
  },
  {
    item: "Allow user to skip payment type review (free form, semi) after clicking \"review & approve\"",
    screen: "Results",
    type: "Enhancement",
    effort: "MED EFFORT" as const,
    impact: "MEDIUM" as const,
    note: "Approval workflow has unnecessary confirmation step for certain payment types that adds friction.",
  },
];

// ── Combined priority list ─────────────────────────────────────────────────
const priority = [
  { rank: "P1", finding: "No visual triage — 9,177 rows all look equal",        source: "Both",     severity: "HIGH" as const,   effort: "MED EFFORT" as const },
  { rank: "P2", finding: "Fraud signals are labels without context or CTA",       source: "Heuristic",severity: "HIGH" as const,   effort: "MED EFFORT" as const },
  { rank: "P3", finding: "Payment status is static — no lifecycle visibility",    source: "Heuristic",severity: "HIGH" as const,   effort: "LOW EFFORT" as const },
  { rank: "P4", finding: "Approval queue has no prioritisation or triage",        source: "Heuristic",severity: "HIGH" as const,   effort: "MED EFFORT" as const },
  { rank: "P5", finding: "No error prevention on bulk approval",                  source: "Heuristic",severity: "HIGH" as const,   effort: "MED EFFORT" as const },
  { rank: "P6", finding: "14-column table causes cognitive overload",             source: "Both",     severity: "HIGH" as const,   effort: "MED EFFORT" as const },
  { rank: "P7", finding: "Filter form has no clear/reset or quick-selects",       source: "Both",     severity: "MEDIUM" as const, effort: "LOW EFFORT" as const },
  { rank: "P8", finding: "Technical column labels don\'t match user language",    source: "Heuristic",severity: "MEDIUM" as const, effort: "LOW EFFORT" as const },
  { rank: "P9", finding: "No saved filter presets for power users",               source: "Both",     severity: "MEDIUM" as const, effort: "HIGH EFFORT" as const },
  { rank: "P10",finding: "No contextual help, tooltips, or onboarding",           source: "Heuristic",severity: "LOW" as const,    effort: "LOW EFFORT" as const },
];

const sourceColor: Record<string, string> = {
  Heuristic: "bg-blue-500/10 text-blue-400 border-blue-500/20",
  Backlog:   "bg-teal-500/10  text-teal-400  border-teal-500/20",
  Both:      "bg-purple-500/10 text-purple-400 border-purple-500/20",
};

function screenColor(screen: string) {
  if (screen === "Filter")  return "bg-blue-500/10 border-blue-500/20 text-blue-400";
  if (screen === "Results") return "bg-teal-500/10 border-teal-500/20 text-teal-400";
  if (screen === "Both")    return "bg-purple-500/10 border-purple-500/20 text-purple-400";
  return "bg-slate-500/10 border-slate-500/20 text-slate-400";
}

// ── Design Requirements data ───────────────────────────────────────────────
const requirements = [
  {
    id: "REQ-01",
    title: "Triage queue widget — overdue, high-risk, and error counts above the table",
    screen: "Results",
    severity: "HIGH" as const,
    effort: "MED EFFORT" as const,
    source: "H3, H6, H8",
    isBug: false,
    icon: <ArrowUpDown className="w-4 h-4 text-rose-400" />,
    iconBg: "bg-rose-500/10",
    requirement: "The results table must be preceded by a triage summary showing counts of: Overdue approvals, High-Risk payments (score >70), and Payments with Errors. Each count must be a clickable chip that filters the table to that segment.",
    designChange: "Add an action bar above the results table with three priority chips — Overdue (rose), High Risk (amber), Errors (muted rose). Clicking a chip applies a filter and highlights the active state. Default table sort: overdue → high-risk → upcoming → routine.",
  },
  {
    id: "REQ-02",
    title: "Inline fraud risk score with colour ring and flag reason on every row",
    screen: "Results",
    severity: "HIGH" as const,
    effort: "MED EFFORT" as const,
    source: "H1, H9",
    isBug: false,
    icon: <ShieldAlert className="w-4 h-4 text-amber-400" />,
    iconBg: "bg-amber-500/10",
    requirement: "Every transaction row must display a risk score (0–100) with a colour-coded indicator: green for <30, amber for 30–70, red for >70. A flag reason must be visible as secondary text (e.g. \"First-time payee\", \"Unusual amount\", \"AML match\"). The score must require no click to see.",
    designChange: "Replace the \"AML Possible Matches\" static Process Flow label with an inline FraudBadge component on each row. The badge shows a numeric score, a colour ring, and a flag reason line. A View Detail hover action links to the full fraud report.",
  },
  {
    id: "REQ-03",
    title: "Status pipeline chip showing current stage and next stage inline per row",
    screen: "Results",
    severity: "HIGH" as const,
    effort: "LOW EFFORT" as const,
    source: "H1, H2",
    isBug: false,
    icon: <Table2 className="w-4 h-4 text-teal-400" />,
    iconBg: "bg-teal-500/10",
    requirement: "The Status column must show both the current stage and the next expected stage in one inline chip. Format: \"Screened → Approved\". Blocked or overdue payments must show a rose warning indicator and the reason on the chip.",
    designChange: "Replace the single-word status label with a pipeline chip using an ArrowRight separator. Current stage highlighted in teal; next stage in muted text. Blocked payments get a rose left border and warning icon.",
  },
  {
    id: "REQ-04",
    title: "Bulk approval fraud-awareness gate — intercept when any selected payment is high-risk",
    screen: "Results",
    severity: "HIGH" as const,
    effort: "MED EFFORT" as const,
    source: "H5",
    isBug: false,
    icon: <ShieldAlert className="w-4 h-4 text-rose-400" />,
    iconBg: "bg-rose-500/10",
    requirement: "When a user initiates bulk approval and any selected payment has a risk score >70 or an active AML flag, a confirmation dialog must intercept the action. The dialog must state the number of flagged payments and offer two paths: Review Flagged or Approve All Anyway (requires a second confirmation click).",
    designChange: "Add a pre-approval check on bulk approve. If flagged payments are present, render a shadcn Dialog with rose border, ShieldAlert icon, risk count summary, primary CTA \"Review Flagged\" (filters table to risky subset), and destructive secondary CTA \"Approve All Anyway\" with double-confirm.",
  },
  {
    id: "REQ-05",
    title: "Reduce default columns from 14 to 7 — add column picker for customisation",
    screen: "Results",
    severity: "HIGH" as const,
    effort: "MED EFFORT" as const,
    source: "H8, H6, Backlog",
    isBug: false,
    icon: <Columns3 className="w-4 h-4 text-slate-300" />,
    iconBg: "bg-slate-500/10",
    requirement: "The default results table must display exactly 7 columns with no horizontal scrolling required. Users must be able to add or remove columns via a column picker accessible in a single click. Column selections must persist for the session.",
    designChange: "Default columns: Reference | Payee | Amount | Status | Risk Score | Account Verified | Actions. Hide remaining 7 columns. Add a Columns button (Columns3 icon) in the table header triggering a Popover with checkboxes. Selections apply immediately.",
  },
  {
    id: "REQ-06",
    title: "Default sort by urgency — overdue first, then high-risk, then upcoming deadline",
    screen: "Results",
    severity: "HIGH" as const,
    effort: "MED EFFORT" as const,
    source: "H6, H3",
    isBug: false,
    icon: <ArrowUpDown className="w-4 h-4 text-slate-300" />,
    iconBg: "bg-slate-500/10",
    requirement: "On page load, the transaction table must be sorted by: (1) Overdue first, (2) Risk score >70, (3) Upcoming approval deadline, (4) Everything else. A visible indicator must explain the active sort. Users must be able to override by clicking any column header.",
    designChange: "Apply urgency sort on initial render. Add a caption bar under the table header: \"Sorted by urgency + risk — click a column to change.\" Overdue rows get a 2px rose left border. Active sort column shows ChevronUp/ChevronDown indicator.",
  },
  {
    id: "REQ-07",
    title: "Filter: Clear All button, per-field dismiss, and date quick-select pills",
    screen: "Filter",
    severity: "MEDIUM" as const,
    effort: "LOW EFFORT" as const,
    source: "H3, H7, Backlog",
    isBug: false,
    icon: <Filter className="w-4 h-4 text-blue-400" />,
    iconBg: "bg-blue-500/10",
    requirement: "The filter form must include: a Clear All action that resets all fields in one click; a dismiss × on each populated field; date quick-select pills (Today, This Week, This Month, This Quarter); and a Transaction Number field. Pressing Enter from any field must trigger search.",
    designChange: "Add \"Clear All\" ghost button top-right of filter panel. Add Lucide X icon to each populated field. Add pill row under date picker with 4 quick-select options. Add Transaction Number input field. Wire Enter keydown to the Search button.",
  },
  {
    id: "REQ-08",
    title: "Rename all column headers to plain English — add tooltip to every header",
    screen: "Results",
    severity: "MEDIUM" as const,
    effort: "LOW EFFORT" as const,
    source: "H2",
    isBug: false,
    icon: <HelpCircle className="w-4 h-4 text-slate-300" />,
    iconBg: "bg-slate-500/10",
    requirement: "All table column headers must use complete, plain-English names. No internal abbreviations may be visible in the default view. Every column header must show a tooltip on hover that explains the field in one sentence.",
    designChange: "Rename: \"Paym Ref\" → \"Payment Reference\", \"Acct Verification\" → \"Account Verified?\", \"SWIFT Ref\" → \"SWIFT Reference\". Add shadcn Tooltip (delayDuration=400) to every TableHead with a HelpCircle icon. Copy-only change — no layout modifications.",
  },
  {
    id: "REQ-09",
    title: "Saved filter presets — built-in defaults plus save current filters",
    screen: "Filter",
    severity: "MEDIUM" as const,
    effort: "HIGH EFFORT" as const,
    source: "H7, Backlog",
    isBug: false,
    icon: <BookmarkCheck className="w-4 h-4 text-teal-400" />,
    iconBg: "bg-teal-500/10",
    requirement: "The filter form must include a Saved Searches mechanism. Two built-in presets must be provided: \"My Daily Queue\" (status=Pending, assignedToMe=true, date=today) and \"Overdue Only\" (overdue=true). Users must be able to save the current filter state with a custom name. Selecting a preset must auto-trigger search.",
    designChange: "Add a Saved Searches Select dropdown at the top of the filter panel. Include 2 built-in presets and a \"+ Save Current\" option that prompts for a name. Use localStorage for persistence in v1 (no backend required). Teal accent for the Save CTA.",
  },
  {
    id: "REQ-10",
    title: "Manual refresh button with last-refreshed timestamp in results header",
    screen: "Results",
    severity: "MEDIUM" as const,
    effort: "LOW EFFORT" as const,
    source: "Backlog",
    isBug: false,
    icon: <RotateCw className="w-4 h-4 text-teal-400" />,
    iconBg: "bg-teal-500/10",
    requirement: "Approvers work in real-time. The results table must provide a manual refresh action that re-fetches current data without a full page reload. A timestamp must show when the data was last loaded.",
    designChange: "Add a Refresh icon button (RotateCw) in the table toolbar beside the Columns button. Show a muted \"Last updated: HH:MM\" label next to the button. On click, re-trigger the data fetch and update the timestamp.",
  },
  {
    id: "REQ-11",
    title: "Bulk void/reject action — parity with existing bulk approve",
    screen: "Results",
    severity: "MEDIUM" as const,
    effort: "LOW EFFORT" as const,
    source: "Backlog",
    isBug: false,
    icon: <Trash2 className="w-4 h-4 text-rose-400" />,
    iconBg: "bg-rose-500/10",
    requirement: "Approvers must be able to void or reject multiple transactions in one action, matching the existing bulk approve capability. A confirmation step must list the count of selected items before proceeding.",
    designChange: "Add \"Void Selected\" button to the bulk action bar that appears when rows are checked. Style as a destructive outline button. On click, show a confirmation dialog stating \"Void X payments?\" with Cancel and Confirm Void options.",
  },
  {
    id: "REQ-12",
    title: "Fix Legal Entity Company filter — entity name must auto-populate on selection",
    screen: "Filter",
    severity: "HIGH" as const,
    effort: "LOW EFFORT" as const,
    source: "Backlog",
    isBug: true,
    icon: <Bug className="w-4 h-4 text-rose-400" />,
    iconBg: "bg-rose-500/10",
    requirement: "The Legal Entity Company filter currently autopopulates only the entity ID when a user selects from the search/select dropdown. The entity name must also populate. Users must not need to manually type the entity name after selecting it from results.",
    designChange: "Fix the search/select component to return and display the entity name (not just ID) on selection. Update the data binding to store both ID (for query) and name (for display). Treat as a defect — regression test required.",
  },
  {
    id: "REQ-13",
    title: "Multi-select within filters and Account Tree filter — robust filtering parity",
    screen: "Filter",
    severity: "HIGH" as const,
    effort: "HIGH EFFORT" as const,
    source: "Backlog",
    isBug: false,
    icon: <ListFilter className="w-4 h-4 text-blue-400" />,
    iconBg: "bg-blue-500/10",
    requirement: "Users must be able to select multiple values within a single filter (e.g. multiple statuses, multiple currencies). An Account Tree hierarchy filter must be added, matching the Account Tree component used in other GTreasury modules.",
    designChange: "Replace single-select filter dropdowns with multi-select checkboxes where applicable (Status, Currency, Inst Type). Add an Account Tree filter field using the existing GTreasury tree-select component. These filters should support OR logic within a field.",
  },
  {
    id: "REQ-14",
    title: "Skip redundant payment type review step for low-friction payment types",
    screen: "Results",
    severity: "MEDIUM" as const,
    effort: "MED EFFORT" as const,
    source: "Backlog",
    isBug: false,
    icon: <ArrowUpDown className="w-4 h-4 text-amber-400" />,
    iconBg: "bg-amber-500/10",
    requirement: "When a user clicks \"Review & Approve\" for free-form or semi-structured payment types, the current workflow presents an unnecessary intermediate confirmation screen. Users must have an option to bypass this step for payment types that do not require it.",
    designChange: "Add a \"Don't show for [payment type]\" checkbox on the intermediate review screen. Persist the preference per payment type in user settings. Power users should be able to configure this for all low-risk types in one step.",
  },
  {
    id: "REQ-15",
    title: "Contextual help — risk score explainer, column tooltips, and helpful empty states",
    screen: "Both",
    severity: "LOW" as const,
    effort: "LOW EFFORT" as const,
    source: "H10",
    isBug: false,
    icon: <HelpCircle className="w-4 h-4 text-slate-400" />,
    iconBg: "bg-slate-500/10",
    requirement: "New users must be able to understand the risk score methodology, column meanings, and Process Flow stages without contacting support. When filters return no results, a helpful empty state must appear with a Clear Filters CTA — not a blank table.",
    designChange: "Add a ? icon next to Risk Score that opens a Popover with a scoring table (0–30 Low, 31–70 Med, 71–100 High). Add shadcn Tooltip to all column headers (see REQ-08). Replace blank empty state with Lucide SearchX icon, explanation text, and a Clear Filters ghost button.",
  },
];

export default function ResearchReport() {
  return (
    <div className="min-h-screen bg-[hsl(var(--navy-dark))]">
      <PageNav />
      {/* Page header */}
      <section className="pt-28 pb-12 relative overflow-hidden">
        <div className="absolute inset-0 pointer-events-none">
          <div className="absolute top-0 left-1/3 w-[500px] h-[300px] bg-blue-600/8 rounded-full blur-3xl" />
        </div>
        <div className="container mx-auto px-6 relative z-10 max-w-6xl">
          <motion.div initial="hidden" animate="visible" variants={stagger}>
            <motion.div variants={fadeInUp} className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-blue-500/10 border border-blue-500/20 text-blue-400 text-xs font-semibold uppercase tracking-widest mb-4">
              <FileSearch className="w-3.5 h-3.5" /> Research Report
            </motion.div>
            <motion.h1 variants={fadeInUp} className="text-4xl md:text-5xl font-extrabold tracking-tight mb-3 text-white">
              UX Research Findings
            </motion.h1>
            <motion.p variants={fadeInUp} className="text-slate-400 text-lg max-w-2xl mb-6">
              Nielsen's 10 heuristics applied to the Transaction Status Workflow, synthesised with
              7 customer-reported enhancement requests.
            </motion.p>
            <motion.div variants={fadeInUp} className="bg-slate-800/40 border border-slate-700/50 rounded-xl px-5 py-4 max-w-4xl">
              <p className="text-sm text-slate-300 leading-relaxed m-0">The current payment approval interface has critical usability and risk management gaps — it shows all 9,177 transactions the same way, with no way to prioritize by risk or urgency. A heuristic evaluation identified 17 findings (6 rated high severity) around missing fraud signals, information overload, and unsafe bulk approval workflows, which customer feedback corroborates. These findings have been distilled into 10 prioritized improvements: the first six redesign the core queue with smarter triage, risk visibility, and fraud prevention, while the last four focus on everyday friction like filtering, clearer labels, and saved views — all grounded in 15 traceable design requirements.</p>
            </motion.div>
          </motion.div>

          {/* Context cards */}
          <motion.div
            initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.3 }}
            className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-10"
          >
            {[
              { icon: <Monitor className="w-5 h-5 text-blue-400" />, label: "Screens Evaluated", value: "2", sub: "Screen 1: Filter form · Screen 2: Results table" },
              { icon: <FileSearch className="w-5 h-5 text-teal-400" />, label: "Method", value: "Heuristic", sub: "Nielsen's 10 usability heuristics, severity rated HIGH / MEDIUM / LOW" },
              { icon: <Layers className="w-5 h-5 text-purple-400" />, label: "Total Findings", value: "17", sub: "10 heuristic + 7 backlog items → 10 consolidated priority recommendations" },
            ].map((c, i) => (
              <div key={i} className="bg-[#0f213e] rounded-xl border border-slate-800 p-5 flex items-start gap-4">
                <div className="mt-0.5">{c.icon}</div>
                <div>
                  <p className="text-xs uppercase tracking-widest text-slate-500 font-semibold mb-0.5">{c.label}</p>
                  <p className="text-xl font-bold text-white leading-none mb-1">{c.value}</p>
                  <p className="text-xs text-slate-400">{c.sub}</p>
                </div>
              </div>
            ))}
          </motion.div>
        </div>
      </section>
      {/* Section A: Heuristic Findings */}
      <section className="py-12 border-t border-slate-800/50 bg-[#070f1f]">
        <div className="container mx-auto px-6 max-w-6xl">
          <motion.div initial={{ opacity: 0, y: 16 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }}>
            <h2 className="text-2xl font-bold text-white mb-2 flex items-center gap-3">
              <span className="w-8 h-8 rounded-full bg-blue-500/15 border border-blue-500/25 text-blue-400 text-sm font-bold flex items-center justify-center">A</span>
              Heuristic Evaluation — H1 to H10
            </h2>
            <p className="text-slate-400 text-sm mb-8">Nielsen's 10 heuristics applied across both screens. Severity rated by frequency × impact.</p>

            <div className="bg-[#0f213e] rounded-xl border border-slate-800 overflow-hidden">
              <div className="overflow-x-auto">
                <table className="w-full text-left border-collapse text-sm">
                  <thead>
                    <tr className="border-b border-blue-500/20 bg-[#162a4d]">
                      <th className="px-4 py-3 text-xs uppercase text-slate-400 font-semibold w-16">ID</th>
                      <th className="px-4 py-3 text-xs uppercase text-slate-400 font-semibold w-44">Heuristic</th>
                      <th className="px-4 py-3 text-xs uppercase text-slate-400 font-semibold">Finding</th>
                      <th className="px-4 py-3 text-xs uppercase text-slate-400 font-semibold w-20">Screen</th>
                      <th className="px-4 py-3 text-xs uppercase text-slate-400 font-semibold w-24">Severity</th>
                      <th className="px-4 py-3 text-xs uppercase text-slate-400 font-semibold">Impact</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800/60">
                    {heuristics.map((h, i) => (
                      <motion.tr
                        key={h.id}
                        initial={{ opacity: 0, x: -8 }}
                        whileInView={{ opacity: 1, x: 0 }}
                        viewport={{ once: true }}
                        transition={{ delay: i * 0.04 }}
                        className="hover:bg-slate-800/25 transition-colors"
                      >
                        <td className="px-4 py-3">
                          <span className="font-mono text-xs font-bold text-blue-400">{h.id}</span>
                        </td>
                        <td className="px-4 py-3 text-xs text-slate-300 font-medium leading-snug">{h.name}</td>
                        <td className="px-4 py-3 text-xs text-slate-400 leading-relaxed max-w-xs">{h.finding}</td>
                        <td className="px-4 py-3">
                          <span className="text-xs px-2 py-0.5 rounded bg-slate-800 text-slate-400 font-medium">{h.screen}</span>
                        </td>
                        <td className="px-4 py-3"><SeverityBadge level={h.severity} /></td>
                        <td className="px-4 py-3 text-xs text-slate-400 leading-relaxed max-w-xs">{h.impact}</td>
                      </motion.tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </motion.div>
        </div>
      </section>
      {/* Section B: Customer Backlog */}
      <section className="py-12 border-t border-slate-800/50">
        <div className="container mx-auto px-6 max-w-6xl">
          <motion.div initial={{ opacity: 0, y: 16 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }}>
            <h2 className="text-2xl font-bold text-white mb-2 flex items-center gap-3">
              <span className="w-8 h-8 rounded-full bg-teal-500/15 border border-teal-500/25 text-teal-400 text-sm font-bold flex items-center justify-center">B</span>
              Customer Backlog — Enhancement Requests
            </h2>
            <p className="text-slate-400 text-sm mb-8">7 items from the product backlog reported by GTreasury customers. All categorised as Enhancement (UX) on the Transaction Status Workflow.</p>

            <div className="bg-[#0f213e] rounded-xl border border-slate-800 overflow-hidden">
              <div className="overflow-x-auto">
                <table className="w-full text-left border-collapse text-sm">
                  <thead>
                    <tr className="border-b border-teal-500/20 bg-[#0d2233]">
                      <th className="px-4 py-3 text-xs uppercase text-slate-400 font-semibold">#</th>
                      <th className="px-4 py-3 text-xs uppercase text-slate-400 font-semibold">Enhancement Request</th>
                      <th className="px-4 py-3 text-xs uppercase text-slate-400 font-semibold w-20">Screen</th>
                      <th className="px-4 py-3 text-xs uppercase text-slate-400 font-semibold w-24">Effort</th>
                      <th className="px-4 py-3 text-xs uppercase text-slate-400 font-semibold w-24">Impact</th>
                      <th className="px-4 py-3 text-xs uppercase text-slate-400 font-semibold">Design Note</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800/60">
                    {backlog.map((b, i) => (
                      <motion.tr
                        key={i}
                        initial={{ opacity: 0, x: -8 }}
                        whileInView={{ opacity: 1, x: 0 }}
                        viewport={{ once: true }}
                        transition={{ delay: i * 0.05 }}
                        className="hover:bg-slate-800/25 transition-colors"
                      >
                        <td className="px-4 py-3 text-xs text-slate-500 font-mono font-bold">{i + 1}</td>
                        <td className="px-4 py-3 text-xs text-slate-300 leading-relaxed max-w-xs">{b.item}</td>
                        <td className="px-4 py-3">
                          <span className="text-xs px-2 py-0.5 rounded bg-slate-800 text-slate-400 font-medium">{b.screen}</span>
                        </td>
                        <td className="px-4 py-3"><FeasBadge level={b.effort} /></td>
                        <td className="px-4 py-3"><SeverityBadge level={b.impact} /></td>
                        <td className="px-4 py-3 text-xs text-slate-400 leading-relaxed max-w-xs">{b.note}</td>
                      </motion.tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </motion.div>
        </div>
      </section>
      {/* Section C: Combined Priority List */}
      <section className="py-12 border-t border-slate-800/50 bg-[#070f1f]">
        <div className="container mx-auto px-6 max-w-6xl">
          <motion.div initial={{ opacity: 0, y: 16 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }}>
            <h2 className="text-2xl font-bold text-white mb-2 flex items-center gap-3">
              <span className="w-8 h-8 rounded-full bg-purple-500/15 border border-purple-500/25 text-purple-400 text-sm font-bold flex items-center justify-center">C</span>
              Combined Priority List — P1 to P10
            </h2>
            <p className="text-slate-400 text-sm mb-8">Heuristic + backlog findings consolidated and ranked by severity × implementation feasibility. Source indicates whether the finding came from heuristic evaluation, customer backlog, or both.</p>

            <div className="space-y-3">
              {priority.map((p, i) => (
                <motion.div
                  key={p.rank}
                  initial={{ opacity: 0, y: 10 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: i * 0.05 }}
                  className="flex items-center gap-4 bg-[#0f213e] rounded-xl border border-slate-800 px-5 py-4 hover:border-slate-700 transition-colors"
                >
                  {/* Rank */}
                  <div className="w-12 h-12 rounded-xl bg-[#162a4d] border border-slate-700 flex items-center justify-center shrink-0">
                    <span className="text-xs font-extrabold text-slate-300">{p.rank}</span>
                  </div>

                  {/* Finding */}
                  <p className="flex-1 text-sm text-white font-medium leading-snug">{p.finding}</p>

                  {/* Source */}
                  <span className={`text-xs font-semibold px-2.5 py-1 rounded-lg border shrink-0 ${sourceColor[p.source]}`}>
                    {p.source}
                  </span>

                  {/* Severity */}
                  <div className="shrink-0"><SeverityBadge level={p.severity} /></div>

                  {/* Effort */}
                  <div className="shrink-0"><FeasBadge level={p.effort} /></div>
                </motion.div>
              ))}
            </div>
          </motion.div>
        </div>
      </section>
      {/* Section D: Design Requirements */}
      <section className="py-12 border-t border-slate-800/50">
        <div className="container mx-auto px-6 max-w-6xl">
          <motion.div initial={{ opacity: 0, y: 16 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }}>
            <h2 className="text-2xl font-bold text-white mb-2 flex items-center gap-3">
              <span className="w-8 h-8 rounded-full bg-orange-500/15 border border-orange-500/25 text-orange-400 text-sm font-bold flex items-center justify-center">D</span>
              Design Requirements &amp; Changes
            </h2>
            <p className="text-slate-400 text-sm mb-8">
              15 functional requirements derived from the heuristic evaluation and customer feedback. Each maps to a screen, a source finding, and a concrete design change.
            </p>

            {/* Screen filter legend */}
            <div className="flex flex-wrap gap-2 mb-8">
              {[
                { label: "Filter screen", color: "bg-blue-500/10 border-blue-500/20 text-blue-400" },
                { label: "Results screen", color: "bg-teal-500/10 border-teal-500/20 text-teal-400" },
                { label: "Both screens", color: "bg-purple-500/10 border-purple-500/20 text-purple-400" },
                { label: "Bug / Defect", color: "bg-rose-500/10 border-rose-500/20 text-rose-400" },
              ].map((l) => (
                <span key={l.label} className={`text-xs font-semibold px-2.5 py-1 rounded-lg border ${l.color}`}>{l.label}</span>
              ))}
            </div>

            <div className="space-y-4">
              {requirements.map((req, i) => (
                <motion.div
                  key={req.id}
                  initial={{ opacity: 0, y: 10 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: i * 0.04 }}
                  className="bg-[#0f213e] rounded-xl border border-slate-800 overflow-hidden hover:border-slate-700 transition-colors"
                >
                  {/* Req header row */}
                  <div className="flex items-start gap-4 px-5 py-4 border-b border-slate-800/60">
                    {/* ID + icon */}
                    <div className="flex items-center gap-2 shrink-0">
                      <div className="w-14 h-8 rounded-lg bg-[#162a4d] border border-slate-700 flex items-center justify-center">
                        <span className="text-[11px] font-extrabold text-slate-300 font-mono">{req.id}</span>
                      </div>
                      <div className={`w-8 h-8 rounded-lg flex items-center justify-center shrink-0 ${req.iconBg}`}>
                        {req.icon}
                      </div>
                    </div>
                    {/* Title + badges */}
                    <div className="flex-1 min-w-0">
                      <div className="flex flex-wrap items-center gap-2 mb-1">
                        <span className={`text-xs font-semibold px-2 py-0.5 rounded-md border ${screenColor(req.screen)}`}>{req.screen}</span>
                        <SeverityBadge level={req.severity} />
                        <FeasBadge level={req.effort} />
                        {req.isBug && (
                          <span className="inline-flex items-center gap-1 text-xs font-bold px-2 py-0.5 rounded-md border bg-rose-500/10 border-rose-500/25 text-rose-400">
                            <Bug className="w-3 h-3" /> Defect
                          </span>
                        )}
                        <span className="text-xs text-slate-500 font-mono">{req.source}</span>
                      </div>
                      <p className="text-sm font-bold text-white leading-snug">{req.title}</p>
                    </div>
                  </div>

                  {/* Requirement + Design Change */}
                  <div className="grid grid-cols-1 md:grid-cols-2 divide-y md:divide-y-0 md:divide-x divide-slate-800/60">
                    <div className="px-5 py-4">
                      <p className="text-xs uppercase tracking-widest text-slate-500 font-semibold mb-2">Requirement</p>
                      <p className="text-xs text-slate-300 leading-relaxed">{req.requirement}</p>
                    </div>
                    <div className="px-5 py-4">
                      <p className="text-xs uppercase tracking-widest text-teal-500 font-semibold mb-2">Design Change</p>
                      <p className="text-xs text-slate-300 leading-relaxed">{req.designChange}</p>
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>
          </motion.div>
        </div>
      </section>
      <footer className="py-6 border-t border-slate-800 bg-[#050b14] text-center">
        <p className="text-slate-600 text-xs">PAYM — UX Research Report · Ripple Treasury Product Design · Feb 2026</p>
      </footer>
    </div>
  );
}
