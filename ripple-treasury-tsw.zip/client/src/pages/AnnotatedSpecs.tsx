import { motion } from "framer-motion";
import { BookOpen, AlertTriangle, AlertCircle, Info, ChevronRight } from "lucide-react";
import { PageNav } from "@/components/PageNav";

const fadeInUp = {
  hidden: { opacity: 0, y: 20 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.5 } },
};

// ── Badges ─────────────────────────────────────────────────────────────────
function SeverityBadge({ level }: { level: "HIGH" | "MEDIUM" | "LOW" }) {
  const map = {
    HIGH:   { cls: "bg-rose-500/15 border-rose-500/30 text-rose-400",     icon: <AlertTriangle className="w-3 h-3" /> },
    MEDIUM: { cls: "bg-amber-500/15 border-amber-500/30 text-amber-400",   icon: <AlertCircle   className="w-3 h-3" /> },
    LOW:    { cls: "bg-emerald-500/15 border-emerald-500/30 text-emerald-400", icon: <Info       className="w-3 h-3" /> },
  };
  const s = map[level];
  return <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-md text-xs font-bold border ${s.cls}`}>{s.icon}{level}</span>;
}

function FeasBadge({ level }: { level: "LOW EFFORT" | "MED EFFORT" | "HIGH EFFORT" }) {
  const cls = {
    "LOW EFFORT":  "bg-emerald-500/10 border-emerald-500/20 text-emerald-400",
    "MED EFFORT":  "bg-amber-500/10   border-amber-500/20   text-amber-400",
    "HIGH EFFORT": "bg-rose-500/10    border-rose-500/20    text-rose-400",
  }[level];
  return <span className={`inline-flex items-center px-2 py-0.5 rounded-md text-xs font-semibold border ${cls}`}>{level}</span>;
}

function PriorityBadge({ rank }: { rank: string }) {
  const isHigh = ["P1","P2","P3","P4","P5","P6"].includes(rank);
  const isMed  = ["P7","P8","P9"].includes(rank);
  return (
    <div className={`w-12 h-12 rounded-xl flex items-center justify-center text-sm font-extrabold shrink-0
      ${isHigh ? "bg-rose-500/15 border border-rose-500/30 text-rose-400"
               : isMed ? "bg-amber-500/15 border border-amber-500/30 text-amber-400"
                       : "bg-emerald-500/10 border border-emerald-500/20 text-emerald-400"}`}>
      {rank}
    </div>
  );
}

// ── Spec data ──────────────────────────────────────────────────────────────
const specs = [
  {
    rank: "P1",
    severity: "HIGH" as const,
    effort: "MED EFFORT" as const,
    heuristic: "H6, H8",
    title: "Intelligent Approval Queue",
    problem: "\"17 Overdue Approvals\" is a raw count. There is no queue ordering by urgency or risk, and no visual differentiation between overdue, upcoming, and high-risk payments. Approvers must scroll 9,177 rows to find what needs action.",
    solution: "Add an Action Required triage widget above the transaction table with 3 priority chips: Overdue (count, rose), High Risk (count, amber), Errors (count, rose-faded). Clicking a chip filters the table to that segment. Default table sort: overdue → high-risk → upcoming → routine.",
    tokens: ["--status-high (rose) for overdue chip", "--status-med (amber) for high-risk chip", "shadcn Badge + Card components", "Lucide AlertTriangle icon"],
    criteria: ["Triage widget visible on page load above the table", "Clicking each chip filters the table and highlights the applied filter", "Default table sort order is by urgency then risk score descending"],
  },
  {
    rank: "P2",
    severity: "HIGH" as const,
    effort: "MED EFFORT" as const,
    heuristic: "H1, H9",
    title: "Inline Fraud Signal — Risk Score + Reason",
    problem: "\"AML Possible Matches\" appears as a static text label in the Process Flow section. There is no score, no explanation of what triggered the flag, and no call to action. Approvers have no idea what to do next.",
    solution: "Replace the static AML label with an inline FraudBadge on every transaction row. The badge shows a risk score (0–100) with a colour-coded ring (green <30, amber 30–70, red >70), a flag reason (\"First-time payee\", \"Unusual amount\", \"AML match\"), and a View Detail action on hover.",
    tokens: ["--status-high / --status-med / --status-low for risk tiers", "shadcn Tooltip + Badge", "Lucide ShieldAlert icon for AML flags", "Colour ring: border-rose-500 / border-amber-400 / border-emerald-500"],
    criteria: ["Risk score visible on every transaction row without any click required", "Colour ring reflects correct score tier (green/amber/red)", "Flag reason text shown as a secondary line below the score"],
  },
  {
    rank: "P3",
    severity: "HIGH" as const,
    effort: "LOW EFFORT" as const,
    heuristic: "H1, H2",
    title: "Status Pipeline Chip",
    problem: "The Status column shows a single word (\"Screened\", \"Approved\"). Users cannot see where a payment is in the 7-stage lifecycle, what stage comes next, what is blocking it, or how long it has been in the current state.",
    solution: "Replace the status label with a mini pipeline chip showing the current step (highlighted in teal) and the next step (muted). Format: \"Screened → Approved\". For blocked payments, show a warning indicator and the reason inline on the chip.",
    tokens: ["--accent-teal for current stage highlight", "--text-secondary for next stage (muted)", "shadcn Badge with border-l-2 accent", "Lucide ArrowRight icon between stages"],
    criteria: ["Every row shows current + next stage in a single inline chip", "Blocked or overdue payments show a rose warning indicator on the chip", "Chip does not exceed the column width — truncate gracefully on narrow viewports"],
  },
  {
    rank: "P4",
    severity: "HIGH" as const,
    effort: "MED EFFORT" as const,
    heuristic: "H5",
    title: "Bulk Approval Fraud-Awareness Gate",
    problem: "Bulk selection + approve has no fraud-awareness confirmation step. Approvers can bulk-approve high-risk payments in a single click, even if several have risk scores above 70 or active AML flags. No warning is shown.",
    solution: "When bulk approval is triggered and any selected payment has risk score >70 or an active AML flag, intercept with a confirmation Dialog: \"2 of 14 selected payments have elevated risk — review before approving?\" with primary CTA \"Review Flagged\" (filters to risky subset) and secondary \"Approve All Anyway\" (requires a second confirmation click).",
    tokens: ["--status-high (rose) for dialog border and icon", "shadcn Dialog + Button (destructive variant for Approve All)", "Lucide ShieldAlert for dialog header icon", "shadcn AlertDescription for the risk count summary"],
    criteria: ["Dialog appears whenever any selected payment is HIGH risk or has an AML flag", "\"Review Flagged\" filters the table to the risky subset without dismissing the modal", "\"Approve All Anyway\" requires a second click (double-confirmation) before proceeding"],
  },
  {
    rank: "P5",
    severity: "HIGH" as const,
    effort: "MED EFFORT" as const,
    heuristic: "H8, H6",
    title: "Column Reduction + Customiser",
    problem: "The table shows 14 columns by default, forcing horizontal scrolling. Most columns are rarely used (SWIFT Ref, Template, Type) but take identical visual weight to critical columns (Amount, Status, Risk Score). Approvers cannot customise what they see.",
    solution: "Default to 7 priority columns only: Reference | Payee | Amount | Status | Risk Score | Account Verified | Actions. Add a column picker (Popover triggered by a Columns button in the table header) that lists all available columns with checkboxes. Selection persists for the session.",
    tokens: ["shadcn Popover + Checkbox for column picker panel", "--navy-mid (#1a2d4d) for the picker panel background", "Lucide Columns3 icon for the toggle button", "shadcn Button (outline, sm) for the Columns trigger"],
    criteria: ["Default view renders exactly 7 columns — no horizontal scroll required", "Column picker is accessible via a single button click", "Column visibility changes apply immediately and persist for the session without page reload"],
  },
  {
    rank: "P6",
    severity: "HIGH" as const,
    effort: "MED EFFORT" as const,
    heuristic: "H6, H3",
    title: "Priority Sort & Default Triage",
    problem: "The transaction table has no default sorting logic. Urgent, overdue, and high-risk payments appear in the same order as routine transactions. There is no \"start here\" visual signal. Approvers have no context for where to focus.",
    solution: "Default table sort to: (1) Overdue first, (2) High risk score (>70), (3) Upcoming approval deadline, (4) Everything else. Display a visible sort indicator and a small callout at the top of the table: \"Sorted by urgency + risk — click any column header to change.\" Allow users to override by clicking column headers.",
    tokens: ["Lucide ArrowUpDown for sortable column indicators", "--status-high left border (2px rose) on overdue rows", "Lucide ChevronUp/ChevronDown for active sort direction", "shadcn TableHead with interactive sort state"],
    criteria: ["First rows on load are always overdue or high-risk without any user interaction", "A callout or caption explains the default sort order", "Clicking any column header changes the sort — active sort column is visually indicated"],
  },
  {
    rank: "P7",
    severity: "MEDIUM" as const,
    effort: "LOW EFFORT" as const,
    heuristic: "H3",
    title: "Filter Clear All + Date Quick-Selects",
    problem: "The filter form (Screen 1) has no way to clear all filters at once. Each field must be individually cleared. Date fields have no quick-select options. There is no keyboard shortcut to trigger search. Re-entering filters every session is a high-frequency friction point.",
    solution: "Add a \"Clear All\" ghost button at the top-right of the filter form that resets all fields. Add a dismissal × on each populated field. Add date quick-select pills below the date picker: Today | This Week | This Month | This Quarter. Add a hint for Enter to search and Esc to clear.",
    tokens: ["shadcn Button (ghost, sm) for Clear All", "--text-secondary for the clear button colour", "shadcn Badge for date quick-select pills", "Lucide X for per-field dismiss icon"],
    criteria: ["\"Clear All\" resets every field to its empty state in a single click", "Each field with a value shows a × icon that clears only that field", "Clicking a date quick-select pill populates both From and To dates correctly"],
  },
  {
    rank: "P8",
    severity: "MEDIUM" as const,
    effort: "LOW EFFORT" as const,
    heuristic: "H2",
    title: "Plain-Language Column Labels + Header Tooltips",
    problem: "Column headers use internal shorthand: \"Paym Ref\" (not \"Payment Reference\"), \"Acct Verification\" (not \"Account Verified?\"), \"SWIFT Ref\" — terms that approvers, especially new ones, may not recognise or may misread. No explanatory tooltips exist.",
    solution: "Rename all column headers to plain English. Add a shadcn Tooltip to every column header that displays a one-sentence explanation on hover. No technical jargon or internal abbreviations visible in the default view. This is a copy + config change — lowest implementation cost of any recommendation.",
    tokens: ["shadcn Tooltip (delayDuration=400) on TableHead cells", "Lucide HelpCircle (w-3 h-3 text-slate-500) after column label", "No colour or layout changes required — copy only"],
    criteria: ["All 7 default column headers use complete plain-English names", "Hovering any column header displays a tooltip within 400ms", "Zero technical abbreviations visible without tooltip interaction"],
  },
  {
    rank: "P9",
    severity: "MEDIUM" as const,
    effort: "HIGH EFFORT" as const,
    heuristic: "H7",
    title: "Saved Filter Presets",
    problem: "High-frequency approvers apply the same filter combination every session (e.g., \"my team's payments, this week, Pending Approval\"). There is no mechanism to save or recall a filter preset. No keyboard shortcut for search. Repetitive setup is a daily friction point.",
    solution: "Add a \"Saved Searches\" dropdown at the top of the filter form with 2 built-in presets (\"My Daily Queue\", \"Overdue Only\") and a \"+ Save Current\" option. Selecting a preset populates filters and auto-triggers search. The Enter key triggers the Search button from any filter field.",
    tokens: ["shadcn Select + DropdownMenu for the preset picker", "--accent-teal for the Save CTA button", "shadcn Input with onKeyDown Enter handler", "localStorage for preset persistence (no backend required in v1)"],
    criteria: ["\"My Daily Queue\" preset populates filters and auto-triggers search in one click", "\"+ Save Current\" prompts for a name and saves the current filter state", "The Enter key triggers search when focus is in any filter input"],
  },
  {
    rank: "P10",
    severity: "LOW" as const,
    effort: "LOW EFFORT" as const,
    heuristic: "H10",
    title: "Contextual Tooltips + In-App Help",
    problem: "New users have no guidance on column meanings, how the risk score is calculated, what Process Flow stages represent, or what to do when an AML flag appears. No empty state guidance exists when filters return no results. Support load for the CS team is elevated as a result.",
    solution: "Add shadcn Tooltip to all column headers (see P8). Add a ? icon next to the Risk Score badge that opens a Popover explaining the GSmart scoring model (0–30 Low, 31–70 Medium, 71–100 High). Improve the empty state: show \"No payments match these filters\" with a Clear All CTA rather than a blank table.",
    tokens: ["shadcn Popover + Tooltip for help overlays", "Lucide HelpCircle (text-slate-500) for help triggers", "shadcn Card for the risk score explanation panel", "Empty state: Lucide SearchX icon + muted text + ghost Button CTA"],
    criteria: ["The ? next to Risk Score opens a popover with a scoring breakdown table", "Empty state renders a helpful message with a Clear Filters action instead of a blank table", "All help interactions are keyboard-accessible (Tab + Enter to open, Esc to close)"],
  },
];

// ── Section divider ────────────────────────────────────────────────────────
function SectionDivider({ label, color }: { label: string; color: string }) {
  return (
    <div className={`flex items-center gap-3 py-4 px-5 rounded-xl border mb-6 ${color}`}>
      <span className="text-sm font-bold uppercase tracking-widest">{label} Priority</span>
    </div>
  );
}

export default function AnnotatedSpecs() {
  const highSpecs   = specs.filter(s => ["P1","P2","P3","P4","P5","P6"].includes(s.rank));
  const mediumSpecs = specs.filter(s => ["P7","P8","P9"].includes(s.rank));
  const lowSpecs    = specs.filter(s => ["P10"].includes(s.rank));

  return (
    <div className="min-h-screen bg-[hsl(var(--navy-dark))]">
      <PageNav />
      {/* Page header */}
      <section className="pt-28 pb-12 relative overflow-hidden">
        <div className="absolute inset-0 pointer-events-none">
          <div className="absolute top-0 right-1/3 w-[400px] h-[300px] bg-teal-600/8 rounded-full blur-3xl" />
        </div>
        <div className="container mx-auto px-6 relative z-10 max-w-5xl">
          <motion.div initial="hidden" animate="visible" variants={{ hidden: { opacity: 0 }, visible: { opacity: 1, transition: { staggerChildren: 0.1 } } }}>
            <motion.div variants={fadeInUp} className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-teal-500/10 border border-teal-500/20 text-teal-400 text-xs font-semibold uppercase tracking-widest mb-4">
              <BookOpen className="w-3.5 h-3.5" /> Annotated Specs
            </motion.div>
            <motion.h1 variants={fadeInUp} className="text-4xl md:text-5xl font-extrabold tracking-tight mb-3 text-white">
              Design Specifications
            </motion.h1>
            <motion.p variants={fadeInUp} className="text-slate-400 text-lg max-w-2xl mb-6">
              10 prioritised recommendations — each with a problem statement, proposed solution,
              Ripple design tokens, and testable acceptance criteria.
            </motion.p>
            <motion.div variants={fadeInUp} className="bg-slate-800/40 border border-slate-700/50 rounded-xl px-5 py-4 max-w-4xl mb-10">
              <p className="text-sm text-slate-300 leading-relaxed m-0">The redesign addresses the approval experience across three priority tiers. The six high-priority changes overhaul the core workflow by surfacing urgent transactions first, embedding fraud scores and status indicators directly in the queue, adding a safeguard for risky bulk actions, and restructuring the table to actively guide approvers rather than just display data. The three medium-priority changes reduce everyday friction through better filtering, clearer language, and saved views. A final lower-priority addition rounds things out by improving onboarding through tooltips and helpful empty states.</p>
            </motion.div>

            {/* Legend */}
            <motion.div variants={fadeInUp} className="flex flex-wrap gap-3 text-xs">
              {[
                { label: "Rank", desc: "P1 = highest priority" },
                { label: "Severity", desc: "HIGH / MEDIUM / LOW — impact of the UX issue" },
                { label: "Effort", desc: "LOW / MED / HIGH — implementation effort in React rebuild" },
                { label: "Heuristic", desc: "Nielsen heuristic(s) violated" },
              ].map((l, i) => (
                <div key={i} className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-[#0f213e] border border-slate-800 text-slate-400">
                  <span className="font-bold text-slate-300">{l.label}:</span> {l.desc}
                </div>
              ))}
            </motion.div>
          </motion.div>
        </div>
      </section>
      {/* Specs */}
      <section className="pb-16 border-t border-slate-800/50">
        <div className="container mx-auto px-6 max-w-5xl">

          {/* HIGH */}
          <div className="pt-10">
            <SectionDivider label="HIGH" color="bg-rose-500/8 border-rose-500/20 text-rose-400" />
            <div className="space-y-6">
              {highSpecs.map((spec, i) => (
                <SpecCard key={spec.rank} spec={spec} index={i} />
              ))}
            </div>
          </div>

          {/* MEDIUM */}
          <div className="pt-10">
            <SectionDivider label="MEDIUM" color="bg-amber-500/8 border-amber-500/20 text-amber-400" />
            <div className="space-y-6">
              {mediumSpecs.map((spec, i) => (
                <SpecCard key={spec.rank} spec={spec} index={i} />
              ))}
            </div>
          </div>

          {/* LOW */}
          <div className="pt-10">
            <SectionDivider label="LOW" color="bg-emerald-500/8 border-emerald-500/20 text-emerald-400" />
            <div className="space-y-6">
              {lowSpecs.map((spec, i) => (
                <SpecCard key={spec.rank} spec={spec} index={i} />
              ))}
            </div>
          </div>
        </div>
      </section>
      <footer className="py-6 border-t border-slate-800 bg-[#050b14] text-center">
        <p className="text-slate-600 text-xs">PAYM — Annotated Specs · Ripple Treasury Product Design · Feb 2026</p>
      </footer>
    </div>
  );
}

// ── Individual spec card ───────────────────────────────────────────────────
function SpecCard({ spec, index }: { spec: typeof specs[0]; index: number }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 16 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ delay: index * 0.05 }}
      className="bg-[#0f213e] rounded-2xl border border-slate-800 overflow-hidden"
    >
      {/* Card header */}
      <div className="flex items-start gap-4 px-6 pt-5 pb-4 border-b border-slate-800/60">
        <PriorityBadge rank={spec.rank} />
        <div className="flex-1 min-w-0">
          <div className="flex flex-wrap items-center gap-2 mb-1.5">
            <SeverityBadge level={spec.severity} />
            <FeasBadge level={spec.effort} />
            <span className="text-xs px-2 py-0.5 rounded-md bg-slate-800 text-slate-400 font-mono font-semibold border border-slate-700">{spec.heuristic}</span>
          </div>
          <h3 className="text-lg font-bold text-white m-0 leading-snug">{spec.title}</h3>
        </div>
      </div>

      {/* Card body */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-0 divide-y md:divide-y-0 md:divide-x divide-slate-800/60">
        {/* Problem */}
        <div className="px-6 py-5">
          <p className="text-xs uppercase tracking-widest text-rose-400 font-semibold mb-2">⚠ Problem — Current State</p>
          <p className="text-sm text-slate-300 leading-relaxed">{spec.problem}</p>
        </div>

        {/* Solution */}
        <div className="px-6 py-5">
          <p className="text-xs uppercase tracking-widest text-teal-400 font-semibold mb-2">→ Solution — Proposed Design</p>
          <p className="text-sm text-slate-300 leading-relaxed">{spec.solution}</p>
        </div>
      </div>

      {/* Tokens + Criteria */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-0 divide-y md:divide-y-0 md:divide-x divide-slate-800/60 border-t border-slate-800/60 bg-[#0a1628]/60">
        {/* Design tokens */}
        <div className="px-6 py-4">
          <p className="text-xs uppercase tracking-widest text-slate-500 font-semibold mb-2">Design Tokens & Components</p>
          <ul className="space-y-1">
            {spec.tokens.map((t, i) => (
              <li key={i} className="flex items-start gap-2 text-xs text-slate-400">
                <ChevronRight className="w-3 h-3 text-teal-500 shrink-0 mt-0.5" />
                <span className="font-mono">{t}</span>
              </li>
            ))}
          </ul>
        </div>

        {/* Acceptance criteria */}
        <div className="px-6 py-4">
          <p className="text-xs uppercase tracking-widest text-slate-500 font-semibold mb-2">Acceptance Criteria</p>
          <ul className="space-y-1.5">
            {spec.criteria.map((c, i) => (
              <li key={i} className="flex items-start gap-2 text-xs text-slate-400">
                <span className="w-4 h-4 rounded-full bg-slate-800 border border-slate-600 flex items-center justify-center text-slate-500 shrink-0 mt-0.5 text-[10px] font-bold">{i + 1}</span>
                {c}
              </li>
            ))}
          </ul>
        </div>
      </div>
    </motion.div>
  );
}
