import React, { useState, useEffect, useRef } from "react";
import AppNav from "@/components/AppNav";
import { motion, AnimatePresence } from "framer-motion";
import {
  Activity, AlertCircle, AlertTriangle, ArrowRight, BarChart2, Ban, Bell,
  Banknote, Briefcase, Building2, BarChart, Calculator, CheckCircle2, CheckSquare,
  ChevronDown, ChevronRight, ChevronUp, Clock, Columns3, CreditCard, Database,
  Download, Globe, HelpCircle, Info, Landmark, Loader2,
  Moon, RefreshCw, Search, Settings, ShieldAlert, ShieldCheck,
  SlidersHorizontal, Square, Star, Sun, TrendingUp, Trash2, User,
  X, ArrowUpRight, FileText, Eye, Edit, MousePointerClick, Paperclip,
} from "lucide-react";

// ── Focus trap hook ───────────────────────────────────────────────────────────
function useFocusTrap(active: boolean, containerRef: React.RefObject<HTMLDivElement>) {
  useEffect(() => {
    if (!active || !containerRef.current) return;
    const el = containerRef.current;
    const focusable = Array.from(
      el.querySelectorAll<HTMLElement>(
        'button:not([disabled]),[href],input:not([disabled]),select:not([disabled]),textarea:not([disabled]),[tabindex]:not([tabindex="-1"])'
      )
    );
    if (!focusable.length) return;
    const first = focusable[0];
    const last  = focusable[focusable.length - 1];
    const onKey = (e: KeyboardEvent) => {
      if (e.key !== "Tab") return;
      if (e.shiftKey) {
        if (document.activeElement === first) { e.preventDefault(); last.focus(); }
      } else {
        if (document.activeElement === last) { e.preventDefault(); first.focus(); }
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [active, containerRef]);
}

// ── Types ─────────────────────────────────────────────────────────────────────
type ProcessStage = "Create" | "Anti Fraud" | "Approvals" | "Status" | "History";
type TrayFilter   = "all" | "overdue" | "high-risk";
interface TxnAttachment { name: string; type: "pdf" | "image"; url: string; }
interface Txn {
  id: string; payee: string; type: string; instType: string; modelId: string;
  amount: number; cur: string; trnDate: string; valDate: string;
  status: string; nextStatus: string; processStage: ProcessStage;
  risk: number; riskReason: string | null; riskFlag: string | null;
  verified: boolean; overdue: boolean;
  bank: string; legalEntity: string; approver: string;
  // Lovable-parity fields
  approvalLevel: number;
  operativeAcct: string;
  offsetNumber: string;
  attachment?: TxnAttachment;
  waterfallChain?: string; waterfallPosition?: number; waterfallTotal?: number;
  rlusdEligible?: boolean;
}

// ── Mock data ─────────────────────────────────────────────────────────────────
const mockTxns: Txn[] = [
  // ── Needs Approval — Approvals ────────────────────────────────────────────
  { id:"2334519",    payee:"Vandelay Industries",  type:"Wire", instType:"PL_E_PAY", modelId:"PL_E_PAY_APPROVE", amount:     99.99, cur:"GBP", trnDate:"25/03/2025", valDate:"25/03/2025", status:"Needs Approval", nextStatus:"Ready to Approve", processStage:"Approvals", risk:45, riskReason:null,                          riskFlag:null,       verified:true,  overdue:false, bank:"Chase Bank",            legalEntity:"GTreasury LLC",    approver:"A. Pacheco", approvalLevel:1, operativeAcct:"0A_CHASE_USD1",     offsetNumber:"2910784214", attachment:{ name:"Invoice-March2025.pdf", type:"pdf", url:"https://www.w3.org/WAI/ER/tests/xhtml/testfiles/resources/pdf/dummy.pdf" } },
  { id:"2334520",    payee:"Vandelay Industries",  type:"Wire", instType:"PL_E_PAY", modelId:"PL_E_PAY_APPROVE", amount:   4000.01, cur:"USD", trnDate:"25/03/2025", valDate:"25/03/2025", status:"Needs Approval", nextStatus:"Ready to Approve", processStage:"Approvals", risk:52, riskReason:null,                          riskFlag:null,       verified:true,  overdue:false, bank:"Chase Bank",            legalEntity:"GTreasury LLC",    approver:"A. Pacheco", approvalLevel:2, operativeAcct:"0A_CHASE_USD1",     offsetNumber:"2910784214" },
  { id:"2334720",    payee:"Tech Corp",            type:"Wire", instType:"PL_E_PAY", modelId:"PL_E_PAY_APPROVE", amount:   4000.01, cur:"USD", trnDate:"25/03/2025", valDate:"25/03/2025", status:"Needs Approval", nextStatus:"Ready to Approve", processStage:"Approvals", risk:38, riskReason:null,                          riskFlag:null,       verified:true,  overdue:false, bank:"Chase Bank",            legalEntity:"GTreasury LLC",    approver:"A. Pacheco", approvalLevel:1, operativeAcct:"0A_CHASE_USD1",     offsetNumber:"2910784215", attachment:{ name:"Payment-Proof.pdf",    type:"pdf", url:"https://www.w3.org/WAI/ER/tests/xhtml/testfiles/resources/pdf/dummy.pdf" } },
  // ── RLUSD-eligible waterfall — Approvals ─────────────────────────────────
  { id:"FTR-100234", payee:"Fund A Account",       type:"Wire", instType:"WIRE",    modelId:"WIRE_APPROVE",     amount:1000000,    cur:"USD", trnDate:"13/02/2026", valDate:"13/02/2026", status:"Needs Approval", nextStatus:"Ready to Approve", processStage:"Approvals", risk:55, riskReason:"Large waterfall transfer · L1",riskFlag:null,       verified:true,  overdue:false, bank:"JPMorgan Chase",        legalEntity:"GTreasury US LLC", approver:"A. Pacheco", approvalLevel:1, operativeAcct:"Master (****1234)",  offsetNumber:"****5678", rlusdEligible:true, waterfallChain:"WF-00042", waterfallPosition:1, waterfallTotal:4 },
  { id:"FTR-100235", payee:"Investment Account",   type:"Wire", instType:"WIRE",    modelId:"WIRE_APPROVE",     amount: 800000,    cur:"USD", trnDate:"13/02/2026", valDate:"13/02/2026", status:"Needs Approval", nextStatus:"Ready to Approve", processStage:"Approvals", risk:48, riskReason:null,                          riskFlag:null,       verified:true,  overdue:false, bank:"JPMorgan Chase",        legalEntity:"GTreasury US LLC", approver:"A. Pacheco", approvalLevel:0, operativeAcct:"Fund A (****5678)",  offsetNumber:"****9012", rlusdEligible:true, waterfallChain:"WF-00042", waterfallPosition:2, waterfallTotal:4 },
  { id:"FTR-100236", payee:"Portfolio Company",    type:"Wire", instType:"WIRE",    modelId:"WIRE_APPROVE",     amount: 600000,    cur:"USD", trnDate:"13/02/2026", valDate:"13/02/2026", status:"Needs Approval", nextStatus:"Ready to Approve", processStage:"Approvals", risk:42, riskReason:null,                          riskFlag:null,       verified:true,  overdue:false, bank:"JPMorgan Chase",        legalEntity:"GTreasury US LLC", approver:"A. Pacheco", approvalLevel:0, operativeAcct:"Invest (****9012)",  offsetNumber:"****3456", rlusdEligible:true, waterfallChain:"WF-00042", waterfallPosition:3, waterfallTotal:4 },
  { id:"FTR-100237", payee:"Operating Account",    type:"Wire", instType:"WIRE",    modelId:"WIRE_APPROVE",     amount: 400000,    cur:"USD", trnDate:"13/02/2026", valDate:"13/02/2026", status:"Needs Approval", nextStatus:"Ready to Approve", processStage:"Approvals", risk:38, riskReason:null,                          riskFlag:null,       verified:true,  overdue:false, bank:"JPMorgan Chase",        legalEntity:"GTreasury US LLC", approver:"A. Pacheco", approvalLevel:0, operativeAcct:"Port Co (****3456)", offsetNumber:"****7890", rlusdEligible:true, waterfallChain:"WF-00042", waterfallPosition:4, waterfallTotal:4 },
  // ── Ready to Extract — Status ─────────────────────────────────────────────
  { id:"2334821",    payee:"Global Supplies",       type:"Wire", instType:"PL_E_PAY", modelId:"PL_E_PAY_EXTRACT", amount:  15234.50, cur:"USD", trnDate:"24/03/2025", valDate:"24/03/2025", status:"Ready to Extract", nextStatus:"Processing",       processStage:"Status",    risk: 8, riskReason:null,                          riskFlag:null,       verified:true,  overdue:false, bank:"Wells Fargo",           legalEntity:"GTreasury US LLC", approver:"L. Kim",     approvalLevel:0, operativeAcct:"0A_WELLS_USD",       offsetNumber:"4512789632", attachment:{ name:"Remittance-Receipt.pdf",    type:"pdf", url:"https://www.w3.org/WAI/ER/tests/xhtml/testfiles/resources/pdf/dummy.pdf" } },
  { id:"2334822",    payee:"European Partners",     type:"Wire", instType:"PL_E_PAY", modelId:"PL_E_PAY_EXTRACT", amount:   8900.00, cur:"EUR", trnDate:"24/03/2025", valDate:"24/03/2025", status:"Ready to Extract", nextStatus:"Processing",       processStage:"Status",    risk:12, riskReason:null,                          riskFlag:null,       verified:true,  overdue:false, bank:"HSBC Europe",           legalEntity:"GTreasury EU GmbH",approver:"L. Kim",     approvalLevel:0, operativeAcct:"0A_HSBC_EUR",        offsetNumber:"7823456789" },
  { id:"2334823",    payee:"UK Services Ltd",       type:"Wire", instType:"PL_E_PAY", modelId:"PL_E_PAY_EXTRACT", amount:  52000.00, cur:"GBP", trnDate:"23/03/2025", valDate:"23/03/2025", status:"Ready to Extract", nextStatus:"Processing",       processStage:"Status",    risk:15, riskReason:null,                          riskFlag:null,       verified:true,  overdue:false, bank:"Barclays",              legalEntity:"GTreasury UK Ltd", approver:"L. Kim",     approvalLevel:0, operativeAcct:"0A_BARCLAYS_GBP",    offsetNumber:"9876543210", attachment:{ name:"Supporting-Documents.pdf", type:"pdf", url:"https://www.w3.org/WAI/ER/tests/xhtml/testfiles/resources/pdf/dummy.pdf" } },
  // ── Extracted — Status ────────────────────────────────────────────────────
  { id:"2334724",    payee:"Manufacturing Inc",     type:"Wire", instType:"PL_E_PAY", modelId:"PL_E_PAY_PROCESS",  amount:  32100.75, cur:"USD", trnDate:"22/03/2025", valDate:"22/03/2025", status:"Extracted",        nextStatus:"Confirmed",        processStage:"Status",    risk: 6, riskReason:null,                          riskFlag:null,       verified:true,  overdue:false, bank:"Chase Bank",            legalEntity:"GTreasury US LLC", approver:"L. Kim",     approvalLevel:0, operativeAcct:"0A_CHASE_USD1",      offsetNumber:"1234567890", attachment:{ name:"Contract-Scan.pdf",         type:"pdf", url:"https://www.w3.org/WAI/ER/tests/xhtml/testfiles/resources/pdf/dummy.pdf" } },
  { id:"2334725",    payee:"German Traders",         type:"Wire", instType:"PL_E_PAY", modelId:"PL_E_PAY_PROCESS",  amount:  18560.00, cur:"EUR", trnDate:"22/03/2025", valDate:"22/03/2025", status:"Extracted",        nextStatus:"Confirmed",        processStage:"Status",    risk: 4, riskReason:null,                          riskFlag:null,       verified:true,  overdue:false, bank:"Deutsche Bank",         legalEntity:"GTreasury EU GmbH",approver:"L. Kim",     approvalLevel:0, operativeAcct:"0A_DEUTSCHE_EUR",    offsetNumber:"5678901234" },
  { id:"2334726",    payee:"Atlantic Freight Co",    type:"Wire", instType:"PL_E_PAY", modelId:"PL_E_PAY_PROCESS",  amount:  67450.00, cur:"USD", trnDate:"22/03/2025", valDate:"22/03/2025", status:"Extracted",        nextStatus:"Confirmed",        processStage:"Status",    risk: 5, riskReason:null,                          riskFlag:null,       verified:true,  overdue:false, bank:"Wells Fargo",           legalEntity:"GTreasury US LLC", approver:"L. Kim",     approvalLevel:0, operativeAcct:"0A_WELLS_USD",       offsetNumber:"1234567891" },
  // ── Confirmed — Status ──────────────────────────────────────────────────
  { id:"2334730",    payee:"Nordic Shipping AS",     type:"Wire", instType:"PL_E_PAY", modelId:"PL_E_PAY_CONFIRM",  amount:  45200.00, cur:"EUR", trnDate:"21/03/2025", valDate:"21/03/2025", status:"Confirmed",        nextStatus:"Approved",         processStage:"Status",    risk: 3, riskReason:null,                          riskFlag:null,       verified:true,  overdue:false, bank:"DNB ASA",               legalEntity:"GTreasury EU GmbH",approver:"L. Kim",     approvalLevel:0, operativeAcct:"0A_DNB_EUR",         offsetNumber:"6012345001" },
  { id:"2334731",    payee:"Midwest Distribution",   type:"Wire", instType:"PL_E_PAY", modelId:"PL_E_PAY_CONFIRM",  amount:  28750.50, cur:"USD", trnDate:"21/03/2025", valDate:"21/03/2025", status:"Confirmed",        nextStatus:"Approved",         processStage:"Status",    risk: 4, riskReason:null,                          riskFlag:null,       verified:true,  overdue:false, bank:"Chase Bank",            legalEntity:"GTreasury US LLC", approver:"L. Kim",     approvalLevel:0, operativeAcct:"0A_CHASE_USD1",      offsetNumber:"6012345002" },
  { id:"2334732",    payee:"Thames Valley Ltd",      type:"Wire", instType:"PL_E_PAY", modelId:"PL_E_PAY_CONFIRM",  amount:  19800.00, cur:"GBP", trnDate:"21/03/2025", valDate:"21/03/2025", status:"Confirmed",        nextStatus:"Approved",         processStage:"Status",    risk: 5, riskReason:null,                          riskFlag:null,       verified:true,  overdue:false, bank:"Barclays",              legalEntity:"GTreasury UK Ltd", approver:"L. Kim",     approvalLevel:0, operativeAcct:"0A_BARCLAYS_GBP",    offsetNumber:"6012345003", attachment:{ name:"Bank-Confirmation.pdf",     type:"pdf", url:"https://www.w3.org/WAI/ER/tests/xhtml/testfiles/resources/pdf/dummy.pdf" } },
  { id:"2334733",    payee:"Berlin Automotive GmbH", type:"Wire", instType:"PL_E_PAY", modelId:"PL_E_PAY_CONFIRM",  amount:  82600.00, cur:"EUR", trnDate:"21/03/2025", valDate:"21/03/2025", status:"Confirmed",        nextStatus:"Approved",         processStage:"Status",    risk: 2, riskReason:null,                          riskFlag:null,       verified:true,  overdue:false, bank:"Deutsche Bank",         legalEntity:"GTreasury EU GmbH",approver:"L. Kim",     approvalLevel:0, operativeAcct:"0A_DEUTSCHE_EUR",    offsetNumber:"6012345004" },
  // ── Failed — Status ───────────────────────────────────────────────────────
  { id:"2334528",    payee:"Retail Stores",          type:"Wire", instType:"PL_E_PAY", modelId:"PL_E_PAY_FAILED",   amount:   7800.00, cur:"USD", trnDate:"21/03/2025", valDate:"21/03/2025", status:"Failed",           nextStatus:"—",                processStage:"Status",    risk:20, riskReason:"Beneficiary account closed",  riskFlag:null,       verified:true,  overdue:false, bank:"Chase Bank",            legalEntity:"GTreasury US LLC", approver:"L. Kim",     approvalLevel:0, operativeAcct:"0A_CHASE_USD1",      offsetNumber:"8901234567" },
  { id:"2334529",    payee:"French Imports",          type:"Wire", instType:"PL_E_PAY", modelId:"PL_E_PAY_FAILED",   amount:  12400.00, cur:"EUR", trnDate:"21/03/2025", valDate:"21/03/2025", status:"Failed",           nextStatus:"—",                processStage:"Status",    risk:18, riskReason:"Routing number invalid",      riskFlag:null,       verified:true,  overdue:false, bank:"BNP Paribas",           legalEntity:"GTreasury EU GmbH",approver:"L. Kim",     approvalLevel:0, operativeAcct:"0A_BNP_EUR",         offsetNumber:"2345678901" },
  // ── Completed — History ───────────────────────────────────────────────────
  { id:"2334626",    payee:"Construction Corp",      type:"Wire", instType:"PL_E_PAY", modelId:"PL_E_PAY_COMPLETE",  amount:  95000.00, cur:"USD", trnDate:"20/03/2025", valDate:"20/03/2025", status:"Approved",         nextStatus:"Complete",         processStage:"History",   risk: 5, riskReason:null,                          riskFlag:null,       verified:true,  overdue:false, bank:"Bank of America",       legalEntity:"GTreasury US LLC", approver:"A. Pacheco", approvalLevel:0, operativeAcct:"0A_BOA_USD",         offsetNumber:"3456789012", attachment:{ name:"Final-Invoice.pdf",         type:"pdf", url:"https://www.w3.org/WAI/ER/tests/xhtml/testfiles/resources/pdf/dummy.pdf" } },
  { id:"2334627",    payee:"Consulting Group",        type:"Wire", instType:"PL_E_PAY", modelId:"PL_E_PAY_COMPLETE",  amount:  42300.50, cur:"GBP", trnDate:"19/03/2025", valDate:"19/03/2025", status:"Approved",         nextStatus:"Complete",         processStage:"History",   risk: 3, riskReason:null,                          riskFlag:null,       verified:true,  overdue:false, bank:"Lloyds Bank",           legalEntity:"GTreasury UK Ltd", approver:"A. Pacheco", approvalLevel:0, operativeAcct:"0A_LLOYDS_GBP",      offsetNumber:"6789012345" },
  // ── Void — History ────────────────────────────────────────────────────────
  { id:"2334430",    payee:"Canceled Order",          type:"Wire", instType:"PL_E_PAY", modelId:"PL_E_PAY_VOID",      amount:   5600.00, cur:"USD", trnDate:"18/03/2025", valDate:"18/03/2025", status:"Void",             nextStatus:"—",                processStage:"History",   risk: 2, riskReason:null,                          riskFlag:null,       verified:true,  overdue:false, bank:"Citibank",              legalEntity:"GTreasury US LLC", approver:"A. Pacheco", approvalLevel:0, operativeAcct:"0A_CITI_USD",        offsetNumber:"4567890123" },
  { id:"2334431",    payee:"Withdrawn Service",       type:"Wire", instType:"PL_E_PAY", modelId:"PL_E_PAY_VOID",      amount:   9200.00, cur:"GBP", trnDate:"17/03/2025", valDate:"17/03/2025", status:"Void",             nextStatus:"—",                processStage:"History",   risk: 3, riskReason:null,                          riskFlag:null,       verified:true,  overdue:false, bank:"NatWest",               legalEntity:"GTreasury UK Ltd", approver:"A. Pacheco", approvalLevel:0, operativeAcct:"0A_NATWEST_GBP",     offsetNumber:"7890123456" },
  // ── Create ────────────────────────────────────────────────────────────────────
  { id:"2334901",    payee:"Apex Engineering",        type:"Wire", instType:"PL_E_PAY", modelId:"PL_E_PAY_CREATE",    amount:  14500.00, cur:"USD", trnDate:"26/02/2026", valDate:"26/02/2026", status:"Draft",            nextStatus:"Submit for Review", processStage:"Create",    risk: 5, riskReason:null,                          riskFlag:null,       verified:false, overdue:false, bank:"Chase Bank",     legalEntity:"GTreasury LLC",    approver:"A. Pacheco", approvalLevel:0, operativeAcct:"0A_CHASE_USD1",      offsetNumber:"3012345678" },
  { id:"2334902",    payee:"Nordic Imports",          type:"Wire", instType:"PL_E_PAY", modelId:"PL_E_PAY_CREATE",    amount:   8250.00, cur:"EUR", trnDate:"26/02/2026", valDate:"26/02/2026", status:"Draft",            nextStatus:"Submit for Review", processStage:"Create",    risk: 3, riskReason:null,                          riskFlag:null,       verified:false, overdue:false, bank:"HSBC Europe",    legalEntity:"GTreasury EU GmbH",approver:"A. Pacheco", approvalLevel:0, operativeAcct:"0A_HSBC_EUR",        offsetNumber:"3012345679" },
  { id:"2334903",    payee:"Pacific Logistics",       type:"Wire", instType:"PL_E_PAY", modelId:"PL_E_PAY_CREATE",    amount:  22800.00, cur:"USD", trnDate:"25/02/2026", valDate:"25/02/2026", status:"Draft",            nextStatus:"Submit for Review", processStage:"Create",    risk: 8, riskReason:null,                          riskFlag:null,       verified:false, overdue:false, bank:"Wells Fargo",    legalEntity:"GTreasury US LLC", approver:"A. Pacheco", approvalLevel:0, operativeAcct:"0A_WELLS_USD",       offsetNumber:"3012345680" },
  { id:"2334904",    payee:"Meridian Capital",        type:"Wire", instType:"WIRE",     modelId:"WIRE_CREATE",        amount: 135000.00, cur:"USD", trnDate:"25/02/2026", valDate:"25/02/2026", status:"Draft",            nextStatus:"Submit for Review", processStage:"Create",    risk:12, riskReason:null,                          riskFlag:null,       verified:false, overdue:false, bank:"JPMorgan Chase", legalEntity:"GTreasury US LLC", approver:"A. Pacheco", approvalLevel:0, operativeAcct:"Master (****1234)",  offsetNumber:"3012345681" },
  { id:"2334905",    payee:"Brisbane Partners",       type:"Wire", instType:"PL_E_PAY", modelId:"PL_E_PAY_CREATE",    amount:  31200.00, cur:"GBP", trnDate:"24/02/2026", valDate:"24/02/2026", status:"Draft",            nextStatus:"Submit for Review", processStage:"Create",    risk: 6, riskReason:null,                          riskFlag:null,       verified:false, overdue:false, bank:"Barclays",       legalEntity:"GTreasury UK Ltd", approver:"A. Pacheco", approvalLevel:0, operativeAcct:"0A_BARCLAYS_GBP",    offsetNumber:"3012345682" },
  // ── Anti Fraud ────────────────────────────────────────────────────────────────
  { id:"AF-100101",  payee:"Horizon Trading Co",      type:"Wire", instType:"PL_E_PAY", modelId:"PL_E_PAY_FRAUD",     amount:  48200.00, cur:"USD", trnDate:"26/02/2026", valDate:"26/02/2026", status:"Under Review",     nextStatus:"Approve / Reject",  processStage:"Anti Fraud",risk:78, riskReason:"Unusual destination country",    riskFlag:"HIGH",     verified:false, overdue:true, bank:"Chase Bank",     legalEntity:"GTreasury LLC",    approver:"A. Pacheco", approvalLevel:1, operativeAcct:"0A_CHASE_USD1",      offsetNumber:"4012345601" },
  { id:"AF-100102",  payee:"Meridian Exports Ltd",    type:"Wire", instType:"PL_E_PAY", modelId:"PL_E_PAY_FRAUD",     amount:  92400.00, cur:"EUR", trnDate:"26/02/2026", valDate:"26/02/2026", status:"Under Review",     nextStatus:"Approve / Reject",  processStage:"Anti Fraud",risk:85, riskReason:"Velocity alert: 3rd wire today", riskFlag:"HIGH",     verified:false, overdue:true, bank:"HSBC Europe",    legalEntity:"GTreasury EU GmbH",approver:"A. Pacheco", approvalLevel:1, operativeAcct:"0A_HSBC_EUR",        offsetNumber:"4012345602" },
  { id:"AF-100103",  payee:"Eastern Capital Group",   type:"Wire", instType:"WIRE",     modelId:"WIRE_FRAUD",         amount: 250000.00, cur:"USD", trnDate:"25/02/2026", valDate:"25/02/2026", status:"Under Review",     nextStatus:"Approve / Reject",  processStage:"Anti Fraud",risk:92, riskReason:"Sanctioned entity match",        riskFlag:"CRIT",     verified:false, overdue:true, bank:"JPMorgan Chase", legalEntity:"GTreasury US LLC", approver:"A. Pacheco", approvalLevel:2, operativeAcct:"Master (****1234)",  offsetNumber:"4012345603" },
  { id:"AF-100104",  payee:"Silvergate Consulting",   type:"Wire", instType:"PL_E_PAY", modelId:"PL_E_PAY_FRAUD",     amount:  18750.00, cur:"GBP", trnDate:"26/02/2026", valDate:"26/02/2026", status:"Under Review",     nextStatus:"Approve / Reject",  processStage:"Anti Fraud",risk:65, riskReason:"New beneficiary — first payment", riskFlag:"MED",      verified:false, overdue:true, bank:"Barclays",       legalEntity:"GTreasury UK Ltd", approver:"A. Pacheco", approvalLevel:1, operativeAcct:"0A_BARCLAYS_GBP",    offsetNumber:"4012345604" },
  { id:"AF-100105",  payee:"Orion Global Corp",       type:"Wire", instType:"WIRE",     modelId:"WIRE_FRAUD",         amount: 175000.00, cur:"USD", trnDate:"25/02/2026", valDate:"25/02/2026", status:"Under Review",     nextStatus:"Approve / Reject",  processStage:"Anti Fraud",risk:88, riskReason:"Amount 3× account average",      riskFlag:"HIGH",     verified:false, overdue:true, bank:"Wells Fargo",    legalEntity:"GTreasury US LLC", approver:"A. Pacheco", approvalLevel:2, operativeAcct:"0A_WELLS_USD",       offsetNumber:"4012345605" },
  { id:"AF-100106",  payee:"Navarro Supply Co",       type:"Wire", instType:"PL_E_PAY", modelId:"PL_E_PAY_FRAUD",     amount:   9300.00, cur:"EUR", trnDate:"26/02/2026", valDate:"26/02/2026", status:"Under Review",     nextStatus:"Approve / Reject",  processStage:"Anti Fraud",risk:55, riskReason:"AML screening — pending review", riskFlag:"MED",      verified:false, overdue:true, bank:"BNP Paribas",    legalEntity:"GTreasury EU GmbH",approver:"A. Pacheco", approvalLevel:1, operativeAcct:"0A_BNP_EUR",         offsetNumber:"4012345606" },
  { id:"AF-100107",  payee:"Vantage Freight Ltd",     type:"Wire", instType:"PL_E_PAY", modelId:"PL_E_PAY_FRAUD",     amount:  62500.00, cur:"USD", trnDate:"25/02/2026", valDate:"25/02/2026", status:"Under Review",     nextStatus:"Approve / Reject",  processStage:"Anti Fraud",risk:72, riskReason:"Duplicate payment reference",    riskFlag:"HIGH",     verified:false, overdue:true, bank:"Chase Bank",     legalEntity:"GTreasury LLC",    approver:"A. Pacheco", approvalLevel:1, operativeAcct:"0A_CHASE_USD1",      offsetNumber:"4012345607" },
  { id:"AF-100108",  payee:"Cascade Renewables",      type:"Wire", instType:"PL_E_PAY", modelId:"PL_E_PAY_FRAUD",     amount:  34800.00, cur:"GBP", trnDate:"26/02/2026", valDate:"26/02/2026", status:"Under Review",     nextStatus:"Approve / Reject",  processStage:"Anti Fraud",risk:60, riskReason:"Counterparty jurisdiction risk", riskFlag:"MED",      verified:false, overdue:true, bank:"NatWest",        legalEntity:"GTreasury UK Ltd", approver:"A. Pacheco", approvalLevel:1, operativeAcct:"0A_NATWEST_GBP",     offsetNumber:"4012345608" },
  { id:"AF-100109",  payee:"Summit Asset Partners",   type:"Wire", instType:"WIRE",     modelId:"WIRE_FRAUD",         amount: 480000.00, cur:"USD", trnDate:"24/02/2026", valDate:"24/02/2026", status:"Under Review",     nextStatus:"Approve / Reject",  processStage:"Anti Fraud",risk:95, riskReason:"High-risk beneficiary profile",  riskFlag:"CRIT",     verified:false, overdue:true, bank:"JPMorgan Chase", legalEntity:"GTreasury US LLC", approver:"A. Pacheco", approvalLevel:2, operativeAcct:"Master (****1234)",  offsetNumber:"4012345609" },
  { id:"AF-100110",  payee:"Titan Procurement SA",    type:"Wire", instType:"PL_E_PAY", modelId:"PL_E_PAY_FRAUD",     amount:  27600.00, cur:"EUR", trnDate:"26/02/2026", valDate:"26/02/2026", status:"Under Review",     nextStatus:"Approve / Reject",  processStage:"Anti Fraud",risk:68, riskReason:"Structuring pattern detected",   riskFlag:"HIGH",     verified:false, overdue:true, bank:"Deutsche Bank",  legalEntity:"GTreasury EU GmbH",approver:"A. Pacheco", approvalLevel:1, operativeAcct:"0A_DEUTSCHE_EUR",    offsetNumber:"4012345610" },
];

const fmtAmt = (n: number, c: string) =>
  `${c==="EUR"?"€":c==="GBP"?"£":"$"}${n.toLocaleString("en-US",{minimumFractionDigits:2})}`;

// Module-level risk colour helper — used by FraudSpotlight and ResultsTable
const getRiskColor = (r: number) =>
  r >= 90 ? { ring:"border-red-500",    text:"text-red-400"    }
  : r >= 70 ? { ring:"border-orange-500",text:"text-orange-400" }
  :           { ring:"border-amber-400", text:"text-amber-400"  };

const PROCESS_STAGES: { key: ProcessStage; color: string; bg: string; desc: string; cta?: string }[] = [
  { key:"Create",    color:"#6366f1", bg:"#eef2ff", desc:"Transactions created and validated",         cta:"New Payment"   },
  { key:"Anti Fraud",color:"#f97316", bg:"#fff7ed", desc:"Fraud screening and AML checks in progress", cta:"Review Flags"  },
  { key:"Approvals", color:"#8b5cf6", bg:"#f5f3ff", desc:"Awaiting authorised approver sign-off",      cta:"Approve Queue" },
  { key:"Status",    color:"#0ea5e9", bg:"#f0f9ff", desc:"Sent for processing and settlement",         cta:undefined       },
  { key:"History",   color:"#64748b", bg:"#f8fafc", desc:"Completed and archived transactions",        cta:undefined       },
];

// ── App nav ───────────────────────────────────────────────────────────────────
// AppNav is now imported from @/components/AppNav



// ── FraudBadge ────────────────────────────────────────────────────────────────
function FraudBadge({ risk, reason }: { risk: number; reason: string | null }) {
  const hi = risk >= 70, md = risk >= 40;
  const ring        = hi ? "border-rose-600"   : md ? "border-amber-500"   : "border-emerald-600";
  const color       = hi ? "text-rose-400"     : md ? "text-amber-400"     : "text-emerald-400";
  const reasonColor = hi ? "text-rose-300"     : md ? "text-amber-300"     : "text-emerald-300";
  const bg          = hi ? "bg-rose-500/10"    : md ? "bg-amber-500/10"    : "bg-emerald-500/10";
  const label       = hi ? "HIGH"              : md ? "MED"                : "LOW";
  return (
    <div>
      <div className={`inline-flex items-center gap-1 px-1.5 py-0.5 rounded border-2 ${ring} ${bg} ${color} text-xs font-bold w-fit`}
        aria-label={`Risk score ${risk} — ${label}`}>
        {hi ? <ShieldAlert className="w-2.5 h-2.5" aria-hidden="true" /> : <ShieldCheck className="w-2.5 h-2.5" aria-hidden="true" />}
        <span aria-hidden="true">{risk}</span> · {label}
      </div>
      {reason && <p className={`text-[11px] ${reasonColor} mt-0.5 max-w-[140px] leading-tight`}>{reason}</p>}
    </div>
  );
}

// ── StatusChip ────────────────────────────────────────────────────────────────
function StatusChip({ status, next, overdue }: { status: string; next: string; overdue: boolean }) {
  const s = status;
  const cls =
    overdue                      ? "bg-rose-500/20 border-rose-500/40 text-rose-300"
    : s === "Under Review"     ? "bg-orange-500/20 border-orange-500/35 text-orange-300"
    : s === "Needs Approval"   ? "bg-amber-500/20 border-amber-500/35 text-amber-300"
    : s === "Ready to Approve" ? "bg-purple-500/20 border-purple-500/35 text-purple-300"
    : s === "Ready to Extract" ? "bg-teal-500/20 border-teal-500/35 text-teal-300"
    : s === "Extracted"        ? "bg-blue-500/20 border-blue-500/35 text-blue-300"
    : s === "Confirmed"        ? "bg-indigo-500/20 border-indigo-500/35 text-indigo-300"
    : s === "Processing"       ? "bg-sky-500/20 border-sky-500/35 text-sky-300"
    : s === "Approved"         ? "bg-emerald-500/20 border-emerald-500/35 text-emerald-300"
    : s === "Failed"           ? "bg-red-500/20 border-red-500/35 text-red-300"
    : s === "Void"             ? "bg-slate-700/50 border-slate-600/50 text-slate-400"
    : s === "Draft"            ? "bg-indigo-500/15 border-indigo-500/30 text-indigo-300"
    :                            "bg-slate-700/30 border-slate-600/40 text-slate-300";
  return (
    <div className="flex items-center gap-1 text-xs flex-wrap">
      <span className={`px-1.5 py-0.5 rounded font-semibold border ${cls}`}>
        {overdue && <Clock className="w-2.5 h-2.5 inline mr-1" aria-hidden="true" />}
        {status}
      </span>
      <ArrowRight className="w-2.5 h-2.5 text-slate-400" aria-hidden="true" />
      <span className="text-slate-400 text-[11px]">{next}</span>
    </div>
  );
}

// ── FraudSpotlight — types, data & helpers ────────────────────────────────────
interface FlaggedTxn {
  id: string; paymentNumber: string; vendor: string; corridor: string;
  currency: string; amount: number; riskScore: number;
  riskLevel: "low"|"medium"|"high"|"critical";
  riskFactors: string[]; recommendation: string;
}
const FRAUD_DATA: FlaggedTxn[] = [
  { id:"1",  paymentNumber:"2766", vendor:"Trusted Partner Ltd",        corridor:"N/A",   currency:"GBP", amount:32000,    riskScore:81, riskLevel:"high",
    riskFactors:["First-Time Payee: No prior transaction history with this recipient","High-Risk Countries: Beneficiary bank located in sanctioned jurisdiction","Amount Outlier: Payment 4.2x above historical average for this corridor"],
    recommendation:"HIGH RISK — Multiple risk factors identified. Manual review and authorization required." },
  { id:"2",  paymentNumber:"2785", vendor:"Regular Supplier",           corridor:"N/A",   currency:"EUR", amount:200000,   riskScore:46, riskLevel:"medium",
    riskFactors:["Amount Outlier: Payment exceeds 2x typical range for this beneficiary","Off-Hours Check: Submitted at 23:47 outside business hours (09:00–17:00)"],
    recommendation:"MEDIUM RISK — Amount exceeds typical range and submitted after hours. Recommend additional verification before proceeding." },
  { id:"3",  paymentNumber:"2763", vendor:"Widget Manufacturing Co",    corridor:"N/A",   currency:"CAD", amount:45750,    riskScore:85, riskLevel:"high",
    riskFactors:["First-Time Payee: New unverified beneficiary with no transaction history","High-Risk Countries: Routing through elevated-risk jurisdiction (Cayman Islands)","Amount Outlier: First payment to this vendor exceeds $40,000 threshold"],
    recommendation:"HIGH RISK — Multiple risk factors identified. Manual review and authorization required." },
  { id:"4",  paymentNumber:"2767", vendor:"Suspicious Entity Inc",      corridor:"N/A",   currency:"USD", amount:500000,   riskScore:92, riskLevel:"critical",
    riskFactors:["High-Risk Countries: Beneficiary in FATF-listed jurisdiction with sanctions exposure","Velocity Check: 5 payments to same beneficiary in 24 hours (threshold: 3)","Amount Outlier: Payment 8x above historical average","First-Time Payee: No prior relationship — shell company indicators detected"],
    recommendation:"CRITICAL RISK — Immediate review required. Transaction blocked pending manual authorization." },
  { id:"5",  paymentNumber:"2790", vendor:"Global Logistics Corp",      corridor:"US → US", currency:"USD", amount:125000, riskScore:78, riskLevel:"high",
    riskFactors:["Velocity Check: Duplicate payment detected — same amount and beneficiary within 2 hours","Amount Outlier: Payment 3x above 90-day average for this vendor","Off-Hours Check: Submitted at 02:15 outside business hours (09:00–17:00)"],
    recommendation:"HIGH RISK — Duplicate payment pattern with off-hours submission. Manual review required before release." },
  { id:"6",  paymentNumber:"2791", vendor:"Offshore Trading Group",     corridor:"US → KY", currency:"USD", amount:750000, riskScore:95, riskLevel:"critical",
    riskFactors:["High-Risk Countries: FATF high-risk jurisdiction (Cayman Islands) with sanctions list match (91%)","First-Time Payee: Nominee structure detected — no prior transaction history","Velocity Check: 7 payments across 3 related entities in 48 hours","Amount Outlier: Single payment exceeds $500,000 threshold","Off-Hours Check: Submitted at 01:30 outside business hours (09:00–17:00)"],
    recommendation:"CRITICAL RISK — Immediate void required. Nominee structure with sanctions match. File SAR." },
  { id:"7",  paymentNumber:"2792", vendor:"MedTech Solutions",          corridor:"US → IN", currency:"INR", amount:8500000, riskScore:52, riskLevel:"medium",
    riskFactors:["First-Time Payee: New beneficiary with no prior transaction history","High-Risk Countries: Cross-border payment to emerging market jurisdiction"],
    recommendation:"MEDIUM RISK — First-time beneficiary in emerging market. Recommend EDD before approval." },
  { id:"8",  paymentNumber:"2793", vendor:"Nordic Energy AS",           corridor:"US → NO", currency:"NOK", amount:1200000, riskScore:88, riskLevel:"critical",
    riskFactors:["Amount Outlier: Invoice amount 3x historical average for this vendor","High-Risk Countries: Beneficiary bank changed to high-risk jurisdiction","Velocity Check: Approval chain bypassed — 4 payments submitted in rapid succession","Off-Hours Check: Submitted at 04:22 outside business hours (09:00–17:00)"],
    recommendation:"CRITICAL RISK — BEC attack indicators present. Transaction blocked pending security review and out-of-band confirmation with vendor." },
  { id:"9",  paymentNumber:"2794", vendor:"Pacific Rim Holdings",       corridor:"US → HK", currency:"HKD", amount:2400000, riskScore:72, riskLevel:"high",
    riskFactors:["First-Time Payee: New beneficiary with no prior transaction history","Amount Outlier: Payment 2.5x above historical average for this corridor"],
    recommendation:"HIGH RISK — First-time payee with elevated amount. Manual review recommended." },
  { id:"10", paymentNumber:"2795", vendor:"Quantum Financial Services", corridor:"US → SG", currency:"SGD", amount:680000, riskScore:58, riskLevel:"medium",
    riskFactors:["Velocity Check: 3 payments to same beneficiary within 6 hours","Off-Hours Check: Submitted at 22:10 outside business hours (09:00–17:00)"],
    recommendation:"MEDIUM RISK — Velocity pattern with off-hours submission. Additional verification recommended." },
  { id:"11", paymentNumber:"2796", vendor:"Atlas Infrastructure Corp",  corridor:"US → AE", currency:"AED", amount:3200000, riskScore:83, riskLevel:"high",
    riskFactors:["High-Risk Countries: Beneficiary in UAE free trade zone with limited transparency","Amount Outlier: Single payment exceeds $800,000 threshold","First-Time Payee: No prior relationship — complex ownership structure detected"],
    recommendation:"HIGH RISK — Complex ownership with high-risk jurisdiction. Enhanced due diligence required before approval." },
];

interface VerifAV  { status:"pass"|"warning"|"fail"; confidence:number; recommendation:string; checks:{label:string;passed:boolean}[] }
interface VerifKYB { risk:"low"|"medium"|"high"; status:string; assessment:string; actions:string[] }
const VERIF_DATA: Record<string, { av?:VerifAV; kyb?:VerifKYB }> = {
  "2766": {
    av:  { status:"pass",    confidence:94, recommendation:"Safe to proceed with transaction", checks:[{label:"Account active and operational",passed:true},{label:"No fraud alerts on file",passed:true},{label:"Not on sanctions / PEP lists",passed:true},{label:"Name match: 94% confidence",passed:true}] },
    kyb: { risk:"low",    status:"COMPLIANT",                     assessment:"Legitimate, well-established entity with clean regulatory record. All checks passed.", actions:[] } },
  "2785": {
    av:  { status:"warning", confidence:67, recommendation:"Request documentation to confirm legal business name", checks:[{label:"Account active and operational",passed:true},{label:"Name match: 67% (S.A. suffix mismatch)",passed:false},{label:"Account type: Savings (unusual for B2B)",passed:false},{label:"Account opened < 3 years ago",passed:false}] },
    kyb: { risk:"medium", status:"REQUIRES ADDITIONAL DILIGENCE", assessment:"UBO data unavailable. Potential OFAC sanctions match at 85% confidence. Company registration unverified.", actions:["Obtain UBO Declaration Form","Confirm sanctions list false positive","Request Certificate of Incorporation"] } },
  "2763": {
    av:  { status:"warning", confidence:58, recommendation:"Clarify name discrepancy before proceeding", checks:[{label:"Account active and operational",passed:true},{label:"Name match: 58% (Co vs Company Inc)",passed:false},{label:"Account type: Savings (unusual for B2B)",passed:false}] },
    kyb: { risk:"medium", status:"REQUIRES ADDITIONAL DILIGENCE", assessment:"Relatively new business. Name discrepancy warrants clarification. Minor adverse media found but resolved.", actions:["Clarify name discrepancy","Request updated business registration"] } },
  "2767": {
    av:  { status:"fail",    confidence:31, recommendation:"DO NOT PROCEED — escalate immediately", checks:[{label:"Account status: FROZEN",passed:false},{label:"Fraud alert flagged by bank (Dec 2025)",passed:false},{label:"Found on internal watchlist (Jan 2026)",passed:false},{label:"Name match: 31% confidence",passed:false}] },
    kyb: { risk:"high",   status:"NON-COMPLIANT",                 assessment:"OFAC SDN match at 98%. Active money laundering investigation. Entity presents unacceptable compliance risk.", actions:["Freeze transaction immediately","File SAR","Notify OFAC within 10 days","Escalate to Chief Compliance Officer"] } },
  "2790": {
    av:  { status:"warning", confidence:62, recommendation:"Confirm account change with vendor via verified contact before releasing", checks:[{label:"Account active and operational",passed:true},{label:"Duplicate payment detected",passed:false},{label:"Beneficiary account changed within 72 hours",passed:false},{label:"Payment velocity: 3 payments in 24 hours",passed:false}] },
    kyb: { risk:"medium", status:"REQUIRES ADDITIONAL DILIGENCE", assessment:"Established company but duplicate payment pattern and recent customs investigation warrant additional review.", actions:["Verify no duplicate payment","Confirm account change with vendor","Review customs investigation status"] } },
  "2791": {
    av:  { status:"fail",    confidence:22, recommendation:"DO NOT PROCEED — void transaction immediately", checks:[{label:"Account status: FROZEN",passed:false},{label:"Multiple SAR filings associated",passed:false},{label:"Name match: 22% — nominee structure detected",passed:false}] },
    kyb: { risk:"high",   status:"NON-COMPLIANT",                 assessment:"Extremely high risk. Nominee structure with OFAC SDN match (91%) and active money laundering investigation. Void immediately.", actions:["Void transaction","File SAR","Escalate to CCO","Freeze related accounts"] } },
  "2792": {
    av:  { status:"warning", confidence:71, recommendation:"Verify beneficiary details with sender before proceeding", checks:[{label:"Account active and operational",passed:true},{label:"Name match: 71% (Pvt Ltd suffix added)",passed:true},{label:"First-time payment to this beneficiary",passed:false}] },
    kyb: { risk:"medium", status:"REQUIRES ADDITIONAL DILIGENCE", assessment:"Legitimate but new company. First-time beneficiary warrants standard enhanced due diligence for initial transaction.", actions:["Verify beneficiary details with originator","Request proforma invoice or contract"] } },
  "2793": {
    av:  { status:"fail",    confidence:28, recommendation:"DO NOT PROCEED — Strong BEC indicators. Contact vendor via known phone number immediately.", checks:[{label:"Account NOT at expected bank (DNB ASA)",passed:false},{label:"Account opened 47 days ago — newly created",passed:false},{label:"Name match: 28% — different entity name",passed:false},{label:"CEO email domain mismatch detected",passed:false}] },
    kyb: { risk:"high",   status:"NON-COMPLIANT",                 assessment:"CRITICAL — Strong BEC attack indicators. Bank changed Norway → Cyprus. Name mismatch with shell entity. DO NOT release funds.", actions:["Block payment immediately","Contact Nordic Energy AS via verified phone","Report BEC attempt to FBI IC3","Review all recent payment instructions from this vendor"] } },
};

const ANOMALY_PFXS = ["Amount Outlier"];
const isAnomaly = (f: string) => ANOMALY_PFXS.some(p => f.startsWith(p));
const displayScore = (t: FlaggedTxn) => t.riskFactors.some(f => !isAnomaly(f)) ? t.riskScore : Math.min(t.riskScore, 70);
const primaryTrigger = (factors: string[]) => {
  const f = factors.find(x => !isAnomaly(x)) ?? factors[0] ?? "";
  if (f.startsWith("First-Time Payee"))    return "New Beneficiary";
  if (f.startsWith("High-Risk Countries")) return "High-Risk Jurisdiction";
  if (f.startsWith("Velocity Check"))      return "Velocity Flag";
  if (f.startsWith("Off-Hours"))           return "Off-Hours";
  if (f.startsWith("Amount Outlier"))      return "Unusual Amount";
  return "Flagged";
};
const scoreColors = (score: number, anomalyOnly: boolean) =>
  anomalyOnly                  ? { dot:"bg-amber-400",   text:"text-amber-400",   label:"Anomaly Detected" }
  : score >= 90                ? { dot:"bg-red-500",     text:"text-red-400",     label:"Critical Risk"    }
  : score >= 75                ? { dot:"bg-orange-500",  text:"text-orange-400",  label:"High Risk"        }
  : score >= 50                ? { dot:"bg-amber-500",   text:"text-amber-400",   label:"Medium Risk"      }
  :                              { dot:"bg-emerald-500", text:"text-emerald-400", label:"Low Risk"         };
const fmtFlagAmt = (amt: number, cur: string) => {
  const sym: Record<string,string> = {USD:"$",EUR:"€",GBP:"£",CAD:"C$",HKD:"HK$",SGD:"S$",NOK:"kr ",INR:"₹",AED:"AED "};
  return `${sym[cur]??cur+" "}${amt.toLocaleString("en-US")}`;
};

function RiskScoreBadge({ txn, size="sm" }: { txn:FlaggedTxn; size?:"sm"|"lg" }) {
  const anomalyOnly = !txn.riskFactors.some(f => !isAnomaly(f));
  const score = displayScore(txn);
  const c = scoreColors(score, anomalyOnly);
  const lg = size === "lg";
  return (
    <div className="shrink-0 flex flex-col">
      <div className="flex items-center gap-1.5">
        <div className={`rounded-full shrink-0 ${c.dot} ${lg ? "w-2.5 h-2.5" : "w-2 h-2"}`} />
        <span className={`font-bold tabular-nums ${c.text} ${lg ? "text-2xl" : "text-sm"}`}>{score}</span>
        <span className={`text-slate-400 ${lg ? "text-sm" : "text-xs"}`}>/100</span>
      </div>
      <span className={`font-semibold ${c.text} ${lg ? "text-xs mt-0.5" : "text-[10px]"}`}>{c.label}</span>
    </div>
  );
}

// ── FraudSpotlight ────────────────────────────────────────────────────────────
function FraudSpotlight() {
  const [open, setOpen]                   = useState(false);
  const [selectedId, setSelectedId]       = useState<string|null>(null);
  const [actioned, setActioned]           = useState<string[]>([]);
  const [overrideOpen, setOverrideOpen]   = useState(false);
  const [overrideReason, setOverrideReason] = useState("");
  const [overrideTxn, setOverrideTxn]     = useState<FlaggedTxn|null>(null);
  const overrideDialogRef                 = useRef<HTMLDivElement>(null);
  useFocusTrap(overrideOpen, overrideDialogRef);
  const [avState,  setAvState]  = useState<Record<string,"idle"|"loading"|"done">>({});
  const [kybState, setKybState] = useState<Record<string,"idle"|"loading"|"done">>({});
  const [avSteps,  setAvSteps]  = useState<Record<string,{label:string;done:boolean}[]>>({});
  const [kybSteps, setKybSteps] = useState<Record<string,{label:string;done:boolean}[]>>({});

  const ALL_FLAGGED = FRAUD_DATA.filter(t => t.riskScore >= 50);
  const flagged     = ALL_FLAGGED.filter(t => !actioned.includes(t.id));
  const allCleared  = ALL_FLAGGED.length > 0 && flagged.length === 0;

  // QA-29: reset selectedId if selected transaction is no longer in the list
  useEffect(() => {
    if (selectedId && !flagged.find(t => t.id === selectedId)) setSelectedId(null);
  }, [flagged.length]); // eslint-disable-line react-hooks/exhaustive-deps

  // Esc closes Override dialog
  useEffect(() => {
    if (!overrideOpen) return;
    const onKey = (e: KeyboardEvent) => { if (e.key === "Escape") setOverrideOpen(false); };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [overrideOpen]);

  const selectedTxn = flagged.find(t => t.id === selectedId) ?? null;
  const selectedIdx = flagged.findIndex(t => t.id === selectedId);

  const critCount = flagged.filter(t => t.riskLevel === "critical").length;
  const highCount = flagged.filter(t => t.riskLevel === "high").length;

  const handleAction = (id: string) => {
    setActioned(a => [...a, id]);
    const next = flagged[selectedIdx + 1];
    setSelectedId(next ? next.id : null);
  };
  const handleOverrideConfirm = () => {
    if (overrideTxn) handleAction(overrideTxn.id);
    setOverrideOpen(false); setOverrideReason(""); setOverrideTxn(null);
  };

  const wait = (ms: number) => new Promise<void>(r => setTimeout(r, ms));
  const runAV = async (pn: string) => {
    const steps = ["Account number format","Bank routing code","Account holder name match","Account status verification"];
    setAvState(s => ({...s,[pn]:"loading"}));
    setAvSteps(s => ({...s,[pn]:steps.map(label=>({label,done:false}))}));
    for (let i=0;i<steps.length;i++) {
      await wait(500);
      setAvSteps(s => ({...s,[pn]:s[pn].map((st,idx)=>idx<=i?{...st,done:true}:st)}));
    }
    await wait(300);
    setAvState(s => ({...s,[pn]:"done"}));
  };
  const runKYB = async (pn: string) => {
    const steps = ["Corporate registry search","Beneficial ownership check","Sanctions & PEP screening","Adverse media screening","Financial crime database check","Industry watchlist cross-reference"];
    setKybState(s => ({...s,[pn]:"loading"}));
    setKybSteps(s => ({...s,[pn]:steps.map(label=>({label,done:false}))}));
    for (let i=0;i<steps.length;i++) {
      await wait(600);
      setKybSteps(s => ({...s,[pn]:s[pn].map((st,idx)=>idx<=i?{...st,done:true}:st)}));
    }
    await wait(300);
    setKybState(s => ({...s,[pn]:"done"}));
  };

  return (
    <section aria-label="Fraud spotlight" className="rounded-xl overflow-hidden border border-rose-500/20 mb-4">

      {/* ── Header ── */}
      <button
        onClick={() => setOpen(o => !o)}
        aria-expanded={open && !allCleared}
        aria-controls={!allCleared ? "fraud-spotlight-content" : undefined}
        className={`w-full flex items-center gap-3 px-4 py-3 text-left transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-inset focus:ring-white/20 ${allCleared ? "bg-emerald-500/10" : "fraud-gradient-header"}`}
        style={allCleared ? undefined : {background:"linear-gradient(to right, #E8367C, #F06844, #F9A826)"}}
      >
        <div className={`w-8 h-8 rounded-lg flex items-center justify-center shrink-0 ${allCleared ? "bg-emerald-500/15" : "bg-white/15 backdrop-blur-sm"}`}>
          {allCleared
            ? <ShieldCheck className="w-4 h-4 text-emerald-400" aria-hidden="true" />
            : <ShieldAlert  className="w-4 h-4 text-white"      aria-hidden="true" />}
        </div>
        <div className="flex-1 flex items-center gap-2 flex-wrap min-w-0">
          {allCleared ? (
            <span className="text-sm font-semibold text-emerald-400">All flagged transactions reviewed</span>
          ) : (
            <>
              <span className="text-sm font-semibold text-white">Fraud Protection Spotlight</span>
              <span className="inline-flex items-center px-2 py-0.5 rounded-full bg-white/20 text-white text-xs font-bold backdrop-blur-sm">
                {flagged.length} flagged
              </span>
              {critCount > 0 && <span className="text-xs text-white">{critCount} critical</span>}
              {highCount > 0 && <span className="text-xs text-white">{highCount} high</span>}
            </>
          )}
        </div>
        {!allCleared && (
          <span className="text-xs font-semibold text-white shrink-0" aria-hidden="true">
            {open ? "Collapse" : "Review now"}
          </span>
        )}
        {open
          ? <ChevronUp   className={`w-4 h-4 shrink-0 ${allCleared?"text-emerald-400":"text-white"}`} aria-hidden="true" />
          : <ChevronDown className={`w-4 h-4 shrink-0 ${allCleared?"text-emerald-400":"text-white"}`} aria-hidden="true" />}
      </button>

      {/* ── Expanded panel ── */}
      <AnimatePresence initial={false}>
        {open && !allCleared && (
          <motion.div id="fraud-spotlight-content"
            initial={{height:0,opacity:0}} animate={{height:"auto",opacity:1}}
            exit={{height:0,opacity:0}} transition={{duration:0.3,ease:[0.4,0,0.2,1]}}
            style={{overflow:"hidden"}}
          >
            <div className="border-t border-white/10 grid lg:grid-cols-2 bg-[#162a47]">

              {/* Left: transaction list */}
              <div role="listbox" aria-label="Flagged transactions"
                aria-activedescendant={selectedId ? `fraud-option-${selectedId}` : undefined}
                className="divide-y divide-[#1a3455] max-h-[360px] overflow-y-auto">
                {flagged.map((t) => {
                  const isSel = t.id === selectedId;
                  const anomalyOnly = !t.riskFactors.some(f => !isAnomaly(f));
                  const score = displayScore(t);
                  const c = scoreColors(score, anomalyOnly);
                  const trigger = primaryTrigger(t.riskFactors);
                  return (
                    <div key={t.id} id={`fraud-option-${t.id}`}
                      role="option" tabIndex={0} aria-selected={isSel}
                      onClick={() => setSelectedId(isSel ? null : t.id)}
                      onKeyDown={(e) => {
                        const idx = flagged.findIndex(x => x.id === t.id);
                        if (e.key==="ArrowDown" && idx<flagged.length-1) { e.preventDefault(); setSelectedId(flagged[idx+1].id); }
                        else if (e.key==="ArrowUp" && idx>0)             { e.preventDefault(); setSelectedId(flagged[idx-1].id); }
                        else if (e.key==="Enter" || e.key===" ")         { e.preventDefault(); setSelectedId(isSel ? null : t.id); }
                      }}
                      className={`w-full flex items-center gap-3 px-4 py-3 cursor-pointer transition-colors duration-200 focus:outline-none focus:ring-2 focus:ring-inset focus:ring-teal-500/50
                        ${isSel ? "bg-[#162a47] border-l-2 border-l-teal-400" : "hover:bg-[#162a47]/50 border-l-2 border-l-transparent"}`}>
                      <RiskScoreBadge txn={t} size="sm" />
                      <div className="flex-1 min-w-0">
                        <div className="text-sm font-semibold text-slate-200 truncate">{t.vendor}</div>
                        <div className="flex items-center gap-2 mt-0.5">
                          <span className="text-xs text-slate-300 font-medium">{t.currency} {t.amount.toLocaleString()}</span>
                          <span className="text-xs text-slate-400">#{t.paymentNumber}</span>
                        </div>
                      </div>
                      <span className={`shrink-0 text-[10px] font-bold px-1.5 py-0.5 rounded border uppercase tracking-wider
                        ${anomalyOnly ? "bg-blue-500/10 border-blue-500/25 text-blue-300"
                        : score>=75   ? "bg-rose-500/15 border-rose-500/25 text-rose-300"
                        :               "bg-amber-500/15 border-amber-500/25 text-amber-300"}`}>
                        {trigger}
                      </span>
                      <ChevronRight className={`w-4 h-4 shrink-0 transition-transform ${isSel?"rotate-90 text-teal-400":"text-slate-600"}`} aria-hidden="true" />
                    </div>
                  );
                })}
              </div>

              {/* Right: detail panel */}
              <div className="border-l border-[#1a3455] bg-[#162a47]">
                {selectedTxn ? (() => {
                  const pn           = selectedTxn.paymentNumber;
                  const ruleFactors  = selectedTxn.riskFactors.filter(f => !isAnomaly(f));
                  const anomFactors  = selectedTxn.riskFactors.filter(f =>  isAnomaly(f));
                  const anomalyOnly  = ruleFactors.length === 0;
                  const hasAnomalies = anomFactors.length > 0;
                  const avS   = avState[pn]  ?? "idle";
                  const kybS  = kybState[pn] ?? "idle";
                  const avSt  = avSteps[pn]  ?? [];
                  const kybSt = kybSteps[pn] ?? [];
                  const avRes  = VERIF_DATA[pn]?.av;
                  const kybRes = VERIF_DATA[pn]?.kyb;
                  const recCls = anomalyOnly
                    ? "border-blue-400 bg-blue-500/25 text-white"
                    : selectedTxn.riskLevel==="critical"||selectedTxn.riskLevel==="high"
                      ? "border-rose-400 bg-rose-500/25 text-white"
                      : selectedTxn.riskLevel==="medium"
                        ? "border-amber-400 bg-amber-500/25 text-white"
                        : "border-emerald-400 bg-emerald-500/25 text-white";
                  return (
                    <div className="p-4 flex flex-col gap-4 overflow-y-auto max-h-[360px]"
                      role="region" aria-label="Transaction detail">

                      {/* Header */}
                      <div className="flex items-start gap-4">
                        <RiskScoreBadge txn={selectedTxn} size="lg" />
                        <div className="flex-1 min-w-0">
                          <h3 className="font-bold text-white text-base leading-tight m-0">{selectedTxn.vendor}</h3>
                          <p className="text-sm font-semibold text-slate-200 mt-1 m-0">
                            {selectedTxn.currency} {selectedTxn.amount.toLocaleString()}
                          </p>
                          <div className="flex items-center gap-2 mt-0.5 flex-wrap">
                            <span className="text-xs text-slate-400">#{selectedTxn.paymentNumber}</span>
                            {selectedTxn.corridor !== "N/A" && (
                              <span className="text-xs text-slate-400">· {selectedTxn.corridor}</span>
                            )}
                          </div>
                        </div>
                      </div>

                      {/* Factor pills */}
                      <div className="flex flex-wrap gap-1.5">
                        {anomalyOnly
                          ? anomFactors.map((f, i) => (
                              <span key={i} className="relative group cursor-default inline-flex items-center gap-1 text-xs px-2 py-0.5 rounded border border-blue-400/30 bg-blue-500/10 text-blue-300 font-medium">
                                ~ {f.split(":")[0]}
                                <span className="pointer-events-none absolute bottom-full left-0 mb-2 hidden group-hover:block w-60 rounded-lg bg-slate-900 border border-slate-700/60 px-3 py-2 text-xs text-slate-300 shadow-xl z-20 leading-relaxed">
                                  Anomaly Detected — statistically derived from this client's historical transaction data
                                </span>
                              </span>
                            ))
                          : ruleFactors.map((f, i) => (
                              <span key={i} className="text-xs px-2 py-0.5 rounded border border-amber-500/30 bg-amber-500/15 text-amber-300 font-medium">
                                {f.split(":")[0]}
                              </span>
                            ))
                        }
                      </div>

                      {/* Risk factors breakdown */}
                      <div>
                        <div className="flex items-center justify-between mb-2">
                          <p className="text-[11px] uppercase tracking-wider text-slate-400 font-semibold m-0">Risk Factors</p>
                          <div className="flex items-center gap-3 text-[10px] text-slate-400">
                            {ruleFactors.length>0 && <span className="flex items-center gap-1"><AlertTriangle className="w-3 h-3 text-amber-400" />Rule-Based</span>}
                            {hasAnomalies          && <span className="flex items-center gap-1 text-blue-400"><span className="font-bold">~</span>Anomaly</span>}
                          </div>
                        </div>
                        {ruleFactors.length>0 && (
                          <div className="space-y-1.5">
                            {ruleFactors.map((f,i) => (
                              <div key={i} className="flex items-start gap-2 text-xs">
                                <AlertTriangle className="w-3.5 h-3.5 shrink-0 mt-0.5 text-amber-400" />
                                <span className="text-slate-400">{f}</span>
                              </div>
                            ))}
                          </div>
                        )}
                        {hasAnomalies && ruleFactors.length>0 && (
                          <div className="mt-3 pt-3 border-t border-slate-800/60">
                            <span className="text-[10px] font-medium text-slate-400 uppercase tracking-wider">Additional Signal</span>
                            <div className="space-y-1.5 mt-1.5">
                              {anomFactors.map((f,i) => (
                                <div key={i} className="flex items-start gap-2 text-xs">
                                  <span className="text-blue-400 font-bold shrink-0 mt-0.5">~</span>
                                  <span className="text-slate-400">{f}</span>
                                </div>
                              ))}
                            </div>
                          </div>
                        )}
                        {anomalyOnly && (
                          <div className="space-y-1.5">
                            {anomFactors.map((f,i) => (
                              <div key={i} className="flex items-start gap-2 text-xs">
                                <span className="text-blue-400 font-bold shrink-0 mt-0.5">~</span>
                                <span className="text-slate-400">{f}</span>
                                <span className="text-[10px] text-blue-300 italic mt-0.5 shrink-0">Anomaly Detected</span>
                              </div>
                            ))}
                          </div>
                        )}
                      </div>

                      {/* Verification Actions */}
                      <div>
                        <div className="flex items-center justify-between mb-2">
                          <p className="text-[11px] uppercase tracking-wider text-slate-400 font-semibold m-0">Verification Actions</p>
                          <span className="text-[10px] text-teal-400 flex items-center gap-1">
                            <Info className="w-3 h-3" aria-hidden="true" />Enhanced screening available
                          </span>
                        </div>
                        <div className="grid grid-cols-2 gap-2 mb-2">
                          <button disabled={avS==="loading"} onClick={() => runAV(pn)}
                            className={`flex items-center gap-2 px-3 py-2.5 rounded-lg border text-left transition-all focus:outline-none focus:ring-2 focus:ring-teal-500/50 disabled:opacity-50
                              ${avS==="done" ? "border-teal-500/30 bg-teal-500/5" : "border-slate-700/60 bg-[#0f1e35] hover:border-slate-600"}`}>
                            <Building2 className="w-4 h-4 text-teal-400 shrink-0" aria-hidden="true" />
                            <div className="flex-1 min-w-0">
                              <p className="text-xs font-medium text-slate-300 m-0">Account Verification</p>
                              <p className="text-[10px] text-slate-400 m-0">{avS==="idle"?"Verify beneficiary account":avS==="loading"?"Running…":"Completed"}</p>
                            </div>
                            {avS==="loading" && <Loader2 className="w-3.5 h-3.5 text-teal-400 animate-spin shrink-0" />}
                            {avS==="done" && avRes && (avRes.status==="pass" ? <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" /> : avRes.status==="warning" ? <AlertTriangle className="w-3.5 h-3.5 text-amber-400 shrink-0" /> : <X className="w-3.5 h-3.5 text-rose-400 shrink-0" />)}
                          </button>
                          <button disabled={kybS==="loading"} onClick={() => runKYB(pn)}
                            className={`flex items-center gap-2 px-3 py-2.5 rounded-lg border text-left transition-all focus:outline-none focus:ring-2 focus:ring-teal-500/50 disabled:opacity-50
                              ${kybS==="done" ? "border-teal-500/30 bg-teal-500/5" : "border-slate-700/60 bg-[#0f1e35] hover:border-slate-600"}`}>
                            <Search className="w-4 h-4 text-teal-400 shrink-0" aria-hidden="true" />
                            <div className="flex-1 min-w-0">
                              <p className="text-xs font-medium text-slate-300 m-0">Enhanced KYB Screening</p>
                              <p className="text-[10px] text-slate-400 m-0">{kybS==="idle"?"Business & compliance checks":kybS==="loading"?"Running…":"Completed"}</p>
                            </div>
                            {kybS==="loading" && <Loader2 className="w-3.5 h-3.5 text-teal-400 animate-spin shrink-0" />}
                            {kybS==="done" && kybRes && (kybRes.risk==="low" ? <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" /> : kybRes.risk==="medium" ? <AlertTriangle className="w-3.5 h-3.5 text-amber-400 shrink-0" /> : <X className="w-3.5 h-3.5 text-rose-400 shrink-0" />)}
                          </button>
                        </div>
                        {avS==="loading" && avSt.length>0 && (
                          <div className="rounded-lg border border-slate-700/60 bg-[#0f1e35] px-3 py-2.5 mb-2">
                            <div className="flex items-center gap-2 mb-1.5"><Loader2 className="w-3.5 h-3.5 animate-spin text-teal-400" /><span className="text-xs font-medium text-slate-300">Running Account Verification…</span></div>
                            <div className="space-y-1">{avSt.map((s,i)=><div key={i} className="flex items-center gap-2 text-xs">{s.done?<CheckCircle2 className="w-3 h-3 text-emerald-400"/>:<Loader2 className="w-3 h-3 animate-spin text-slate-400"/>}<span className={s.done?"text-slate-400":"text-slate-300"}>{s.label}</span></div>)}</div>
                          </div>
                        )}
                        {kybS==="loading" && kybSt.length>0 && (
                          <div className="rounded-lg border border-slate-700/60 bg-[#0f1e35] px-3 py-2.5 mb-2">
                            <div className="flex items-center gap-2 mb-1.5"><Loader2 className="w-3.5 h-3.5 animate-spin text-teal-400" /><span className="text-xs font-medium text-slate-300">Running Enhanced KYB Screening…</span></div>
                            <div className="space-y-1">{kybSt.map((s,i)=><div key={i} className="flex items-center gap-2 text-xs">{s.done?<CheckCircle2 className="w-3 h-3 text-emerald-400"/>:<Loader2 className="w-3 h-3 animate-spin text-slate-400"/>}<span className={s.done?"text-slate-400":"text-slate-300"}>{s.label}</span></div>)}</div>
                          </div>
                        )}
                        {avS==="done" && avRes && (
                          <div className={`rounded-lg border px-3 py-2.5 mb-2 text-xs ${avRes.status==="pass"?"border-emerald-500/30 bg-emerald-500/8":avRes.status==="warning"?"border-amber-500/30 bg-amber-500/8":"border-rose-500/30 bg-rose-500/8"}`}>
                            <div className="flex items-center justify-between mb-1.5">
                              <span className="font-semibold text-slate-200">Account Verification</span>
                              <span className={`font-bold text-[10px] uppercase tracking-wider ${avRes.status==="pass"?"text-emerald-400":avRes.status==="warning"?"text-amber-400":"text-rose-400"}`}>
                                {avRes.status==="pass"?"PASS":avRes.status==="warning"?"WARNING":"FAIL"} · {avRes.confidence}% confidence
                              </span>
                            </div>
                            <div className="space-y-1 mb-2">
                              {avRes.checks.map((c,i)=><div key={i} className="flex items-center gap-1.5">{c.passed?<CheckCircle2 className="w-3 h-3 text-emerald-400 shrink-0"/>:<X className="w-3 h-3 text-rose-400 shrink-0"/>}<span className={c.passed?"text-slate-400":"text-slate-300"}>{c.label}</span></div>)}
                            </div>
                            <p className={`text-[10px] font-medium m-0 ${avRes.status==="pass"?"text-emerald-400":avRes.status==="warning"?"text-amber-400":"text-rose-400"}`}>{avRes.recommendation}</p>
                          </div>
                        )}
                        {kybS==="done" && kybRes && (
                          <div className={`rounded-lg border px-3 py-2.5 mb-2 text-xs ${kybRes.risk==="low"?"border-emerald-500/30 bg-emerald-500/8":kybRes.risk==="medium"?"border-amber-500/30 bg-amber-500/8":"border-rose-500/30 bg-rose-500/8"}`}>
                            <div className="flex items-center justify-between mb-1.5">
                              <span className="font-semibold text-slate-200">KYB Screening</span>
                              <span className={`font-bold text-[10px] uppercase tracking-wider ${kybRes.risk==="low"?"text-emerald-400":kybRes.risk==="medium"?"text-amber-400":"text-rose-400"}`}>{kybRes.status}</span>
                            </div>
                            <p className="text-slate-400 mb-1.5 leading-relaxed m-0">{kybRes.assessment}</p>
                            {kybRes.actions.length>0 && (
                              <div className="space-y-0.5 mt-1.5">
                                {kybRes.actions.map((a,i)=><div key={i} className="flex items-start gap-1.5"><span className={`shrink-0 mt-0.5 ${kybRes.risk==="high"?"text-rose-400":"text-amber-400"}`}>→</span><span className="text-slate-400">{a}</span></div>)}
                              </div>
                            )}
                          </div>
                        )}
                      </div>

                      {/* Recommendation */}
                      <div>
                        <p className="text-[11px] uppercase tracking-wider text-slate-400 font-semibold mb-2 m-0">Recommendation</p>
                        <div className={`border-l-4 rounded-r-lg px-3 py-2.5 text-sm ${recCls}`}>
                          {anomalyOnly ? "Unusual pattern detected — please review payment details before approving." : selectedTxn.recommendation}
                        </div>
                      </div>

                      {/* Action buttons */}
                      <div className="flex flex-wrap gap-2">
                        <button onClick={() => handleAction(selectedTxn.id)}
                          className="flex items-center gap-1.5 px-3 py-2 min-h-[36px] rounded-lg text-xs font-bold bg-slate-700/40 hover:bg-slate-700/60 text-slate-300 border border-slate-700/60 transition-colors focus:outline-none focus:ring-2 focus:ring-slate-400 focus:ring-offset-1 focus:ring-offset-transparent">
                          Skip →
                        </button>
                        <button onClick={() => handleAction(selectedTxn.id)}
                          className="flex items-center gap-1.5 px-3 py-2 min-h-[36px] rounded-lg text-xs font-bold bg-rose-500/20 hover:bg-rose-500/30 text-rose-300 border border-rose-500/30 transition-colors focus:outline-none focus:ring-2 focus:ring-rose-400 focus:ring-offset-1 focus:ring-offset-transparent">
                          <X className="w-3.5 h-3.5" aria-hidden="true" /> Reject
                        </button>
                        <button onClick={() => handleAction(selectedTxn.id)}
                          className="flex items-center gap-1.5 px-3 py-2 min-h-[36px] rounded-lg text-xs font-bold bg-transparent hover:bg-rose-500/15 text-rose-400 border border-rose-500/40 transition-colors focus:outline-none focus:ring-2 focus:ring-rose-400 focus:ring-offset-1 focus:ring-offset-transparent">
                          <Ban className="w-3.5 h-3.5" aria-hidden="true" /> Void
                        </button>
                        <button
                          onClick={() => { setOverrideTxn(selectedTxn); setOverrideReason(""); setOverrideOpen(true); }}
                          className="flex-1 flex items-center justify-center gap-1.5 px-3 py-2 min-h-[36px] rounded-lg text-xs font-bold text-white transition-all hover:brightness-110 focus:outline-none focus:ring-2 focus:ring-rose-400 focus:ring-offset-1 focus:ring-offset-transparent"
                          style={{background:"linear-gradient(to right, #E8367C, #F06844)"}}>
                          <ShieldCheck className="w-3.5 h-3.5" aria-hidden="true" /> Override &amp; Approve
                        </button>
                      </div>
                    </div>
                  );
                })() : (
                  <div className="flex flex-col items-center justify-center h-full p-8 text-center" aria-live="polite">
                    <ShieldAlert className="w-8 h-8 text-slate-500 mb-2" aria-hidden="true" />
                    <p className="text-slate-400 text-sm">Select a transaction to review details</p>
                  </div>
                )}
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Override & Approve dialog */}
      <AnimatePresence>
        {overrideOpen && (
          <motion.div
            initial={{opacity:0}} animate={{opacity:1}} exit={{opacity:0}}
            className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm"
            onClick={e => { if(e.target===e.currentTarget) setOverrideOpen(false); }}
          >
            <motion.div
              ref={overrideDialogRef}
              initial={{scale:0.95,opacity:0}} animate={{scale:1,opacity:1}} exit={{scale:0.95,opacity:0}}
              transition={{duration:0.15}}
              className="bg-[#162a47] border border-slate-700/60 rounded-xl shadow-2xl w-full max-w-md mx-4 p-6"
              role="dialog" aria-modal="true" aria-labelledby="override-title"
            >
              <h3 id="override-title" className="text-white font-bold text-base m-0 mb-4">Override &amp; Approve</h3>
              <div className="rounded-lg bg-amber-500/10 border border-amber-500/30 p-3 mb-4">
                <div className="flex items-center gap-2 mb-1">
                  <AlertTriangle className="w-4 h-4 text-amber-400" aria-hidden="true" />
                  <span className="font-semibold text-sm text-white">Payment #{overrideTxn?.paymentNumber}</span>
                </div>
                <p className="text-xs text-slate-400 m-0">
                  {overrideTxn?.vendor} · {overrideTxn?.currency} {overrideTxn?.amount.toLocaleString()} · Risk Score: {overrideTxn?.riskScore}/100
                </p>
              </div>
              <label className="block text-sm font-medium text-slate-300 mb-1.5">
                Reason for Override <span className="text-rose-400">*</span>
              </label>
              <textarea
                value={overrideReason}
                onChange={e => setOverrideReason(e.target.value)}
                placeholder="Enter the reason for overriding the fraud alert and approving this transaction…"
                rows={4}
                className="w-full bg-[#0f1e35] border border-slate-700/60 text-slate-200 text-sm rounded-lg px-3 py-2 resize-none focus:outline-none focus:ring-2 focus:ring-teal-500/50 placeholder:text-slate-400 transition-all"
              />
              <p className="text-xs text-slate-400 mt-1.5 mb-5 m-0">This will be logged for audit and compliance purposes.</p>
              <div className="flex gap-3">
                <button onClick={() => setOverrideOpen(false)}
                  className="flex-1 py-2 rounded-lg border border-slate-700/60 text-slate-300 hover:text-white hover:border-slate-600 text-sm font-semibold transition-colors focus:outline-none focus:ring-2 focus:ring-teal-500/50">
                  Cancel
                </button>
                <button
                  disabled={!overrideReason.trim()}
                  onClick={handleOverrideConfirm}
                  className="flex-1 py-2 rounded-lg text-white text-sm font-bold transition-all hover:brightness-110 focus:outline-none focus:ring-2 focus:ring-rose-400 disabled:opacity-40 disabled:cursor-not-allowed"
                  style={{background: overrideReason.trim() ? "linear-gradient(to right, #E8367C, #F06844)" : "#374151"}}>
                  Confirm Override
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </section>
  );
}

// ── ProcessFlow ────────────────────────────────────────────────────────────────
function ProcessFlow({ txns, isFiltered, filters, setFilters }: {
  txns: Txn[]; isFiltered: boolean; filters: Filters; setFilters: (f: Filters) => void;
}) {
  const [open, setOpen] = useState(true);

  const counts = Object.fromEntries(
    PROCESS_STAGES.map(s => [s.key, txns.filter(t => t.processStage === s.key).length])
  ) as Record<ProcessStage, number>;

  const activeStage = filters.processStage as ProcessStage | "";

  const toggleStage = (key: ProcessStage) => {
    setFilters({ ...filters, processStage: activeStage === key ? "" : key });
  };

  return (
    <section aria-label="Process flow" className="bg-[#162a47] border border-slate-700/50 rounded-xl overflow-hidden">
      <button
        onClick={() => setOpen(o => !o)}
        aria-expanded={open}
        aria-controls="process-flow-content"
        className="w-full flex items-center gap-3 px-4 py-2.5 hover:bg-white/2 transition-colors duration-200 select-none text-left">
        <span className="text-base font-semibold text-white shrink-0">Process Flow</span>
        {isFiltered && <span className="text-[11px] text-slate-400 italic shrink-0">*filtered</span>}
        {!open && (
          <div className="flex items-center gap-1.5 flex-1 min-w-0 ml-1" aria-hidden="true">
            {PROCESS_STAGES.map((s, i) => (
              <div key={s.key} className="flex items-center gap-1 shrink-0">
                <span className={`text-[11px] px-1.5 py-0.5 rounded font-semibold transition-all ${activeStage === s.key ? "ring-1" : ""}`}
                  style={{
                    color: s.color,
                    background: activeStage === s.key ? s.color + "33" : s.color + "22",
                    ...(activeStage === s.key ? { boxShadow:`0 0 0 1px ${s.color}66` } : {}),
                  }}>
                  {s.key} ({counts[s.key]})
                </span>
                {i < 4 && <ArrowRight className="w-2.5 h-2.5 text-slate-700" aria-hidden="true" />}
              </div>
            ))}
          </div>
        )}
        <div className="ml-auto shrink-0">
          {open
            ? <ChevronUp   className="w-4 h-4 text-slate-400" aria-hidden="true" />
            : <ChevronDown className="w-4 h-4 text-slate-400" aria-hidden="true" />}
        </div>
      </button>

      <AnimatePresence initial={false}>
        {open && (
          <motion.div id="process-flow-content"
            initial={{ height:0, opacity:0 }} animate={{ height:"auto", opacity:1 }}
            exit={{ height:0, opacity:0 }} transition={{ duration:0.3, ease:[0.4,0,0.2,1] }}
            style={{ overflow:"hidden" }}
          >
            <div className="border-t border-slate-700/40 grid grid-cols-5">
              {PROCESS_STAGES.map((s, i) => {
                const isActive = activeStage === s.key;
                return (
                  <button
                    key={s.key}
                    onClick={() => toggleStage(s.key)}
                    aria-pressed={isActive}
                    aria-label={isActive ? `Clear ${s.key} filter` : `Filter by ${s.key} stage`}
                    className={[
                      "p-3 flex flex-col gap-1.5 text-left transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-inset",
                      i < 4 ? "border-r border-slate-700/30" : "",
                      isActive
                        ? "bg-white/5"
                        : "hover:bg-white/3",
                    ].join(" ")}
                    style={isActive ? { boxShadow:`inset 0 0 0 1.5px ${s.color}55` } : undefined}
                  >
                    {/* Header row */}
                    <div className="flex items-center justify-between gap-1">
                      <div className="flex items-center gap-1.5 min-w-0">
                        <div className={`w-2 h-2 rounded-full shrink-0 transition-all ${isActive ? "scale-125" : ""}`}
                          style={{ background: s.color }} aria-hidden="true" />
                        <span className="text-xs font-bold text-white truncate">{s.key}</span>
                      </div>
                      {isActive && (
                        <span className="text-[10px] font-semibold px-1.5 py-0.5 rounded-full shrink-0"
                          style={{ background: s.color + "30", color: s.color }}>
                          Active
                        </span>
                      )}
                    </div>

                    {/* Count */}
                    <div className="text-2xl font-bold leading-none" style={{ color: s.color }}
                      aria-label={`${counts[s.key]} transactions`}>
                      {counts[s.key]}
                    </div>

                    {/* Description */}
                    <p className="text-[11px] text-slate-400 leading-tight flex-1">{s.desc}</p>

                    {/* CTA */}
                    <div className={`flex items-center gap-0.5 text-[11px] mt-0.5 transition-colors ${
                      isActive ? "font-semibold" : "text-slate-500"
                    }`} style={isActive ? { color: s.color } : {}}>
                      {isActive
                        ? <><X className="w-2.5 h-2.5" aria-hidden="true" /> Clear filter</>
                        : counts[s.key] > 0
                          ? <>View {counts[s.key]} <ArrowRight className="w-2.5 h-2.5" aria-hidden="true" /></>
                          : s.cta
                            ? <>{s.cta} <ArrowRight className="w-2.5 h-2.5" aria-hidden="true" /></>
                            : null}
                    </div>
                  </button>
                );
              })}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </section>
  );
}

// ── FilterPanel ───────────────────────────────────────────────────────────────
// Layout driven by Pendo usage data (30-day feature events):
//   Always visible: Date Type (7,455) · Start/End Date (2,229 / 1,241) · My Items (244)
//   More Filters:   Status · Payment Type (363) · Legal Entity · Trn# · Beneficiary
//   Advanced:       Netting (2 events each — de-prioritised behind accordion)
//   Removed:        Rows per Page (42 events — table footer only)
const DEFAULT_FILTERS = {
  dateType:"Trn. Date", dateFrom:"2026-02-24", dateTo:"2026-02-24",
  quickSearch:"", txnNum:"", payee:"", status:"", txnType:"", legalEntity:"",
  netting:"All", showMyItems:false, rowsPerPage:"25", preset:"", processStage:"",
};
type Filters = typeof DEFAULT_FILTERS;

function FilterPanel({ filters, setFilters }: {
  filters: Filters; setFilters: (f: Filters) => void;
}) {
  const [moreOpen, setMoreOpen] = useState(false);
  const [advOpen,  setAdvOpen]  = useState(false);

  // Esc closes the More Filters panel (implements the keyboard hint shown in the footer)
  useEffect(() => {
    if (!moreOpen) return;
    const handler = (e: KeyboardEvent) => { if (e.key === "Escape") setMoreOpen(false); };
    document.addEventListener("keydown", handler);
    return () => document.removeEventListener("keydown", handler);
  }, [moreOpen]);

  // Count active secondary filters (excludes date + quickSearch + showMyItems)
  const secondaryCount = [filters.status, filters.txnType, filters.legalEntity, filters.payee, filters.txnNum, filters.processStage].filter(Boolean).length;
  const hasAnyClear    = !!(filters.quickSearch || secondaryCount || !filters.showMyItems ||
                            filters.dateFrom !== DEFAULT_FILTERS.dateFrom || filters.dateTo !== DEFAULT_FILTERS.dateTo);

  const clearAll = () => setFilters(DEFAULT_FILTERS);

  const quickDate = (r: string) => {
    const map: Record<string,[string,string]> = {
      today:["2026-02-24","2026-02-24"], week:["2026-02-17","2026-02-24"],
      month:["2026-02-01","2026-02-24"], qtr:["2026-01-01","2026-02-24"],
    };
    const [from, to] = map[r];
    setFilters({ ...filters, preset:r, dateFrom:from, dateTo:to });
  };

  const inp = "w-full bg-[#0f1e35] border border-slate-700/60 text-slate-200 text-sm rounded px-2.5 py-1.5 focus:outline-none focus:ring-2 focus:ring-teal-500/50 focus:border-teal-500/50 placeholder:text-slate-400 transition-all";

  return (
    <section aria-label="Filters" className="bg-[#162a47] border border-slate-700/50 rounded-xl overflow-hidden">

      {/* ── Always-visible primary bar ────────────────────────────────────────── */}
      {/* Date controls are surfaced here because they account for ~80% of filter  */}
      {/* interactions (Pendo). Users should never need to expand a panel just to  */}
      {/* change a date.                                                            */}
      <div className="flex flex-wrap items-center gap-2 px-3 py-2.5">

        {/* Quick Search */}
        <div className="relative shrink-0">
          <Search className="absolute left-2 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-slate-400" aria-hidden="true" />
          <input
            value={filters.quickSearch}
            placeholder="Search ID or beneficiary…"
            aria-label="Quick search transactions"
            onChange={e => setFilters({ ...filters, quickSearch:e.target.value })}
            className="bg-[#0f1e35] border border-slate-700/60 text-slate-200 text-sm rounded pl-7 pr-3 py-1.5 w-48 focus:outline-none focus:ring-2 focus:ring-teal-500/50 placeholder:text-slate-400 transition-all"
          />
        </div>

        <div className="w-px h-5 bg-slate-700/50 shrink-0" aria-hidden="true" />

        {/* Date Type — #1 interacted feature (7,455 events) */}
        <select
          value={filters.dateType}
          onChange={e => setFilters({ ...filters, dateType:e.target.value })}
          aria-label="Date type"
          className="bg-[#0f1e35] border border-slate-700/60 text-slate-200 text-sm rounded px-2.5 py-1.5 shrink-0 focus:outline-none focus:ring-2 focus:ring-teal-500/50 cursor-pointer transition-all">
          <option>Trn. Date</option>
          <option>Value Date</option>
          <option>Entry Date</option>
        </select>

        {/* Start Date → End Date — #3 & #4 by events */}
        <div className="flex items-center gap-1.5 shrink-0">
          <input type="date" value={filters.dateFrom} aria-label="Start date"
            onChange={e => setFilters({ ...filters, dateFrom:e.target.value, preset:"" })}
            className="bg-[#0f1e35] border border-slate-700/60 text-slate-200 text-sm rounded px-2.5 py-1.5 w-36 focus:outline-none focus:ring-2 focus:ring-teal-500/50 transition-all" />
          <ArrowRight className="w-3 h-3 text-slate-400 shrink-0" aria-hidden="true" />
          <input type="date" value={filters.dateTo} aria-label="End date"
            onChange={e => setFilters({ ...filters, dateTo:e.target.value, preset:"" })}
            className="bg-[#0f1e35] border border-slate-700/60 text-slate-200 text-sm rounded px-2.5 py-1.5 w-36 focus:outline-none focus:ring-2 focus:ring-teal-500/50 transition-all" />
        </div>

        {/* Quick-date preset — single select replaces 4 buttons; shows active preset */}
        <select
          value={filters.preset}
          onChange={e => { if (e.target.value) quickDate(e.target.value); }}
          aria-label="Date range preset"
          className="bg-[#0f1e35] border border-slate-700/60 text-slate-200 text-sm rounded px-2.5 py-1.5 shrink-0 focus:outline-none focus:ring-2 focus:ring-teal-500/50 cursor-pointer transition-all">
          <option value="">Preset…</option>
          <option value="today">Today</option>
          <option value="week">This Week</option>
          <option value="month">This Month</option>
          <option value="qtr">This Quarter</option>
        </select>

        <div className="w-px h-5 bg-slate-700/50 shrink-0" aria-hidden="true" />

        {/* My Items toggle — #6 by events (244), meaningful daily workflow shortcut */}
        <div
          role="switch" aria-checked={filters.showMyItems} tabIndex={0}
          aria-label="Show only items I can approve"
          onClick={() => setFilters({ ...filters, showMyItems:!filters.showMyItems })}
          onKeyDown={e => (e.key==="Enter"||e.key===" ") && setFilters({ ...filters, showMyItems:!filters.showMyItems })}
          className="flex items-center gap-2 cursor-pointer shrink-0 focus:outline-none focus:ring-2 focus:ring-teal-500/50 rounded px-1">
          <div className={`w-8 h-4 rounded-full relative transition-colors ${filters.showMyItems ? "bg-teal-500" : "bg-slate-700"}`}>
            <div className={`w-3 h-3 rounded-full bg-white absolute top-0.5 transition-all shadow ${filters.showMyItems ? "left-4" : "left-0.5"}`} />
          </div>
          <span className="text-xs text-slate-300 whitespace-nowrap select-none">My Items</span>
        </div>

        {/* Right-side actions */}
        <div className="flex items-center gap-2 shrink-0 ml-auto">

          {/* Secondary filter summary chips — shown when More Filters is collapsed */}
          {secondaryCount > 0 && !moreOpen && (
            <div className="flex items-center gap-1" aria-label={`${secondaryCount} additional filter${secondaryCount>1?"s":""} active`}>
              {([
                filters.status    && `Status: ${filters.status}`,
                filters.txnType   && `Type: ${filters.txnType}`,
                filters.legalEntity && filters.legalEntity.replace("GTreasury ",""),
              ] as (string|false)[]).filter(Boolean).slice(0,2).map((c, i) => (
                <span key={i} className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-xs font-medium bg-slate-700/60 border border-slate-600/60 text-slate-200 shrink-0">
                  {c}
                </span>
              ))}
              {secondaryCount > 2 && (
                <span className="text-xs text-slate-400">+{secondaryCount-2}</span>
              )}
            </div>
          )}

          {/* More Filters — badge shows count of active secondary filters */}
          <button
            onClick={() => setMoreOpen(o => !o)}
            aria-expanded={moreOpen}
            aria-controls="more-filters-panel"
            className={`flex items-center gap-1.5 px-2.5 py-1.5 min-h-[28px] rounded-lg border text-xs font-semibold transition-all focus:outline-none focus:ring-2 focus:ring-teal-500/50
              ${moreOpen || secondaryCount > 0
                ? "bg-teal-500/15 border-teal-500/35 text-teal-300"
                : "bg-[#1a3050] border-slate-700/60 text-slate-300 hover:border-teal-500/30 hover:text-teal-400"}`}>
            <SlidersHorizontal className="w-3 h-3" aria-hidden="true" />
            More filters
            {secondaryCount > 0 && (
              <span className="w-4 h-4 rounded-full bg-teal-500 text-white text-[10px] font-bold flex items-center justify-center leading-none">
                {secondaryCount}
              </span>
            )}
            {moreOpen
              ? <ChevronUp   className="w-3 h-3" aria-hidden="true" />
              : <ChevronDown className="w-3 h-3" aria-hidden="true" />}
          </button>

          {hasAnyClear && (
            <button onClick={clearAll} aria-label="Clear all filters"
              className="text-xs text-slate-400 hover:text-rose-400 flex items-center gap-0.5 transition-colors px-2 py-1 min-h-[24px] rounded focus:outline-none focus:ring-2 focus:ring-teal-500/50">
              <X className="w-3 h-3" aria-hidden="true" /> Clear
            </button>
          )}
        </div>
      </div>

      {/* ── More Filters panel ─────────────────────────────────────────────────── */}
      <AnimatePresence initial={false}>
        {moreOpen && (
          <motion.div
            id="more-filters-panel"
            initial={{ height:0, opacity:0 }} animate={{ height:"auto", opacity:1 }}
            exit={{ height:0, opacity:0 }} transition={{ duration:0.2, ease:"easeInOut" }}
            style={{ overflow:"hidden" }}
          >
            <div className="border-t border-slate-700/40 px-4 pt-3 pb-3 space-y-3">

              {/* Secondary filters — ordered by Pendo usage */}
              <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
                {/* Status (part of overall filter usage) */}
                <div>
                  <label htmlFor="filter-status" className="block text-[11px] uppercase tracking-wider text-slate-400 font-semibold mb-1">Status</label>
                  <select id="filter-status" value={filters.status} onChange={e => setFilters({ ...filters, status:e.target.value })} className={inp + " cursor-pointer"}>
                    <option value="">All statuses</option>
                    <option>Draft</option>
                    <option>Under Review</option>
                    <option>Needs Approval</option>
                    <option>Ready to Extract</option>
                    <option>Extracted</option>
                    <option>Confirmed</option>
                    <option>Approved</option>
                    <option>Failed</option>
                    <option>Void</option>
                    <option>On Hold</option>
                    <option>Escalated</option>
                    <option>Rejected</option>
                  </select>
                </div>
                {/* Payment Type — 363 events (#5) */}
                <div>
                  <label htmlFor="filter-txnType" className="block text-[11px] uppercase tracking-wider text-slate-400 font-semibold mb-1">Payment Type</label>
                  <select id="filter-txnType" value={filters.txnType} onChange={e => setFilters({ ...filters, txnType:e.target.value })} className={inp + " cursor-pointer"}>
                    <option value="">All types</option>
                    <option>Wire</option><option>ACH</option><option>RLUSD</option><option>USDC</option>
                  </select>
                </div>
                <div>
                  <label htmlFor="filter-legalEntity" className="block text-[11px] uppercase tracking-wider text-slate-400 font-semibold mb-1">Legal Entity</label>
                  <select id="filter-legalEntity" value={filters.legalEntity} onChange={e => setFilters({ ...filters, legalEntity:e.target.value })} className={inp + " cursor-pointer"}>
                    <option value="">All entities</option>
                    <option>GTreasury US LLC</option><option>GTreasury EU GmbH</option><option>GTreasury UK Ltd</option>
                  </select>
                </div>
                <div>
                  <label htmlFor="filter-txnNum" className="block text-[11px] uppercase tracking-wider text-slate-400 font-semibold mb-1">Trn. Number</label>
                  <div className="relative">
                    <input id="filter-txnNum" value={filters.txnNum} placeholder="e.g. PMT-0029410"
                      onChange={e => setFilters({ ...filters, txnNum:e.target.value })}
                      className={inp} />
                    {filters.txnNum && (
                      <button onClick={() => setFilters({ ...filters, txnNum:"" })}
                        aria-label="Clear transaction number"
                        className="absolute right-1.5 top-1/2 -translate-y-1/2 p-1.5 min-w-[28px] min-h-[28px] flex items-center justify-center text-slate-400 hover:text-slate-200 rounded focus:outline-none focus:ring-2 focus:ring-teal-500/50">
                        <X className="w-3 h-3" aria-hidden="true" />
                      </button>
                    )}
                  </div>
                </div>
                <div>
                  <label htmlFor="filter-payee" className="block text-[11px] uppercase tracking-wider text-slate-400 font-semibold mb-1">Beneficiary</label>
                  <div className="relative">
                    <input id="filter-payee" value={filters.payee} placeholder="Beneficiary name…"
                      onChange={e => setFilters({ ...filters, payee:e.target.value })}
                      className={inp} />
                    {filters.payee && (
                      <button onClick={() => setFilters({ ...filters, payee:"" })}
                        aria-label="Clear beneficiary filter"
                        className="absolute right-1.5 top-1/2 -translate-y-1/2 p-1.5 min-w-[28px] min-h-[28px] flex items-center justify-center text-slate-400 hover:text-slate-200 rounded focus:outline-none focus:ring-2 focus:ring-teal-500/50">
                        <X className="w-3 h-3" aria-hidden="true" />
                      </button>
                    )}
                  </div>
                </div>
              </div>

              {/* Advanced — Netting de-prioritised (2 events each in Pendo data) */}
              <div>
                <button
                  onClick={() => setAdvOpen(o => !o)}
                  aria-expanded={advOpen}
                  className="flex items-center gap-1.5 text-[11px] uppercase tracking-wider text-slate-400 hover:text-slate-300 font-semibold transition-colors focus:outline-none focus:ring-2 focus:ring-teal-500/50 rounded px-1 py-0.5">
                  <ChevronRight className={`w-3 h-3 transition-transform ${advOpen ? "rotate-90" : ""}`} aria-hidden="true" />
                  Advanced
                </button>
                <AnimatePresence initial={false}>
                  {advOpen && (
                    <motion.div
                      initial={{ height:0, opacity:0 }} animate={{ height:"auto", opacity:1 }}
                      exit={{ height:0, opacity:0 }} transition={{ duration:0.15 }}
                      style={{ overflow:"hidden" }}
                    >
                      <fieldset className="border-0 p-0 m-0 mt-2">
                        <legend className="block text-[11px] uppercase tracking-wider text-slate-400 font-semibold mb-1.5">Netting</legend>
                        <div className="flex items-center gap-4">
                          {["All","Not Netted","Netted Only"].map(n => (
                            <label key={n} className="flex items-center gap-1.5 cursor-pointer">
                              <input type="radio" name="netting" value={n} checked={filters.netting === n}
                                onChange={() => setFilters({ ...filters, netting:n })}
                                className="w-3.5 h-3.5 accent-teal-500" />
                              <span className="text-xs text-slate-300 whitespace-nowrap">{n}</span>
                            </label>
                          ))}
                        </div>
                      </fieldset>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>

              {/* Footer */}
              <div className="flex items-center justify-between pt-2 border-t border-slate-700/40">
                <div className="flex items-center gap-3">
                  <select value={filters.preset} onChange={e => {
                    const p = e.target.value;
                    if (p==="daily")   setFilters({ ...filters, preset:p, status:"Needs Approval", showMyItems:true });
                    else if (p==="overdue") setFilters({ ...filters, preset:p, status:"Needs Approval" });
                    else setFilters({ ...filters, preset:p });
                  }} className="bg-[#0f1e35] border border-slate-700/50 text-slate-400 text-xs rounded px-2.5 py-1.5 focus:outline-none focus:ring-2 focus:ring-teal-500/50 cursor-pointer"
                    aria-label="Saved filter presets">
                    <option value="">💾 Saved Searches</option>
                    <option value="daily">My Daily Queue</option>
                    <option value="overdue">Overdue Only</option>
                  </select>
                  <span className="text-[11px] text-slate-300 hidden md:inline">
                    <kbd className="px-1 py-0.5 rounded bg-slate-800 border border-slate-700 font-mono text-[10px] text-slate-300">Enter</kbd>
                    {" "}to apply ·{" "}
                    <kbd className="px-1 py-0.5 rounded bg-slate-800 border border-slate-700 font-mono text-[10px] text-slate-300">Esc</kbd>
                    {" "}to close
                  </span>
                </div>
                <div className="flex items-center gap-2">
                  <button onClick={() => setMoreOpen(false)}
                    className="px-4 py-1.5 text-xs text-slate-300 border border-slate-700/60 rounded hover:text-white hover:border-slate-600 transition-colors focus:outline-none focus:ring-2 focus:ring-teal-500/50">
                    Close
                  </button>
                  <button onClick={() => setMoreOpen(false)}
                    className="flex items-center gap-1.5 px-5 py-1.5 rounded-lg bg-gradient-to-r from-teal-600 to-blue-700 hover:from-teal-500 hover:to-blue-600 text-white font-bold text-xs shadow-md transition-all focus:outline-none focus:ring-2 focus:ring-teal-400 focus:ring-offset-1 focus:ring-offset-transparent">
                    <Search className="w-3.5 h-3.5" aria-hidden="true" /> Apply
                  </button>
                </div>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </section>
  );
}

// ── PaymentSummary ────────────────────────────────────────────────────────────
type SummaryRowId = "approval-needed" | "pending-fraud-review" | "ready-to-extract" | "extracted" | "completed" | "failed" | "void";

interface SummaryRow {
  id: SummaryRowId;
  label: string;
  statusFilter: string;
  Icon: React.ElementType;
  iconColor: string;
  iconBg: string;
  debits: number;
  credits: number;
  amount: number;
  count: number;
}

const SUMMARY_ROWS: SummaryRow[] = [
  { id:"approval-needed",      label:"Approval Needed",      statusFilter:"Needs Approval",   Icon:Clock,       iconColor:"text-amber-400",   iconBg:"bg-amber-500/15",   debits:14350.75,       credits:0,            amount:14350.75,       count:11  },
  { id:"pending-fraud-review", label:"Pending Fraud Review", statusFilter:"Under Review",     Icon:ShieldAlert, iconColor:"text-rose-400",    iconBg:"bg-rose-500/15",    debits:1298550.00,     credits:0,            amount:1298550.00,     count:10  },
  { id:"ready-to-extract",     label:"Ready to Extract",     statusFilter:"Ready to Extract", Icon:ArrowUpRight,iconColor:"text-teal-400",    iconBg:"bg-teal-500/15",    debits:5234182.50,     credits:1128640.00,   amount:6362822.50,     count:47  },
  { id:"extracted",            label:"Extracted",            statusFilter:"Extracted",        Icon:CheckCircle2,iconColor:"text-blue-400",    iconBg:"bg-blue-500/15",    debits:37807355.65,    credits:22170426.91,  amount:59977782.56,    count:275 },
  { id:"confirmed",            label:"Confirmed",            statusFilter:"Confirmed",        Icon:CheckCircle2,iconColor:"text-indigo-400",  iconBg:"bg-indigo-500/15",  debits:28450120.33,    credits:15280445.12,  amount:43730565.45,    count:189 },
  { id:"completed",            label:"Completed",            statusFilter:"Approved",         Icon:CheckCircle2,iconColor:"text-emerald-400", iconBg:"bg-emerald-500/15", debits:81838589.67,    credits:18933320.49,  amount:100771910.16,   count:238 },
  { id:"failed",               label:"Failed",               statusFilter:"Failed",           Icon:X,           iconColor:"text-red-400",     iconBg:"bg-red-500/15",     debits:2882646.73,     credits:1630339.30,   amount:4512986.03,     count:172 },
  { id:"void",                 label:"Void",                 statusFilter:"Void",             Icon:Ban,         iconColor:"text-slate-400",   iconBg:"bg-slate-700/50",   debits:44058587.78,    credits:4067933.40,   amount:48126521.18,    count:96  },
];

function PaymentSummary({ filters, setFilters }: { filters: Filters; setFilters: (f: Filters) => void }) {
  const [open, setOpen]       = useState(true);
  const [activeId, setActiveId] = useState<SummaryRowId | null>(null);

  const fmt = (n: number) => n.toLocaleString("en-US", { minimumFractionDigits:2, maximumFractionDigits:2 });

  const displayRows  = activeId ? SUMMARY_ROWS.filter(r => r.id === activeId) : SUMMARY_ROWS;
  const totalCount   = displayRows.reduce((s, r) => s + r.count, 0);
  const totalDebits  = displayRows.reduce((s, r) => s + r.debits, 0);
  const totalCredits = displayRows.reduce((s, r) => s + r.credits, 0);
  const totalAmount  = displayRows.reduce((s, r) => s + r.amount, 0);

  const handleRowClick = (row: SummaryRow) => {
    setActiveId(row.id);
    if (row.statusFilter) setFilters({ ...filters, status: row.statusFilter });
  };

  const handleClear = () => {
    setActiveId(null);
    setFilters({ ...filters, status: "" });
  };

  return (
    <section aria-label="Payment summary" className="bg-[#162a47] border border-slate-700/50 rounded-xl overflow-hidden">

      {/* Header */}
      <div className="flex items-center gap-3 px-4 py-2.5">
        <button
          onClick={() => setOpen(o => !o)}
          aria-expanded={open}
          aria-controls="payment-summary-content"
          className="flex items-center gap-2 flex-1 hover:bg-white/2 transition-colors duration-200 select-none text-left rounded focus:outline-none focus:ring-2 focus:ring-teal-500/50">
          <span className="text-base font-semibold text-white shrink-0">Payment Summary</span>
          <span className="text-xs text-slate-400 font-normal ml-1">
            {totalCount.toLocaleString()} transactions · {displayRows.length} status{displayRows.length !== 1 ? "es" : ""}
          </span>
          <div className="ml-auto shrink-0">
            {open
              ? <ChevronUp   className="w-4 h-4 text-slate-400" aria-hidden="true" />
              : <ChevronDown className="w-4 h-4 text-slate-400" aria-hidden="true" />}
          </div>
        </button>
        {activeId && (
          <button onClick={handleClear}
            className="shrink-0 text-xs text-teal-400 hover:text-teal-300 border border-teal-500/30 hover:border-teal-400/50 px-2.5 py-1 rounded-lg transition-colors focus:outline-none focus:ring-2 focus:ring-teal-500/50">
            Show all statuses
          </button>
        )}
      </div>

      <AnimatePresence initial={false}>
        {open && (
          <motion.div id="payment-summary-content"
            initial={{ height:0, opacity:0 }} animate={{ height:"auto", opacity:1 }}
            exit={{ height:0, opacity:0 }} transition={{ duration:0.3, ease:[0.4,0,0.2,1] }}
            style={{ overflow:"hidden" }}
          >
            <div className="border-t border-slate-700/40 overflow-x-auto">
              <table className="w-full text-left border-collapse text-sm" aria-label="Payment status summary">
                <thead>
                  <tr className="bg-[#0d1c30] border-b border-slate-700/60">
                    <th scope="col" className="px-4 py-2.5 text-[11px] uppercase tracking-wider text-slate-400 font-semibold w-[260px]">Status</th>
                    <th scope="col" className="px-4 py-2.5 text-[11px] uppercase tracking-wider text-slate-400 font-semibold text-right">Operative Debits</th>
                    <th scope="col" className="px-4 py-2.5 text-[11px] uppercase tracking-wider text-slate-400 font-semibold text-right">Operative Credits</th>
                    <th scope="col" className="px-4 py-2.5 text-[11px] uppercase tracking-wider text-slate-400 font-semibold text-right">Amount</th>
                    <th scope="col" className="px-4 py-2.5 text-[11px] uppercase tracking-wider text-slate-400 font-semibold text-center w-[130px]">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-700/30">
                  {displayRows.map((row) => {
                    const isActive = activeId === row.id;
                    return (
                      <tr key={row.id}
                        className={`transition-colors group ${isActive ? "bg-teal-500/5" : "hover:bg-slate-800/20"}`}>
                        <td className="px-4 py-3">
                          <button onClick={() => handleRowClick(row)}
                            aria-label={`Filter by ${row.label}`}
                            className="flex items-center gap-3 hover:opacity-90 transition-opacity focus:outline-none focus:ring-2 focus:ring-teal-500/50 rounded">
                            <div className={`w-8 h-8 rounded-lg flex items-center justify-center shrink-0 ${row.iconBg}`}>
                              <row.Icon className={`w-4 h-4 ${row.iconColor}`} aria-hidden="true" />
                            </div>
                            <span className="text-sm font-medium text-slate-200 leading-tight">
                              {row.label}
                              <span className="ml-1.5 text-xs text-slate-400 font-normal">({row.count.toLocaleString()})</span>
                            </span>
                          </button>
                        </td>
                        <td className="px-4 py-3 text-right font-medium tabular-nums text-sm text-slate-300">{fmt(row.debits)}</td>
                        <td className="px-4 py-3 text-right font-medium tabular-nums text-sm text-slate-300">{fmt(row.credits)}</td>
                        <td className="px-4 py-3 text-right font-semibold tabular-nums text-sm text-slate-200">{fmt(row.amount)}</td>
                        <td className="px-4 py-3 text-center">
                          <button onClick={() => handleRowClick(row)}
                            aria-label={`View details for ${row.label}`}
                            className="text-xs text-slate-400 hover:text-teal-400 opacity-40 group-hover:opacity-100 transition-all focus:outline-none focus:ring-2 focus:ring-teal-500/50 focus:opacity-100 rounded px-2 py-1">
                            View details →
                          </button>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
                <tfoot>
                  <tr className="bg-[#0d1c30] border-t-2 border-slate-700/60">
                    <td className="px-4 py-3 font-bold text-white">
                      <div className="pl-11">Total</div>
                    </td>
                    <td className="px-4 py-3 text-right font-bold tabular-nums text-sm text-slate-200">{fmt(totalDebits)}</td>
                    <td className="px-4 py-3 text-right font-bold tabular-nums text-sm text-slate-200">{fmt(totalCredits)}</td>
                    <td className="px-4 py-3 text-right font-bold tabular-nums text-sm text-slate-200">{fmt(totalAmount)}</td>
                    <td />
                  </tr>
                </tfoot>
              </table>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </section>
  );
}

// ── ResultsTable ──────────────────────────────────────────────────────────────
const ALL_COLS = {
  risk:"Risk", trnNum:"Trn. Number", trnDate:"Trn. Date", amount:"Amount",
  payee:"Beneficiary", operativeAcct:"Operative Account", instType:"Type",
  valDate:"Value Date", offsetNum:"Account No.",
};
const DEFAULT_COLS = { risk:true, trnNum:true, trnDate:true, amount:true, payee:true, operativeAcct:true, instType:true, valDate:false, offsetNum:false };

type FeatureFlags = { rlusdStrip: boolean; stablecoinRail: boolean; selectPaymentRail: boolean; riskColumn: boolean };
function ResultsTable({ txns, tray, filters, setFilters, featureFlags = { rlusdStrip: true, stablecoinRail: true, selectPaymentRail: true, riskColumn: true } }: { txns: Txn[]; tray: TrayFilter; filters: Filters; setFilters: (f: Filters) => void; featureFlags?: FeatureFlags }) {
  const [selected, setSelected]           = useState<string[]>([]);
  const [expandedRow, setExpandedRow]     = useState<string | null>(null);
  const [showColPicker, setShowColPicker] = useState(false);
  const colPickerRef = useRef<HTMLDivElement>(null);
  const [showFraudGate, setShowFraudGate] = useState(false);
  const [showVoid, setShowVoid]           = useState(false);
  const [paymentRailTxn, setPaymentRailTxn] = useState<Txn | null>(null);
  const [attachment, setAttachment]         = useState<TxnAttachment | null>(null);
  const [rlusdOnly, setRlusdOnly]           = useState(false);
  const paymentRailDialogRef               = useRef<HTMLDivElement>(null);
  useFocusTrap(!!paymentRailTxn, paymentRailDialogRef);
  const fraudGateDialogRef               = useRef<HTMLDivElement>(null);
  const voidDialogRef                    = useRef<HTMLDivElement>(null);
  useFocusTrap(showFraudGate, fraudGateDialogRef);
  useFocusTrap(showVoid, voidDialogRef);
  const [refreshing, setRefreshing]       = useState(false);
  const [sortCol, setSortCol]             = useState("urgency");
  const [sortDir, setSortDir]             = useState<"asc"|"desc">("desc");
  const [cols, setCols]                   = useState(DEFAULT_COLS);
  const effectiveCols = { ...cols, risk: cols.risk && featureFlags.riskColumn };
  const [page, setPage]                   = useState(1);
  const [tableSearch, setTableSearch]     = useState("");

  const rowsPerPage = parseInt(filters.rowsPerPage) || 25;

  // Apply all filters
  const filtered = txns.filter(t => {
    const q = filters.quickSearch.toLowerCase();
    if (q && !t.id.toLowerCase().includes(q) && !t.payee.toLowerCase().includes(q)) return false;
    const ts = tableSearch.toLowerCase();
    if (ts && !t.id.toLowerCase().includes(ts) && !t.payee.toLowerCase().includes(ts)) return false;
    if (filters.status       && t.status       !== filters.status)                           return false;
    if (filters.processStage && t.processStage !== filters.processStage)                    return false;
    if (filters.txnType      && t.type         !== filters.txnType)                         return false;
    if (filters.legalEntity && t.legalEntity !== filters.legalEntity)                       return false;
    if (filters.payee     && !t.payee.toLowerCase().includes(filters.payee.toLowerCase()))  return false;
    if (filters.txnNum    && !t.id.toLowerCase().includes(filters.txnNum.toLowerCase()))    return false;
    if (filters.showMyItems && t.approver !== "A. Pacheco")                                 return false;
    if (rlusdOnly && !t.rlusdEligible)                                                     return false;
    if (tray === "overdue")   return t.overdue;
    if (tray === "high-risk") return t.risk >= 70;
    return true;
  });

  const sorted = [...filtered].sort((a, b) => {
    if (sortCol === "urgency")      return ((b.overdue?200:0)+b.risk) - ((a.overdue?200:0)+a.risk);
    if (sortCol === "amount")       return sortDir==="desc" ? b.amount-a.amount : a.amount-b.amount;
    if (sortCol === "risk")         return sortDir==="desc" ? b.risk-a.risk : a.risk-b.risk;
    const strSort = (av: string, bv: string) => sortDir==="asc" ? av.localeCompare(bv) : bv.localeCompare(av);
    if (sortCol === "trnNum")       return strSort(a.id, b.id);
    if (sortCol === "trnDate")      return strSort(a.trnDate, b.trnDate);
    if (sortCol === "valDate")      return strSort(a.valDate, b.valDate);
    if (sortCol === "payee")        return strSort(a.payee, b.payee);
    if (sortCol === "operativeAcct")return strSort(a.operativeAcct, b.operativeAcct);
    if (sortCol === "instType")     return strSort(a.instType, b.instType);
    if (sortCol === "offsetNum")    return strSort(a.offsetNumber, b.offsetNumber);
    return 0;
  });

  const totalPages = Math.max(1, Math.ceil(sorted.length / rowsPerPage));
  const pageRows   = sorted.slice((page-1)*rowsPerPage, page*rowsPerPage);

  // Reset page when filters change
  useEffect(() => { setPage(1); }, [filters, tray]);

  // Close column picker on outside click or Escape
  useEffect(() => {
    if (!showColPicker) return;
    const onMouse = (e: MouseEvent) => {
      if (colPickerRef.current && !colPickerRef.current.contains(e.target as Node)) {
        setShowColPicker(false);
      }
    };
    const onKey = (e: KeyboardEvent) => { if (e.key === "Escape") setShowColPicker(false); };
    document.addEventListener("mousedown", onMouse);
    document.addEventListener("keydown", onKey);
    return () => {
      document.removeEventListener("mousedown", onMouse);
      document.removeEventListener("keydown", onKey);
    };
  }, [showColPicker]);

  // Esc closes Hold / Reject / FraudGate modals
  useEffect(() => {
    if (!showVoid && !showFraudGate) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") { setShowVoid(false); setShowFraudGate(false); }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [showVoid, showFraudGate]);

  const visibleColCount = Object.values(cols).filter(Boolean).length;
  const totalColSpan    = visibleColCount + 3; // +1 chevron, +1 checkbox, +1 actions

  const allSel    = pageRows.length > 0 && pageRows.every(t => selected.includes(t.id));
  const toggleAll = () => setSelected(allSel ? [] : pageRows.map(t => t.id));
  const toggleRow = (id: string) => setSelected(s => s.includes(id) ? s.filter(x => x!==id) : [...s, id]);
  const toggleExpand = (id: string) => setExpandedRow(e => e===id ? null : id);

  const selTxns          = txns.filter(t => selected.includes(t.id));
  const flaggedInSel     = selTxns.filter(t => t.risk >= 70).length;

  const handleApprove = () => {
    if (flaggedInSel > 0) setShowFraudGate(true);
    else setSelected([]);  // no flagged items — approve directly, clear selection
  };
  const handleRefresh = () => { setRefreshing(true); setTimeout(() => setRefreshing(false), 1200); };
  const handleSort    = (col: string) => {
    if (sortCol===col) setSortDir(d => d==="asc"?"desc":"asc");
    else { setSortCol(col); setSortDir("desc"); }
  };

  const th       = "px-3 py-2.5 text-[11px] uppercase tracking-wider text-slate-400 font-semibold text-left whitespace-nowrap select-none cursor-pointer hover:text-slate-200 transition-colors focus:outline-none focus:ring-inset focus:ring-2 focus:ring-teal-500/50";
  const thStatic = "px-3 py-2.5 text-[11px] uppercase tracking-wider text-slate-400 font-semibold text-left whitespace-nowrap select-none";
  const td = "px-3 py-3";

  return (
    <section aria-label="Transaction results">
      {/* Section heading row */}
      <div className="flex items-center px-4 py-3 bg-[#162a47] border border-b border-slate-700/50 rounded-t-xl">
        <h2 className="text-base font-semibold text-white">Transaction Details</h2>
      </div>
      {/* Toolbar */}
      <div className="flex items-center justify-between px-3 py-2 bg-[#162a47] border-x border-b-0 border-slate-700/50">
        <div className="flex items-center gap-2 min-h-[32px]">
          {selected.length > 0 ? (
            <div className="flex items-center gap-2" role="toolbar" aria-label="Bulk actions">
              <span className="text-xs text-slate-300 font-medium">{selected.length} selected</span>
              <button onClick={handleApprove}
                className="flex items-center gap-1 px-3 py-1.5 min-h-[28px] rounded-lg text-xs font-bold bg-emerald-600 hover:bg-emerald-500 text-white transition-colors focus:outline-none focus:ring-2 focus:ring-emerald-400 focus:ring-offset-1 focus:ring-offset-transparent">
                <CheckCircle2 className="w-3.5 h-3.5" aria-hidden="true" /> Approve
              </button>
              <button onClick={() => setShowVoid(true)}
                className="flex items-center gap-1 px-3 py-1.5 min-h-[28px] rounded-lg text-xs font-bold bg-rose-500/20 hover:bg-rose-500/30 text-rose-300 border border-rose-500/30 transition-colors focus:outline-none focus:ring-2 focus:ring-rose-400 focus:ring-offset-1 focus:ring-offset-transparent">
                <Trash2 className="w-3.5 h-3.5" aria-hidden="true" /> Reject
              </button>
              <button onClick={() => setSelected([])} aria-label="Clear selection"
                className="p-1.5 min-w-[24px] min-h-[24px] text-slate-400 hover:text-slate-300 transition-colors rounded focus:outline-none focus:ring-2 focus:ring-teal-500/50">
                <X className="w-3.5 h-3.5" aria-hidden="true" />
              </button>
            </div>
          ) : (
            <span className="text-xs text-slate-400 flex items-center gap-1.5">
              <ChevronUp className="w-3 h-3 text-rose-400" aria-hidden="true" />
              {sortCol==="urgency"
                ? "Sorted by urgency · overdue first, then risk score"
                : <>{`Sorted by ${sortCol}`} · <button onClick={() => setSortCol("urgency")} className="text-teal-400 hover:underline focus:outline-none focus:ring-2 focus:ring-teal-500/50 rounded">Reset to urgency sort</button></>}
            </span>
          )}
        </div>

        <div className="flex items-center gap-2">
          <div className="relative">
            <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-slate-400 pointer-events-none" aria-hidden="true" />
            <input
              value={tableSearch}
              onChange={e => { setTableSearch(e.target.value); setPage(1); }}
              placeholder="Search transactions…"
              aria-label="Search transaction details"
              className="bg-[#0f1e35] border border-slate-700/60 text-slate-200 text-xs rounded-lg pl-8 pr-3 py-1.5 min-h-[28px] w-44 focus:outline-none focus:ring-2 focus:ring-teal-500/50 placeholder:text-slate-500 transition-all"
            />
          </div>
          <button className="flex items-center gap-1.5 px-3 py-1.5 min-h-[28px] rounded-lg text-xs text-slate-300 hover:text-white border border-slate-700/60 hover:border-slate-600 bg-[#0f1e35] transition-all focus:outline-none focus:ring-2 focus:ring-teal-500/50">
            <Download className="w-3.5 h-3.5" aria-hidden="true" /> Export
          </button>
          <div className="relative" ref={colPickerRef}>
            <button onClick={() => setShowColPicker(v => !v)} aria-expanded={showColPicker} aria-haspopup="dialog"
              className="flex items-center gap-1.5 px-3 py-1.5 min-h-[28px] rounded-lg text-xs text-slate-300 hover:text-white border border-slate-700/60 hover:border-slate-600 bg-[#0f1e35] transition-all focus:outline-none focus:ring-2 focus:ring-teal-500/50">
              <Columns3 className="w-3.5 h-3.5" aria-hidden="true" /> Columns
            </button>
            <AnimatePresence>
              {showColPicker && (
                <motion.div initial={{ opacity:0, y:-6 }} animate={{ opacity:1, y:0 }} exit={{ opacity:0, y:-6 }}
                  role="dialog" aria-label="Column visibility"
                  className="absolute right-0 top-full mt-1.5 w-48 bg-[#162a47] border border-slate-700/60 rounded-xl shadow-2xl p-3 z-30">
                  <p className="text-[11px] uppercase tracking-widest text-slate-400 font-semibold mb-2">Show / Hide Columns</p>
                  {Object.entries(ALL_COLS).map(([key, label]) => (
                    <label key={key} className="flex items-center gap-2 py-1.5 cursor-pointer group">
                      <input type="checkbox"
                        checked={cols[key as keyof typeof cols]}
                        onChange={() => setCols(c => ({ ...c, [key]:!c[key as keyof typeof c] }))}
                        className="w-4 h-4 rounded accent-teal-500" />
                      <span className="text-xs text-slate-300 group-hover:text-white transition-colors">{label}</span>
                    </label>
                  ))}
                </motion.div>
              )}
            </AnimatePresence>
          </div>
          <button onClick={handleRefresh} aria-label={refreshing ? "Refreshing data" : "Refresh data"}
            className={`flex items-center gap-1.5 px-3 py-1.5 min-h-[28px] rounded-lg text-xs text-slate-300 hover:text-white border border-slate-700/60 hover:border-slate-600 bg-[#0f1e35] transition-all focus:outline-none focus:ring-2 focus:ring-teal-500/50 ${refreshing?"opacity-60":""}`}>
            <RefreshCw className={`w-3.5 h-3.5 ${refreshing?"animate-spin":""}`} aria-hidden="true" />
            {refreshing ? "Refreshing…" : "Refresh"}
          </button>
          <span className="text-xs text-slate-400 pl-1" aria-live="polite" aria-atomic="true">
            {sorted.length===0 ? "0 results" : `${(page-1)*rowsPerPage+1}–${Math.min(page*rowsPerPage,sorted.length)} of ${sorted.length}`}
          </span>
        </div>
      </div>

      {/* RLUSD eligible strip */}
      {featureFlags.rlusdStrip && (() => {
        const rlusdCount = filtered.filter(t => t.rlusdEligible && t.status === "Needs Approval").length;
        if (rlusdCount === 0) return null;
        return (
          <div className="flex items-center justify-between px-4 py-2.5 bg-teal-500/10 border-x border-t border-teal-500/25 border-b border-b-teal-500/25">
            <div className="flex items-center gap-2.5">
              <span className="inline-flex items-center px-2 py-0.5 rounded text-[10px] font-bold text-white bg-teal-500">RLUSD</span>
              <span className="text-xs font-medium text-slate-300">
                {rlusdCount} transaction{rlusdCount !== 1 ? "s" : ""} eligible for instant RLUSD settlement
              </span>
            </div>
            <button onClick={() => setRlusdOnly(v => !v)}
              className="text-xs font-semibold text-teal-400 hover:text-teal-300 transition-colors focus:outline-none focus:ring-2 focus:ring-teal-500/50 rounded px-1">
              {rlusdOnly ? "Show all" : "View eligible only"}
            </button>
          </div>
        );
      })()}

      {/* Table */}
      <div className="bg-[#162a47] border border-slate-700/50 rounded-b-xl overflow-x-auto">
        <table className="w-full text-left border-collapse text-sm" aria-label="Transactions matching current filters">
          <caption className="sr-only">
            Transaction results — {sorted.length} transactions, sorted by {sortCol === "urgency" ? "urgency (overdue first, then risk score)" : sortCol}
          </caption>
          <thead>
            <tr className="bg-[#0d1c30] border-b border-slate-700/60">
              <th scope="col" className="pl-3 pr-1 py-2.5 w-6" aria-hidden="true" />
              <th scope="col" className="px-3 py-2.5 w-9">
                <button onClick={toggleAll}
                  aria-label={allSel ? "Deselect all transactions" : "Select all transactions on this page"}
                  aria-pressed={allSel}
                  className="p-1 min-w-[24px] min-h-[24px] flex items-center justify-center text-slate-400 hover:text-white transition-colors rounded focus:outline-none focus:ring-2 focus:ring-teal-500/50">
                  {allSel ? <CheckSquare className="w-4 h-4 text-teal-400" aria-hidden="true" /> : <Square className="w-4 h-4" aria-hidden="true" />}
                </button>
              </th>
              {effectiveCols.risk && <th scope="col" className={th} onClick={() => handleSort("risk")}
                aria-sort={sortCol==="risk" ? (sortDir==="desc" ? "descending" : "ascending") : "none"}>
                Risk {sortCol==="risk" ? <span aria-hidden="true">{sortDir==="desc"?"↓":"↑"}</span> : <span aria-hidden="true" className="opacity-30">↕</span>}
              </th>}
              {cols.trnNum        && <th scope="col" className={th} onClick={() => handleSort("trnNum")}
                aria-sort={sortCol==="trnNum" ? (sortDir==="desc" ? "descending" : "ascending") : "none"}>
                Trn. Number {sortCol==="trnNum" ? <span aria-hidden="true">{sortDir==="desc"?"↓":"↑"}</span> : <span aria-hidden="true" className="opacity-30">↕</span>}
              </th>}
              {cols.trnDate       && <th scope="col" className={th} onClick={() => handleSort("trnDate")}
                aria-sort={sortCol==="trnDate" ? (sortDir==="desc" ? "descending" : "ascending") : "none"}>
                Trn. Date {sortCol==="trnDate" ? <span aria-hidden="true">{sortDir==="desc"?"↓":"↑"}</span> : <span aria-hidden="true" className="opacity-30">↕</span>}
              </th>}
              {cols.amount        && <th scope="col" className={`${th} text-right`} onClick={() => handleSort("amount")}
                aria-sort={sortCol==="amount" ? (sortDir==="desc" ? "descending" : "ascending") : "none"}>
                Amount {sortCol==="amount" ? <span aria-hidden="true">{sortDir==="desc"?"↓":"↑"}</span> : <span aria-hidden="true" className="opacity-30">↕</span>}
              </th>}
              {cols.payee         && <th scope="col" className={th} onClick={() => handleSort("payee")}
                aria-sort={sortCol==="payee" ? (sortDir==="desc" ? "descending" : "ascending") : "none"}>
                Beneficiary {sortCol==="payee" ? <span aria-hidden="true">{sortDir==="desc"?"↓":"↑"}</span> : <span aria-hidden="true" className="opacity-30">↕</span>}
              </th>}
              {cols.operativeAcct && <th scope="col" className={th} onClick={() => handleSort("operativeAcct")}
                aria-sort={sortCol==="operativeAcct" ? (sortDir==="desc" ? "descending" : "ascending") : "none"}>
                Operative Account {sortCol==="operativeAcct" ? <span aria-hidden="true">{sortDir==="desc"?"↓":"↑"}</span> : <span aria-hidden="true" className="opacity-30">↕</span>}
              </th>}
              {cols.instType      && <th scope="col" className={th} onClick={() => handleSort("instType")}
                aria-sort={sortCol==="instType" ? (sortDir==="desc" ? "descending" : "ascending") : "none"}>
                Type {sortCol==="instType" ? <span aria-hidden="true">{sortDir==="desc"?"↓":"↑"}</span> : <span aria-hidden="true" className="opacity-30">↕</span>}
              </th>}
              {cols.valDate       && <th scope="col" className={th} onClick={() => handleSort("valDate")}
                aria-sort={sortCol==="valDate" ? (sortDir==="desc" ? "descending" : "ascending") : "none"}>
                Value Date {sortCol==="valDate" ? <span aria-hidden="true">{sortDir==="desc"?"↓":"↑"}</span> : <span aria-hidden="true" className="opacity-30">↕</span>}
              </th>}
              {cols.offsetNum     && <th scope="col" className={th} onClick={() => handleSort("offsetNum")}
                aria-sort={sortCol==="offsetNum" ? (sortDir==="desc" ? "descending" : "ascending") : "none"}>
                Account No. {sortCol==="offsetNum" ? <span aria-hidden="true">{sortDir==="desc"?"↓":"↑"}</span> : <span aria-hidden="true" className="opacity-30">↕</span>}
              </th>}
              <th scope="col" className="px-3 py-2.5 text-[11px] uppercase tracking-wider text-slate-400 font-semibold text-left whitespace-nowrap w-px">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-700/30">
            {pageRows.map((t, i) => {
              const isExpanded = expandedRow === t.id;
              const isSel      = selected.includes(t.id);
              const urgencyLabel = t.overdue ? "Overdue" : t.risk >= 70 ? "High risk" : t.risk >= 40 ? "Medium risk" : "Low risk";
              return (
                <React.Fragment key={t.id}>
                  <motion.tr
                    initial={{ opacity:0, x:-4 }} animate={{ opacity:1, x:0 }} transition={{ delay:Math.min(i*0.03, 0.36), duration:0.25 }}
                    onClick={() => toggleExpand(t.id)}
                    onKeyDown={(e) => { if (e.key==="Enter"||e.key===" ") { e.preventDefault(); toggleExpand(t.id); } }}
                    tabIndex={0}
                    aria-expanded={isExpanded}
                    aria-label={`${urgencyLabel} — ${t.payee}, ${fmtAmt(t.amount, t.cur)}, ${t.status}`}
                    className={`transition-colors cursor-pointer border-l-2 focus:outline-none focus:ring-inset focus:ring-2 focus:ring-teal-500/50
                      ${t.overdue    ? "border-l-rose-500"
                      : t.risk >= 70 ? "border-l-orange-500"
                      : t.risk >= 40 ? "border-l-amber-500/50"
                                     : "border-l-transparent"}
                      ${isExpanded ? "bg-slate-700/20" : isSel ? "bg-teal-500/5 hover:bg-teal-500/8" : "hover:bg-slate-800/20"}`}>

                    <td className="pl-3 pr-1 py-2" aria-hidden="true">
                      <ChevronRight className={`w-3.5 h-3.5 text-slate-500 transition-transform duration-200 ${isExpanded ? "rotate-90" : ""}`} />
                    </td>
                    <td className={td} onClick={e => { e.stopPropagation(); toggleRow(t.id); }}>
                      <button
                        aria-label={isSel ? `Deselect ${t.payee}` : `Select ${t.payee}`}
                        aria-pressed={isSel}
                        className="p-1 min-w-[24px] min-h-[24px] flex items-center justify-center cursor-pointer text-slate-400 hover:text-teal-400 transition-colors rounded focus:outline-none focus:ring-2 focus:ring-teal-500/50">
                        {isSel ? <CheckSquare className="w-4 h-4 text-teal-400" aria-hidden="true" /> : <Square className="w-4 h-4" aria-hidden="true" />}
                      </button>
                    </td>
                    {effectiveCols.risk && <td className={td} onClick={e => e.stopPropagation()}><FraudBadge risk={t.risk} reason={null} /></td>}
                    {cols.trnNum        && (
                      <td className={`${td} font-mono text-xs text-slate-300 whitespace-nowrap`}>
                        {t.id}
                        {featureFlags.rlusdStrip && t.rlusdEligible && t.status === "Needs Approval" && (
                          <span className="ml-1.5 inline-flex items-center px-1 py-0 rounded text-[9px] font-bold text-white bg-teal-500 leading-tight">RLUSD</span>
                        )}
                      </td>
                    )}
                    {cols.trnDate      && <td className={`${td} text-xs text-slate-300`}>{t.trnDate}</td>}
                    {cols.amount        && (
                      <td className={`${td} text-sm font-bold text-slate-200 whitespace-nowrap text-right`}>
                        {fmtAmt(t.amount, t.cur)} <span className="text-[11px] text-slate-400 font-normal">{t.cur}</span>
                      </td>
                    )}
                    {cols.payee         && <td className={`${td} text-sm font-medium text-white whitespace-nowrap`}>{t.payee}</td>}
                    {cols.operativeAcct && (
                      <td className={`${td} font-mono text-xs whitespace-nowrap`}>
                        <button
                          aria-label={`View operative account ${t.operativeAcct}`}
                          onClick={e => e.stopPropagation()}
                          className="text-teal-400 hover:text-teal-300 hover:underline transition-colors focus:outline-none focus:ring-2 focus:ring-teal-500/50 rounded">
                          {t.operativeAcct}
                        </button>
                      </td>
                    )}
                    {cols.instType      && (
                      <td className={td}>
                        <span className="text-xs px-1.5 py-0.5 rounded bg-slate-800/60 border border-slate-700/60 text-slate-300 font-medium">{t.instType}</span>
                      </td>
                    )}
                    {cols.valDate      && <td className={`${td} text-xs text-slate-300`}>{t.valDate}</td>}
                    {cols.offsetNum    && <td className={`${td} font-mono text-xs text-slate-400`}>{t.offsetNumber}</td>}
                    <td className={`${td} whitespace-nowrap`} onClick={e => e.stopPropagation()}>
                      <div className="flex items-center gap-1">
                        {/* Select Payment Rail — RLUSD-eligible Needs Approval txns */}
                        {featureFlags.selectPaymentRail && t.rlusdEligible && t.status === "Needs Approval" && (
                          <button
                            onClick={() => setPaymentRailTxn(t)}
                            aria-label={`Select payment rail for ${t.id}`}
                            title="Select Payment Rail"
                            className="p-1.5 min-w-[28px] min-h-[28px] flex items-center justify-center rounded bg-teal-500/15 border border-teal-500/25 text-teal-300 hover:bg-teal-500/25 transition-colors focus:outline-none focus:ring-2 focus:ring-teal-400 focus:ring-offset-1 focus:ring-offset-transparent">
                            <MousePointerClick className="w-3.5 h-3.5" aria-hidden="true" />
                          </button>
                        )}
                        {/* Approve — approval-eligible statuses */}
                        {(t.status==="Needs Approval"||t.status==="Ready to Approve") && (
                          <button
                            aria-label={`Approve payment to ${t.payee}`}
                            className="flex items-center gap-1 px-2 py-1 min-h-[28px] rounded text-xs font-bold bg-emerald-500/15 hover:bg-emerald-500/25 text-emerald-300 border border-emerald-500/25 transition-colors focus:outline-none focus:ring-2 focus:ring-emerald-400 focus:ring-offset-1 focus:ring-offset-transparent">
                            <CheckCircle2 className="w-3 h-3" aria-hidden="true" /> Approve
                          </button>
                        )}
                        {/* View */}
                        <button
                          aria-label={`View details for ${t.id}`}
                          title="View"
                          className="p-1.5 min-w-[28px] min-h-[28px] flex items-center justify-center rounded text-slate-400 hover:text-blue-300 hover:bg-blue-500/10 transition-colors focus:outline-none focus:ring-2 focus:ring-blue-400 focus:ring-offset-1 focus:ring-offset-transparent">
                          <Eye className="w-3.5 h-3.5" aria-hidden="true" />
                        </button>
                        {/* Edit */}
                        <button
                          aria-label={`Edit ${t.id}`}
                          title="Edit"
                          className="p-1.5 min-w-[28px] min-h-[28px] flex items-center justify-center rounded text-slate-400 hover:text-amber-300 hover:bg-amber-500/10 transition-colors focus:outline-none focus:ring-2 focus:ring-amber-400 focus:ring-offset-1 focus:ring-offset-transparent">
                          <Edit className="w-3.5 h-3.5" aria-hidden="true" />
                        </button>
                        {/* Delete */}
                        <button
                          aria-label={`Delete ${t.id}`}
                          title="Delete"
                          className="p-1.5 min-w-[28px] min-h-[28px] flex items-center justify-center rounded text-slate-400 hover:text-rose-300 hover:bg-rose-500/10 transition-colors focus:outline-none focus:ring-2 focus:ring-rose-400 focus:ring-offset-1 focus:ring-offset-transparent">
                          <Trash2 className="w-3.5 h-3.5" aria-hidden="true" />
                        </button>
                      </div>
                    </td>
                  </motion.tr>

                  {/* Expanded row — 4-card detail layout (matches Lovable) */}
                  <AnimatePresence initial={false}>
                    {isExpanded && (
                      <tr>
                        <td colSpan={totalColSpan} className="p-0 border-b border-slate-700/40">
                          <motion.div
                            initial={{ height:0, opacity:0 }} animate={{ height:"auto", opacity:1 }}
                            exit={{ height:0, opacity:0 }} transition={{ duration:0.18, ease:"easeInOut" }}
                            style={{ overflow:"hidden" }}
                          >
                            <div className="bg-[#0d1c30] px-6 py-4 grid grid-cols-2 md:grid-cols-4 gap-4">
                              {/* Card 1 — Payment Details */}
                              <div className="rounded-lg bg-[#162a47] border border-slate-700/50 p-4">
                                <h4 className="text-[10px] font-bold text-teal-400 uppercase tracking-wider mb-3 pb-2 border-b border-slate-700/50">Payment Details</h4>
                                <dl className="space-y-2.5">
                                  {([
                                    ["Approval Level", String(t.approvalLevel)],
                                    ["Inst. Type",     t.instType],
                                    ["Model ID",       t.modelId],
                                    ["Risk Score",     `${t.risk}/100`],
                                    ["Verified",       t.verified ? "✓ Verified" : "✗ Unverified"],
                                  ] as [string,string][]).map(([label, val]) => (
                                    <div key={label} className="flex items-baseline justify-between gap-3">
                                      <dt className="text-[10px] text-slate-400 whitespace-nowrap shrink-0">{label}</dt>
                                      <dd className={`text-xs font-medium text-right truncate ${label==="Verified"&&!t.verified ? "text-rose-300" : "text-slate-200"}`}>{val}</dd>
                                    </div>
                                  ))}
                                </dl>
                              </div>

                              {/* Card 2 — Dates */}
                              <div className="rounded-lg bg-[#162a47] border border-slate-700/50 p-4">
                                <h4 className="text-[10px] font-bold text-teal-400 uppercase tracking-wider mb-3 pb-2 border-b border-slate-700/50">Dates</h4>
                                <dl className="space-y-2.5">
                                  {([
                                    ["Transaction Date", t.trnDate],
                                    ["Value Date",       t.valDate],
                                    ["Process Stage",    t.processStage],
                                    ["Approver",         t.approver],
                                  ] as [string,string][]).map(([label, val]) => (
                                    <div key={label} className="flex items-baseline justify-between gap-3">
                                      <dt className="text-[10px] text-slate-400 whitespace-nowrap shrink-0">{label}</dt>
                                      <dd className="text-xs font-medium text-right truncate text-slate-200">{val}</dd>
                                    </div>
                                  ))}
                                </dl>
                              </div>

                              {/* Card 3 — Account Information */}
                              <div className="rounded-lg bg-[#162a47] border border-slate-700/50 p-4">
                                <h4 className="text-[10px] font-bold text-teal-400 uppercase tracking-wider mb-3 pb-2 border-b border-slate-700/50">Account Information</h4>
                                <dl className="space-y-2.5">
                                  <div className="flex items-baseline justify-between gap-3">
                                    <dt className="text-[10px] text-slate-400 whitespace-nowrap shrink-0">Operative Acct.</dt>
                                    <dd className="text-xs font-medium text-right text-teal-400 font-mono truncate">{t.operativeAcct}</dd>
                                  </div>
                                  <div className="flex items-baseline justify-between gap-3">
                                    <dt className="text-[10px] text-slate-400 whitespace-nowrap shrink-0">Account Name</dt>
                                    <dd className="text-xs font-medium text-right text-slate-200 truncate">{t.payee}</dd>
                                  </div>
                                  <div className="flex items-baseline justify-between gap-3">
                                    <dt className="text-[10px] text-slate-400 whitespace-nowrap shrink-0">Account No.</dt>
                                    <dd className="text-xs font-medium text-right text-slate-200 font-mono truncate">{t.offsetNumber}</dd>
                                  </div>
                                  <div className="flex items-baseline justify-between gap-3">
                                    <dt className="text-[10px] text-slate-400 whitespace-nowrap shrink-0">Legal Entity</dt>
                                    <dd className="text-xs font-medium text-right text-slate-200 truncate">{t.legalEntity}</dd>
                                  </div>
                                  <div className="flex items-baseline justify-between gap-3">
                                    <dt className="text-[10px] text-slate-400 whitespace-nowrap shrink-0">Bank</dt>
                                    <dd className="text-xs font-medium text-right text-slate-200 truncate">{t.bank}</dd>
                                  </div>
                                </dl>
                              </div>

                              {/* Card 4 — Additional Info */}
                              <div className="rounded-lg bg-[#162a47] border border-slate-700/50 p-4">
                                <h4 className="text-[10px] font-bold text-teal-400 uppercase tracking-wider mb-3 pb-2 border-b border-slate-700/50">Additional Info</h4>
                                <dl className="space-y-2.5">
                                  <div className="flex items-baseline justify-between gap-3">
                                    <dt className="text-[10px] text-slate-400 whitespace-nowrap shrink-0">Type</dt>
                                    <dd className="text-xs font-medium text-right text-slate-200">{t.type}</dd>
                                  </div>
                                  {t.riskReason && (
                                    <div className="flex items-baseline justify-between gap-3">
                                      <dt className="text-[10px] text-slate-400 whitespace-nowrap shrink-0">Risk Reason</dt>
                                      <dd className="text-xs font-medium text-right text-rose-300 truncate">{t.riskReason}</dd>
                                    </div>
                                  )}
                                  {t.waterfallChain && (
                                    <div className="flex items-baseline justify-between gap-3">
                                      <dt className="text-[10px] text-slate-400 whitespace-nowrap shrink-0">Chain</dt>
                                      <dd className="text-xs font-medium text-right">
                                        <button className="text-teal-400 hover:underline focus:outline-none focus:ring-2 focus:ring-teal-500/50 rounded">
                                          {t.waterfallChain} ({t.waterfallPosition}/{t.waterfallTotal})
                                        </button>
                                      </dd>
                                    </div>
                                  )}
                                  {t.attachment && (
                                    <div className="flex items-center gap-2 pt-1">
                                      <Paperclip className="w-3 h-3 text-slate-400 shrink-0" aria-hidden="true" />
                                      <button
                                        onClick={e => { e.stopPropagation(); setAttachment(t.attachment!); }}
                                        className="text-xs text-teal-400 hover:underline truncate focus:outline-none focus:ring-2 focus:ring-teal-500/50 rounded">
                                        {t.attachment.name}
                                      </button>
                                    </div>
                                  )}
                                </dl>
                              </div>
                            </div>
                          </motion.div>
                        </td>
                      </tr>
                    )}
                  </AnimatePresence>
                </React.Fragment>
              );
            })}
          </tbody>
        </table>

        {filtered.length === 0 && (
          <div className="py-12 text-center" role="status">
            <AlertCircle className="w-8 h-8 text-slate-700 mx-auto mb-2" aria-hidden="true" />
            <p className="text-slate-400 text-sm">No transactions match this filter</p>
          </div>
        )}

        {/* Pagination */}
        <div className="flex items-center justify-between px-4 py-2.5 border-t border-slate-800/40 text-xs text-slate-400">
          <span aria-live="polite">
            {sorted.length===0 ? "0 results" : `Rows ${(page-1)*rowsPerPage+1}–${Math.min(page*rowsPerPage,sorted.length)} of ${sorted.length}`}
          </span>
          <nav aria-label="Pagination" className="flex items-center gap-1">
            {[
              ["First",    () => setPage(1),              page===1       ],
              ["Previous", () => setPage(p => p-1),       page===1       ],
              ["Next",     () => setPage(p => p+1),       page===totalPages],
              ["Last",     () => setPage(totalPages),     page===totalPages],
            ].map(([label, fn, disabled]) => (
              <button key={label as string} onClick={fn as ()=>void} disabled={disabled as boolean}
                className="px-3 py-1.5 min-h-[28px] rounded hover:text-white hover:bg-slate-800/40 disabled:opacity-30 disabled:cursor-not-allowed transition-colors focus:outline-none focus:ring-2 focus:ring-teal-500/50">
                {label as string}
              </button>
            ))}
            <span className="px-3 text-slate-400">Page {page} of {totalPages}</span>
          </nav>
          <select
            value={filters.rowsPerPage}
            aria-label="Rows per page"
            onChange={e => setFilters({ ...filters, rowsPerPage: e.target.value })}
            className="bg-[#0f1e35] border border-slate-700/50 text-slate-400 text-xs rounded px-2 py-1.5 focus:outline-none focus:ring-2 focus:ring-teal-500/50 cursor-pointer">
            <option value="25">25 / page</option>
            <option value="50">50 / page</option>
            <option value="100">100 / page</option>
          </select>
        </div>
      </div>

      {/* Fraud Gate Modal */}
      <AnimatePresence>
        {showFraudGate && (
          <motion.div initial={{ opacity:0 }} animate={{ opacity:1 }} exit={{ opacity:0 }}
            className="fixed inset-0 bg-black/70 backdrop-blur-sm z-50 flex items-center justify-center p-6"
            onClick={e => { if (e.target===e.currentTarget) setShowFraudGate(false); }}>
            <motion.div ref={fraudGateDialogRef}
              initial={{ opacity:0, scale:0.95, y:12 }} animate={{ opacity:1, scale:1, y:0 }} exit={{ opacity:0, scale:0.95 }}
              role="dialog" aria-modal="true" aria-labelledby="fraud-gate-title"
              className="bg-[#162a47] border border-rose-500/40 rounded-2xl shadow-2xl max-w-md w-full p-6">
              <div className="flex items-start gap-3 mb-4">
                <div className="w-10 h-10 rounded-xl bg-rose-500/15 border border-rose-500/30 flex items-center justify-center shrink-0">
                  <ShieldAlert className="w-5 h-5 text-rose-400" aria-hidden="true" />
                </div>
                <div>
                  <h3 id="fraud-gate-title" className="text-white font-bold text-base m-0 mb-1">Elevated risk detected</h3>
                  <p className="text-slate-300 text-sm leading-relaxed m-0">
                    <strong className="text-rose-300">{flaggedInSel} of {selected.length}</strong> selected payments have a risk score ≥ 70. Review before approving.
                  </p>
                </div>
              </div>
              <div className="bg-rose-500/8 border border-rose-500/20 rounded-xl p-3 mb-5 space-y-1.5" role="list" aria-label="High-risk transactions">
                {selTxns.filter(t => t.risk >= 70).map(t => (
                  <div key={t.id} className="flex items-center gap-2 text-xs" role="listitem">
                    <ShieldAlert className="w-3 h-3 text-rose-400 shrink-0" aria-hidden="true" />
                    <span className="font-mono font-bold text-rose-300">{t.id}</span>
                    <span className="text-slate-300 flex-1 truncate">{t.payee}</span>
                    <span className="text-rose-300 font-bold shrink-0" aria-label={`Risk score ${t.risk}`}>{t.risk}/100</span>
                  </div>
                ))}
              </div>
              <div className="flex flex-col gap-2">
                <button onClick={() => setShowFraudGate(false)} autoFocus
                  className="w-full py-2.5 rounded-xl bg-teal-600 hover:bg-teal-500 text-white font-bold text-sm transition-colors flex items-center justify-center gap-2 focus:outline-none focus:ring-2 focus:ring-teal-400 focus:ring-offset-2 focus:ring-offset-[#162a47]">
                  <ShieldCheck className="w-4 h-4" aria-hidden="true" /> Review Flagged Payments
                </button>
                <button onClick={() => { setShowFraudGate(false); setSelected([]); }}
                  className="w-full py-2.5 rounded-xl bg-rose-500/15 hover:bg-rose-500/25 text-rose-300 border border-rose-500/25 font-bold text-sm transition-colors focus:outline-none focus:ring-2 focus:ring-rose-400 focus:ring-offset-2 focus:ring-offset-[#162a47]">
                  Approve All Anyway (not recommended)
                </button>
                <button onClick={() => setShowFraudGate(false)}
                  className="text-slate-400 hover:text-slate-300 text-sm text-center transition-colors py-1 focus:outline-none focus:ring-2 focus:ring-teal-500/50 rounded">
                  Cancel
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Reject Modal */}
      <AnimatePresence>
        {showVoid && (
          <motion.div initial={{ opacity:0 }} animate={{ opacity:1 }} exit={{ opacity:0 }}
            className="fixed inset-0 bg-black/70 backdrop-blur-sm z-50 flex items-center justify-center p-6"
            onClick={e => { if (e.target===e.currentTarget) setShowVoid(false); }}>
            <motion.div ref={voidDialogRef}
              initial={{ opacity:0, scale:0.95 }} animate={{ opacity:1, scale:1 }} exit={{ opacity:0, scale:0.95 }}
              role="dialog" aria-modal="true" aria-labelledby="reject-title"
              className="bg-[#162a47] border border-slate-700/60 rounded-2xl shadow-2xl max-w-sm w-full p-6">
              <div className="flex items-center gap-3 mb-3">
                <AlertTriangle className="w-5 h-5 text-rose-400" aria-hidden="true" />
                <h3 id="reject-title" className="text-white font-bold text-base m-0">Reject {selected.length} payment{selected.length!==1?"s":""}?</h3>
              </div>
              <p className="text-slate-300 text-sm mb-5 m-0">Rejected payments are logged in the audit trail and cannot be re-approved without re-entry.</p>
              <div className="flex gap-3">
                <button onClick={() => setShowVoid(false)}
                  className="flex-1 py-2 rounded-xl border border-slate-700/60 text-slate-300 hover:text-white hover:border-slate-600 font-semibold text-sm transition-colors focus:outline-none focus:ring-2 focus:ring-teal-500/50">
                  Cancel
                </button>
                <button autoFocus onClick={() => { setSelected([]); setShowVoid(false); }}
                  className="flex-1 py-2 rounded-xl bg-rose-500 hover:bg-rose-400 text-white font-bold text-sm transition-colors focus:outline-none focus:ring-2 focus:ring-rose-400 focus:ring-offset-2 focus:ring-offset-[#162a47]">
                  Reject Payments
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Payment Rail Dialog */}
      <PaymentRailDialog txn={paymentRailTxn} dialogRef={paymentRailDialogRef} onClose={() => setPaymentRailTxn(null)} showStablecoin={featureFlags.stablecoinRail} />

      {/* Attachment Viewer */}
      <AnimatePresence>
        {attachment && (
          <motion.div initial={{ opacity:0 }} animate={{ opacity:1 }} exit={{ opacity:0 }}
            className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-6"
            onClick={e => { if (e.target===e.currentTarget) setAttachment(null); }}>
            <motion.div initial={{ opacity:0, scale:0.95 }} animate={{ opacity:1, scale:1 }} exit={{ opacity:0, scale:0.95 }}
              role="dialog" aria-modal="true" aria-label={attachment.name}
              className="bg-[#162a47] border border-slate-700/50 rounded-2xl shadow-2xl max-w-3xl w-full flex flex-col overflow-hidden max-h-[90vh]">
              <div className="flex items-center justify-between px-5 py-3.5 border-b border-slate-700/50">
                <div className="flex items-center gap-2">
                  <Paperclip className="w-4 h-4 text-slate-400" aria-hidden="true" />
                  <span className="text-sm font-semibold text-white">{attachment.name}</span>
                </div>
                <button onClick={() => setAttachment(null)} aria-label="Close attachment viewer"
                  className="p-1.5 rounded text-slate-400 hover:text-white hover:bg-slate-700/50 transition-colors focus:outline-none focus:ring-2 focus:ring-teal-500/50">
                  <X className="w-4 h-4" aria-hidden="true" />
                </button>
              </div>
              <div className="flex-1 overflow-auto p-4">
                {attachment.type === "pdf" ? (
                  <iframe src={attachment.url} title={attachment.name} className="w-full h-[65vh] rounded border border-slate-700/40" />
                ) : (
                  <img src={attachment.url} alt={attachment.name} className="max-w-full mx-auto rounded" />
                )}
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </section>
  );
}

// ── PaymentRailDialog ──────────────────────────────────────────────────────────
function PaymentRailDialog({ txn, dialogRef, onClose, showStablecoin = true }: {
  txn: Txn | null;
  dialogRef: React.RefObject<HTMLDivElement>;
  onClose: () => void;
  showStablecoin?: boolean;
}) {
  const [selectedRail, setSelectedRail] = useState<"bank-wire" | "stablecoin">(showStablecoin ? "stablecoin" : "bank-wire");
  const [quoteGenerated, setQuoteGenerated] = useState(false);

  useEffect(() => {
    if (txn) { setSelectedRail(showStablecoin ? "stablecoin" : "bank-wire"); setQuoteGenerated(false); }
  }, [txn, showStablecoin]);

  // Esc to close
  useEffect(() => {
    if (!txn) return;
    const onKey = (e: KeyboardEvent) => { if (e.key === "Escape") onClose(); };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [txn, onClose]);

  if (!txn) return null;

  const fmtUSD = (n: number) => `$${n.toLocaleString("en-US", { minimumFractionDigits:2 })}`;

  return (
    <AnimatePresence>
      {txn && (
        <motion.div initial={{ opacity:0 }} animate={{ opacity:1 }} exit={{ opacity:0 }}
          className="fixed inset-0 bg-black/75 backdrop-blur-sm z-50 flex items-center justify-center p-6 overflow-y-auto"
          onClick={e => { if (e.target===e.currentTarget) onClose(); }}>
          <motion.div ref={dialogRef}
            initial={{ opacity:0, scale:0.96, y:16 }} animate={{ opacity:1, scale:1, y:0 }} exit={{ opacity:0, scale:0.96 }}
            role="dialog" aria-modal="true" aria-labelledby="rail-dialog-title"
            className="bg-[#0f1e35] border border-slate-700/50 rounded-2xl shadow-2xl w-full max-w-3xl my-auto">

            {/* Header */}
            <div className="px-6 py-5 border-b border-slate-700/40">
              <div className="flex items-start justify-between gap-4">
                <div>
                  <h2 id="rail-dialog-title" className="text-xl font-bold text-white m-0">Select Payment Rail</h2>
                  <p className="text-slate-400 text-sm mt-1">Choose how to process this payment. Compare options to find the best solution.</p>
                </div>
                <button onClick={onClose} aria-label="Close dialog"
                  className="p-1.5 rounded text-slate-400 hover:text-white hover:bg-slate-700/50 transition-colors shrink-0 focus:outline-none focus:ring-2 focus:ring-teal-500/50">
                  <X className="w-5 h-5" aria-hidden="true" />
                </button>
              </div>
              {/* Payment info bar */}
              <div className="flex flex-wrap items-center gap-x-6 gap-y-2 mt-4 text-sm">
                <div className="flex items-center gap-2">
                  <span className="text-slate-400">Payment Amount:</span>
                  <span className="text-lg font-bold text-white">{fmtUSD(txn.amount)}</span>
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-slate-400">Corridor:</span>
                  <span className="px-2 py-0.5 rounded border border-slate-600 font-mono text-xs text-slate-300">{txn.cur} → EUR</span>
                </div>
                {showStablecoin && (
                  <div className="flex items-center gap-2 text-teal-400">
                    <CheckCircle2 className="w-4 h-4" aria-hidden="true" />
                    <span className="font-medium text-sm">Stablecoin rail available</span>
                  </div>
                )}
              </div>
            </div>

            {/* Rail comparison cards */}
            <div className={`p-6 grid grid-cols-1 ${showStablecoin ? "md:grid-cols-2" : ""} gap-4`}>
              {/* Bank Wire */}
              <button
                onClick={() => { setSelectedRail("bank-wire"); setQuoteGenerated(false); }}
                aria-pressed={selectedRail === "bank-wire"}
                className={`relative rounded-xl border-2 p-5 text-left transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-teal-500/50 ${
                  selectedRail === "bank-wire"
                    ? "border-teal-500/50 bg-teal-500/5 shadow-lg shadow-teal-500/10"
                    : "border-slate-700/50 bg-[#162a47] hover:border-slate-600"
                }`}>
                {selectedRail === "bank-wire" && (
                  <div className="absolute top-3 right-3">
                    <CheckCircle2 className="w-5 h-5 text-teal-400" aria-hidden="true" />
                  </div>
                )}
                <div className="flex items-center gap-3 mb-4">
                  <div className="p-2.5 rounded-lg bg-slate-800/60 border border-slate-700/50">
                    <Landmark className="w-5 h-5 text-slate-300" aria-hidden="true" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-white text-sm">Bank Wire Transfer</h3>
                    <p className="text-xs text-slate-400">Standard processing</p>
                  </div>
                </div>
                <div className="space-y-3 mb-4">
                  <div className="flex items-center justify-between text-sm">
                    <div className="flex items-center gap-2 text-slate-400"><Clock className="w-3.5 h-3.5" /> Settlement</div>
                    <span className="font-semibold text-slate-200">1–5 business days</span>
                  </div>
                  <div className="flex items-center justify-between text-sm">
                    <div className="flex items-center gap-2 text-slate-400"><FileText className="w-3.5 h-3.5" /> Cost</div>
                    <span className="font-semibold text-slate-200">$25–45 / txn</span>
                  </div>
                </div>
                <div className="border-t border-slate-700/40 pt-3 space-y-1.5">
                  {["Traditional banking infrastructure","Established processes","Wide acceptance"].map(f => (
                    <div key={f} className="flex items-center gap-2 text-xs text-slate-400">
                      <CheckCircle2 className="w-3.5 h-3.5 text-slate-600 shrink-0" aria-hidden="true" /> {f}
                    </div>
                  ))}
                </div>
              </button>

              {/* Stablecoin / RLUSD */}
              {showStablecoin && (
                <button
                  onClick={() => setSelectedRail("stablecoin")}
                  aria-pressed={selectedRail === "stablecoin"}
                  className={`relative rounded-xl border-2 p-5 text-left transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-teal-500/50 ${
                    selectedRail === "stablecoin"
                      ? "border-teal-500/60 bg-teal-500/8 shadow-lg shadow-teal-500/15"
                      : "border-slate-700/50 bg-[#162a47] hover:border-slate-600"
                  }`}>
                  <div className="absolute -top-3 left-1/2 -translate-x-1/2">
                    <span className="px-3 py-0.5 rounded-full text-[10px] font-bold bg-teal-500 text-white">RECOMMENDED</span>
                  </div>
                  {selectedRail === "stablecoin" && (
                    <div className="absolute top-3 right-3">
                      <CheckCircle2 className="w-5 h-5 text-teal-400" aria-hidden="true" />
                    </div>
                  )}
                  <div className="flex items-center gap-3 mb-4">
                    <div className="p-2 rounded-lg bg-teal-500/15 border border-teal-500/25 flex items-center justify-center">
                      <span className="text-[11px] font-bold text-teal-300 px-0.5">RLUSD</span>
                    </div>
                    <div>
                      <h3 className="font-semibold text-white text-sm">Stablecoin Transfer (RLUSD)</h3>
                      <p className="text-xs text-slate-400">Next-generation instant settlement</p>
                    </div>
                  </div>
                  <div className="space-y-3 mb-4">
                    <div className="flex items-center justify-between text-sm">
                      <div className="flex items-center gap-2 text-slate-400"><Clock className="w-3.5 h-3.5" /> Settlement</div>
                      <span className="font-semibold text-teal-400">Minutes</span>
                    </div>
                    <div className="flex items-center justify-between text-sm">
                      <div className="flex items-center gap-2 text-slate-400"><FileText className="w-3.5 h-3.5" /> Cost</div>
                      <span className="font-semibold text-teal-400">$2–5 / txn</span>
                    </div>
                  </div>
                  <div className="border-t border-slate-700/40 pt-3 space-y-1.5">
                    {["Real-time settlement","Blockchain transparency","Lower operational costs"].map(f => (
                      <div key={f} className="flex items-center gap-2 text-xs text-slate-400">
                        <CheckCircle2 className="w-3.5 h-3.5 text-teal-400 shrink-0" aria-hidden="true" /> {f}
                      </div>
                    ))}
                  </div>
                  {selectedRail === "stablecoin" && !quoteGenerated && (
                    <div className="mt-4">
                      <button
                        onClick={e => { e.stopPropagation(); setQuoteGenerated(true); }}
                        className="w-full py-2 rounded-lg border border-teal-500/30 text-teal-400 text-xs font-semibold hover:bg-teal-500/10 transition-colors focus:outline-none focus:ring-2 focus:ring-teal-500/50">
                        <FileText className="w-3.5 h-3.5 inline mr-1.5" aria-hidden="true" /> Get Quote
                      </button>
                    </div>
                  )}
                </button>
              )}
            </div>

            {/* Quote panel */}
            {quoteGenerated && selectedRail === "stablecoin" && (
              <div className="px-6 pb-4 space-y-4">
                <div className="rounded-xl border-2 border-teal-500/40 bg-teal-500/5 p-5">
                  <div className="flex items-center justify-between mb-4">
                    <div className="flex items-center gap-2">
                      <CheckCircle2 className="w-4 h-4 text-teal-400" aria-hidden="true" />
                      <h3 className="font-semibold text-white text-base m-0">Stablecoin Quote</h3>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-teal-500 text-white">VALID</span>
                      <span className="px-2 py-0.5 rounded border border-slate-600 font-mono text-[10px] text-slate-300">quo_3f2a8c19b4e047d8</span>
                    </div>
                  </div>
                  {/* Source → Dest */}
                  <div className="grid grid-cols-[1fr_auto_1fr] items-center gap-4 mb-4">
                    <div className="rounded-lg border border-slate-700/50 bg-[#162a47] p-3">
                      <p className="text-[10px] text-teal-400 font-semibold mb-1">Source</p>
                      <p className="text-xl font-bold text-white">100.15 <span className="text-sm font-semibold">RLUSD</span></p>
                      <p className="text-[10px] text-slate-400 mt-1 font-mono">ACT_998877</p>
                    </div>
                    <ArrowRight className="w-5 h-5 text-slate-500" aria-hidden="true" />
                    <div className="rounded-lg border border-slate-700/50 bg-[#162a47] p-3">
                      <p className="text-[10px] text-teal-400 font-semibold mb-1">Destination</p>
                      <p className="text-xl font-bold text-white">1,854.20 <span className="text-sm font-semibold">MXN</span></p>
                      <p className="text-[10px] text-slate-400 mt-1 font-mono">DEST_554433</p>
                    </div>
                  </div>
                  {/* Quote details grid */}
                  <div className="grid grid-cols-2 gap-x-8 gap-y-4 text-sm">
                    {([
                      ["FX Rate",          "18.5142", "RLUSD → MXN"],
                      ["Total Source",     "100.30 RLUSD", "Incl. all fees"],
                      ["Transaction Fee",  "0.05 RLUSD", ""],
                      ["FX Spread",        "0.10 RLUSD", ""],
                      ["Settlement",       "DIGITAL_ASSET", ""],
                      ["Asset Path",       "RLUSD → XRP → MXN", ""],
                      ["Slippage",         "0.50%", ""],
                    ] as [string,string,string][]).map(([label, val, sub]) => (
                      <div key={label}>
                        <p className="text-[10px] text-teal-400 font-semibold mb-0.5">{label}</p>
                        <p className="font-bold text-white text-sm">{val}</p>
                        {sub && <p className="text-[10px] text-slate-400">{sub}</p>}
                      </div>
                    ))}
                  </div>
                  <p className="mt-4 pt-3 border-t border-teal-500/20 text-[10px] text-slate-400">
                    Expires 2026-02-25 09:35:12 UTC · Real-time pricing · Transparent blockchain settlement
                  </p>
                </div>

                {/* Additional details */}
                <div className="rounded-xl border border-slate-700/50 bg-[#162a47] p-5">
                  <div className="flex items-center gap-2 mb-4">
                    <h3 className="font-semibold text-white text-sm m-0">Additional Details</h3>
                    <HelpCircle className="w-3.5 h-3.5 text-slate-400" aria-hidden="true" />
                  </div>
                  <div className="grid grid-cols-2 gap-x-8 gap-y-3 text-sm">
                    {([
                      ["Blockchain Network",     "XRP Ledger (via RLUSD)"],
                      ["Regulatory Compliance",  "Fully compliant"],
                      ["Expected Completion",    "~3–5 minutes"],
                      ["Blockchain Tracking",    "Full transparency"],
                    ] as [string,string][]).map(([label, val]) => (
                      <div key={label}>
                        <p className="text-[10px] text-teal-400 font-semibold mb-0.5">{label}</p>
                        <p className="text-sm font-semibold text-slate-200">{val}</p>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            )}

            {/* Footer actions */}
            <div className="px-6 py-4 border-t border-slate-700/40 flex items-center justify-between">
              <button onClick={onClose}
                className="px-5 py-2 rounded-xl border border-slate-700/60 text-slate-300 hover:text-white hover:border-slate-600 font-semibold text-sm transition-colors focus:outline-none focus:ring-2 focus:ring-teal-500/50">
                Cancel
              </button>
              {(quoteGenerated && selectedRail === "stablecoin") || selectedRail === "bank-wire" ? (
                <button onClick={onClose}
                  className="flex items-center gap-2 px-5 py-2 rounded-xl bg-teal-600 hover:bg-teal-500 text-white font-bold text-sm transition-colors focus:outline-none focus:ring-2 focus:ring-teal-400 focus:ring-offset-2 focus:ring-offset-[#0f1e35]">
                  Continue with {selectedRail === "stablecoin" ? "Stablecoin" : "Bank Wire"}
                  <ArrowRight className="w-4 h-4" aria-hidden="true" />
                </button>
              ) : null}
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}

// ── Main page ─────────────────────────────────────────────────────────────────
export default function Prototype() {
  const [filters, setFilters]         = useState(DEFAULT_FILTERS);
  const [refreshing, setRefreshing]   = useState(false);
  const [lastRefreshed, setLastRefreshed] = useState("4:23 PM");
  const [isDark, setIsDark]           = useState(() => localStorage.getItem("paym-theme") !== "light");

  const urlParams = new URLSearchParams(window.location.search);
  const featureFlags = {
    rlusdStrip: urlParams.get("rlusdStrip") !== "0",
    stablecoinRail: urlParams.get("stablecoinRail") !== "0",
    selectPaymentRail: urlParams.get("selectPaymentRail") !== "0",
    riskColumn: urlParams.get("riskColumn") !== "0",
  };

  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  useEffect(() => {
    document.documentElement.classList.toggle("light-mode", !isDark);
    localStorage.setItem("paym-theme", isDark ? "dark" : "light");
  }, [isDark]);

  const handleRefresh = () => {
    setRefreshing(true);
    setTimeout(() => {
      setRefreshing(false);
      setLastRefreshed(new Date().toLocaleTimeString("en-US",{ hour:"numeric", minute:"2-digit" }));
    }, 1200);
  };

  const isFiltered =
    filters.status !== "" ||
    filters.processStage !== "" ||
    filters.txnType !== "" ||
    filters.payee !== "" ||
    filters.txnNum !== "" ||
    filters.legalEntity !== "" ||
    filters.quickSearch !== "" ||
    filters.dateFrom !== DEFAULT_FILTERS.dateFrom ||
    filters.dateTo !== DEFAULT_FILTERS.dateTo ||
    !filters.showMyItems;

  return (
    <div className="min-h-screen flex flex-col bg-[#0f1e35] text-white">
      <AppNav />

      <main id="main-content" className="flex-1 p-6 space-y-5 overflow-y-auto">
        {/* Page header */}
        <div className="flex items-center justify-between">
          <div>
            <nav aria-label="Breadcrumb" className="breadcrumb-bar flex items-center gap-1.5 text-xs mb-1.5">
              <span className="text-slate-500 font-medium">Payments</span>
              <ChevronRight className="w-3 h-3 text-slate-600" aria-hidden="true" />
              <span className="text-slate-400" aria-current="page">Transaction Status Workflow</span>
            </nav>
            <h1 className="text-xl font-bold text-white m-0 leading-tight tracking-tight">Transaction Status Workflow</h1>
            <p className="text-xs text-slate-400 mt-1 m-0">Manage and monitor all your payments in one place</p>
          </div>
          <div className="flex items-center gap-3">
            <p className="text-xs text-slate-400 m-0" aria-live="polite">
              Last refreshed: <span className="text-slate-300 font-medium">{lastRefreshed}</span>
            </p>
            <button onClick={handleRefresh} aria-label={refreshing ? "Refreshing all sections" : "Refresh all sections"}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs text-slate-300 hover:text-white border border-slate-700/60 hover:border-slate-600 bg-[#162a47] transition-all focus:outline-none focus:ring-2 focus:ring-teal-500/50 ${refreshing?"opacity-60":""}`}>
              <RefreshCw className={`w-3.5 h-3.5 ${refreshing?"animate-spin":""}`} aria-hidden="true" />
              {refreshing ? "Refreshing…" : "Refresh"}
            </button>
          </div>
        </div>

        <FilterPanel filters={filters} setFilters={setFilters} />
        <FraudSpotlight />
        <PaymentSummary filters={filters} setFilters={setFilters} />
        <ResultsTable txns={mockTxns} tray="all" filters={filters} setFilters={setFilters} featureFlags={featureFlags} />
      </main>

      <footer className="shrink-0 py-2 px-4 border-t border-slate-800/60 bg-[#0f1e35] flex items-center justify-between">
        <span className="text-[11px] text-slate-400">©2026 G TREASURY SS, LLC. All rights reserved · 26.1.0421 · Policies · QAVR</span>
        <div className="flex items-center gap-3">
          <span className="text-[11px] text-slate-400">TSW Redesign · Ripple Treasury Design System · Feb 2026</span>
          <button
            onClick={() => setIsDark(d => !d)}
            aria-label={isDark ? "Switch to light mode" : "Switch to dark mode"}
            className="flex items-center gap-1.5 px-2.5 py-1 rounded-full border border-slate-700/60 bg-slate-800/60 hover:border-slate-600 hover:bg-slate-700/60 transition-all text-xs font-medium text-slate-400 hover:text-white focus:outline-none focus:ring-2 focus:ring-teal-500/50">
            {isDark
              ? <><Sun  className="w-3 h-3 text-amber-400" aria-hidden="true" /> Light</>
              : <><Moon className="w-3 h-3 text-slate-400" aria-hidden="true" /> Dark</>}
          </button>
        </div>
      </footer>
    </div>
  );
}
