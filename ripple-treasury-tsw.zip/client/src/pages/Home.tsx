import { motion } from "framer-motion";
import { 
  Users, Target, Zap, Globe, Shield, 
  BarChart, Wallet, PieChart, ArrowRight,
  Send, Terminal, Layers
} from "lucide-react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { insertFeedbackSchema, type InsertFeedback } from "@shared/schema";
import { useCreateFeedback } from "@/hooks/use-feedback";

import { Navigation } from "@/components/Navigation";
import { SectionHeader } from "@/components/SectionHeader";
import { CompetitorCard } from "@/components/CompetitorCard";
import { 
  Form, FormControl, FormField, FormItem, 
  FormLabel, FormMessage 
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";

// Animation variants
const fadeInUp = {
  hidden: { opacity: 0, y: 20 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.6 } }
};

const staggerContainer = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: {
      staggerChildren: 0.1
    }
  }
};

export default function Home() {
  const createFeedback = useCreateFeedback();
  
  const form = useForm<InsertFeedback>({
    resolver: zodResolver(insertFeedbackSchema),
    defaultValues: {
      name: "",
      email: "",
      message: "",
    }
  });

  const onSubmit = (data: InsertFeedback) => {
    createFeedback.mutate(data, {
      onSuccess: () => form.reset()
    });
  };

  return (
    <div className="min-h-screen bg-[hsl(var(--navy-dark))]">
      <Navigation />

      {/* HERO SECTION */}
      <section id="overview" className="pt-32 pb-20 relative overflow-hidden">
        <div className="absolute top-0 inset-x-0 h-[500px] bg-gradient-to-b from-blue-900/10 to-transparent pointer-events-none" />
        
        <div className="container mx-auto px-6 relative z-10">
          <motion.div 
            initial="hidden" 
            animate="visible" 
            variants={staggerContainer}
            className="max-w-4xl mx-auto text-center"
          >
            <motion.div variants={fadeInUp} className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-blue-500/10 border border-blue-500/20 text-blue-400 text-sm font-medium mb-6">
              <span className="relative flex h-2 w-2">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-blue-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2 w-2 bg-blue-500"></span>
              </span>
              Internal Strategy Document
            </motion.div>
            
            <motion.h1 variants={fadeInUp} className="text-5xl md:text-7xl font-bold tracking-tight mb-8">
              Treasury Management <span className="text-gradient">2.0</span>
            </motion.h1>
            
            <motion.p variants={fadeInUp} className="text-xl text-slate-400 max-w-2xl mx-auto mb-12">
              A unified platform strategy to revolutionize how global finance teams manage liquidity, risk, and operations.
            </motion.p>
            
            <motion.div variants={fadeInUp} className="bg-[#132038] border border-[#1e3a5f] rounded-2xl p-8 text-left shadow-2xl relative overflow-hidden group">
              <div className="absolute top-0 right-0 p-8 opacity-10 group-hover:opacity-20 transition-opacity">
                <Target className="w-32 h-32 text-blue-400" />
              </div>
              
              <h3 className="text-blue-400 font-bold uppercase tracking-wider text-sm mb-4">The Challenge</h3>
              <p className="text-lg text-slate-300 leading-relaxed relative z-10">
                Current treasury operations are fragmented across 12+ legacy systems, resulting in <span className="text-white font-semibold">48h data latency</span> and <span className="text-white font-semibold">manual reconciliation overhead</span>. We need a single source of truth.
              </p>
            </motion.div>
          </motion.div>
        </div>
      </section>

      {/* RESEARCH SECTION */}
      <section id="research" className="py-20 border-t border-slate-800/50 bg-[#0d1b33]">
        <div className="container mx-auto px-6">
          <SectionHeader 
            icon={<Users className="w-8 h-8" />}
            title="Research Insights"
            subtitle="Synthesized from 25+ stakeholder interviews across London, New York, and Singapore offices."
          />

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 mb-20">
            {/* Personas Table */}
            <motion.div 
              initial={{ opacity: 0, x: -20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              className="bg-[#0f213e] rounded-xl border border-slate-800 overflow-hidden shadow-lg"
            >
              <div className="px-6 py-4 border-b border-blue-500/30 bg-[#162a4d]">
                <h3 className="text-white font-bold m-0">Key Personas</h3>
              </div>
              <div className="overflow-x-auto">
                <table className="w-full text-left border-collapse">
                  <thead>
                    <tr className="border-b border-slate-700/50">
                      <th className="p-4 text-xs uppercase text-slate-400 font-semibold w-1/3">Role</th>
                      <th className="p-4 text-xs uppercase text-slate-400 font-semibold">Primary Pain Point</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-700/50">
                    <tr className="hover:bg-slate-800/30 transition-colors">
                      <td className="p-4">
                        <div className="font-semibold text-white">Cash Manager</div>
                        <div className="text-xs text-slate-400">Daily Ops</div>
                      </td>
                      <td className="p-4 text-sm text-slate-300">
                        "I spend 4 hours daily just logging into different bank portals to scrape CSVs."
                      </td>
                    </tr>
                    <tr className="hover:bg-slate-800/30 transition-colors">
                      <td className="p-4">
                        <div className="font-semibold text-white">Risk Analyst</div>
                        <div className="text-xs text-slate-400">Strategic</div>
                      </td>
                      <td className="p-4 text-sm text-slate-300">
                        "FX exposure data is stale by the time I get it. I'm hedging based on yesterday's news."
                      </td>
                    </tr>
                    <tr className="hover:bg-slate-800/30 transition-colors">
                      <td className="p-4">
                        <div className="font-semibold text-white">CFO</div>
                        <div className="text-xs text-slate-400">Executive</div>
                      </td>
                      <td className="p-4 text-sm text-slate-300">
                        "I can't see our global liquidity position in one view. It's a blind spot."
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </motion.div>

            {/* Quote Card */}
            <motion.div 
              initial={{ opacity: 0, x: 20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              className="flex flex-col justify-center"
            >
              <div className="relative">
                <div className="absolute -top-6 -left-6 text-6xl text-blue-800 font-serif opacity-50">"</div>
                <blockquote className="text-2xl font-light text-slate-300 italic leading-relaxed z-10 relative">
                  The biggest risk isn't market volatility; it's our inability to see the volatility until it's too late.
                </blockquote>
                <div className="mt-6 flex items-center gap-4">
                  <div className="w-12 h-12 rounded-full bg-slate-700 overflow-hidden">
                    <div className="w-full h-full bg-gradient-to-tr from-blue-600 to-purple-600 flex items-center justify-center text-white font-bold">SJ</div>
                  </div>
                  <div>
                    <div className="text-white font-semibold">Sarah Jenkins</div>
                    <div className="text-sm text-blue-400">Head of Global Treasury</div>
                  </div>
                </div>
              </div>
            </motion.div>
          </div>

          <h3 className="text-xl font-bold text-white mb-8 flex items-center gap-3">
            <Globe className="text-teal-400" />
            Competitive Landscape
          </h3>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <CompetitorCard 
              name="Modern Treasury" 
              color="teal"
              pros={["API-first architecture", "Excellent developer docs", "Real-time payments"]}
              cons={["Limited forecasting tools", "US-centric banking coverage"]}
            />
            <CompetitorCard 
              name="Kyriba" 
              color="purple"
              pros={["Comprehensive features", "Strong enterprise reputation", "Global coverage"]}
              cons={["Dated UX/UI", "High implementation cost", "Slow performance"]}
            />
            <CompetitorCard 
              name="FIS Integrity" 
              color="blue"
              pros={["Deep banking integration", "Robust risk modules", "Audit trail"]}
              cons={["Complex workflows", "Steep learning curve", "Legacy codebase"]}
            />
          </div>
        </div>
      </section>

      {/* STRATEGY SECTION */}
      <section id="strategy" className="py-20 relative overflow-hidden">
        {/* Abstract background shapes */}
        <div className="absolute top-1/4 right-0 w-[500px] h-[500px] bg-blue-600/5 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute bottom-0 left-0 w-[400px] h-[400px] bg-teal-600/5 rounded-full blur-3xl pointer-events-none" />

        <div className="container mx-auto px-6 relative z-10">
          <SectionHeader 
            icon={<Zap className="w-8 h-8" />}
            title="Design Strategy"
            subtitle="Our approach combines the speed of consumer fintech with the robustness of enterprise banking."
          />

          <div className="grid grid-cols-1 md:grid-cols-2 gap-12 mb-20">
            <div>
              <h3 className="text-xl font-bold text-white mb-6">Core Principles</h3>
              <div className="space-y-6">
                {[
                  {
                    title: "Data Visualization First",
                    desc: "Numbers tell a story. We lead with charts and trends, not just grids of data.",
                    icon: <BarChart className="w-5 h-5" />
                  },
                  {
                    title: "Exception-Based Workflows",
                    desc: "Don't show everything. Only highlight what needs attention or approval.",
                    icon: <Shield className="w-5 h-5" />
                  },
                  {
                    title: "Actionable Insights",
                    desc: "Every data point should lead to a clear next action or decision.",
                    icon: <Send className="w-5 h-5" />
                  }
                ].map((item, i) => (
                  <motion.div 
                    key={i}
                    whileHover={{ x: 5 }}
                    className="flex gap-4 p-4 rounded-lg hover:bg-white/5 transition-colors border border-transparent hover:border-white/5"
                  >
                    <div className="glow-point shrink-0">
                      {i + 1}
                    </div>
                    <div>
                      <h4 className="text-lg font-bold text-white mb-1 flex items-center gap-2">
                        {item.title}
                      </h4>
                      <p className="text-slate-400 text-sm">{item.desc}</p>
                    </div>
                  </motion.div>
                ))}
              </div>
            </div>

            <div className="bg-gradient-to-br from-[#162a4d] to-[#0a1628] p-1 rounded-2xl">
              <div className="bg-[#0a1628] rounded-xl h-full p-8 border border-slate-800">
                <h3 className="text-xl font-bold text-white mb-6">Key Differentiators</h3>
                <div className="grid grid-cols-1 gap-4">
                  {[
                    { title: "Unified Data Layer", val: "Aggregates 45+ bank APIs into one schema" },
                    { title: "Predictive AI", val: "Forecasts cash flow with 94% accuracy" },
                    { title: "Zero-Code Rules", val: "Automated sweeping rules via drag-and-drop" },
                    { title: "Real-Time Netting", val: "Inter-company settlement in minutes, not days" }
                  ].map((diff, i) => (
                    <div key={i} className="flex items-center justify-between p-4 bg-[#0f213e] rounded-lg border border-slate-800/50">
                      <span className="font-medium text-blue-300">{diff.title}</span>
                      <span className="text-sm text-slate-400 text-right max-w-[200px]">{diff.val}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ROADMAP SECTION */}
      <section id="roadmap" className="py-20 bg-[#0d1b33] border-t border-slate-800/50">
        <div className="container mx-auto px-6">
          <SectionHeader 
            icon={<Terminal className="w-8 h-8" />}
            title="Execution Roadmap"
            subtitle="Phased rollout strategy to minimize operational disruption."
          />

          <div className="relative">
            {/* Vertical Line */}
            <div className="absolute left-6 top-0 bottom-0 w-0.5 bg-gradient-to-b from-blue-500 via-teal-500 to-slate-800 md:left-1/2 md:-ml-px" />

            <div className="space-y-12">
              {[
                {
                  phase: "Phase 1: Foundation",
                  time: "Q3 2024",
                  items: ["Bank API Integration Layer", "Cash Position Dashboard", "User Role Management"],
                  status: "completed",
                  icon: <Layers className="w-5 h-5 text-white" />
                },
                {
                  phase: "Phase 2: Intelligence",
                  time: "Q4 2024",
                  items: ["Cash Flow Forecasting", "FX Hedging Recommendations", "Automated Reporting"],
                  status: "active",
                  icon: <PieChart className="w-5 h-5 text-white" />
                },
                {
                  phase: "Phase 3: Automation",
                  time: "Q1 2025",
                  items: ["Smart Payment Routing", "Inter-company Netting Engine", "Virtual Account Management"],
                  status: "future",
                  icon: <Wallet className="w-5 h-5 text-white" />
                }
              ].map((item, i) => (
                <motion.div 
                  key={i}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: i * 0.1 }}
                  className={`relative flex items-center justify-between md:justify-normal ${i % 2 === 0 ? 'md:flex-row-reverse' : ''}`}
                >
                  {/* Dot on line */}
                  <div className={`absolute left-6 md:left-1/2 w-4 h-4 rounded-full border-4 border-[#0d1b33] -ml-2 z-10 
                    ${item.status === 'completed' ? 'bg-emerald-500' : item.status === 'active' ? 'bg-blue-500 animate-pulse' : 'bg-slate-600'}`} 
                  />

                  {/* Spacer for desktop layout */}
                  <div className="hidden md:block w-1/2" />

                  {/* Card */}
                  <div className={`w-[calc(100%-60px)] md:w-[calc(50%-40px)] ml-16 md:ml-0 ${i % 2 === 0 ? 'md:mr-10' : 'md:ml-10'}`}>
                    <div className="bg-[#0f213e] p-6 rounded-xl border border-slate-800 shadow-lg relative group hover:border-blue-500/30 transition-colors">
                      <div className="flex justify-between items-start mb-4">
                        <div className={`p-2 rounded-lg ${item.status === 'active' ? 'bg-blue-500/20' : 'bg-slate-800'}`}>
                          {item.icon}
                        </div>
                        <span className={`text-xs font-bold px-2 py-1 rounded-full uppercase tracking-wide
                          ${item.status === 'completed' ? 'bg-emerald-500/10 text-emerald-400' : 
                            item.status === 'active' ? 'bg-blue-500/10 text-blue-400' : 'bg-slate-700/50 text-slate-400'}`}>
                          {item.time}
                        </span>
                      </div>
                      
                      <h3 className="text-xl font-bold text-white mb-1">{item.phase}</h3>
                      <ul className="mt-4 space-y-2">
                        {item.items.map((sub, j) => (
                          <li key={j} className="flex items-center gap-2 text-sm text-slate-300">
                            <div className="w-1.5 h-1.5 rounded-full bg-blue-500/50" />
                            {sub}
                          </li>
                        ))}
                      </ul>
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* FEEDBACK SECTION (Functional) */}
      <section id="feedback" className="py-20">
        <div className="container mx-auto px-6 max-w-3xl">
          <div className="bg-gradient-to-br from-[#1a2d4d] to-[#0f213e] rounded-2xl p-8 md:p-12 border border-slate-700/50 shadow-2xl">
            <div className="text-center mb-10">
              <h2 className="text-3xl font-bold text-white mb-4">Share Your Feedback</h2>
              <p className="text-slate-400">Help shape the future of Treasury Management. Your input goes directly to the product team.</p>
            </div>

            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <FormField
                    control={form.control}
                    name="name"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="text-slate-300">Name</FormLabel>
                        <FormControl>
                          <Input placeholder="John Doe" className="bg-[#0a1628] border-slate-700 text-white placeholder:text-slate-600 focus:border-blue-500 transition-colors" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="email"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="text-slate-300">Email</FormLabel>
                        <FormControl>
                          <Input placeholder="john@company.com" className="bg-[#0a1628] border-slate-700 text-white placeholder:text-slate-600 focus:border-blue-500 transition-colors" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>
                
                <FormField
                  control={form.control}
                  name="message"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="text-slate-300">Feedback</FormLabel>
                      <FormControl>
                        <Textarea 
                          placeholder="I think the roadmap should include..." 
                          className="min-h-[120px] bg-[#0a1628] border-slate-700 text-white placeholder:text-slate-600 focus:border-blue-500 transition-colors resize-none" 
                          {...field} 
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <Button 
                  type="submit" 
                  className="w-full bg-gradient-to-r from-blue-600 to-teal-600 hover:from-blue-500 hover:to-teal-500 text-white font-bold py-6 rounded-lg shadow-lg hover:shadow-blue-500/25 transition-all duration-300"
                  disabled={createFeedback.isPending}
                >
                  {createFeedback.isPending ? "Submitting..." : (
                    <span className="flex items-center gap-2">
                      Submit Feedback <ArrowRight className="w-5 h-5" />
                    </span>
                  )}
                </Button>
              </form>
            </Form>
          </div>
        </div>
      </section>

      {/* FOOTER */}
      <footer className="py-8 border-t border-slate-800 bg-[#050b14] text-center">
        <p className="text-slate-600 text-sm">
          &copy; 2026 Ripple Treasury. Confidential &amp; Proprietary.
        </p>
      </footer>
    </div>
  );
}
