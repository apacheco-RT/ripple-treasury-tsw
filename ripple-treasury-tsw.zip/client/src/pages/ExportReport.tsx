import { AlertTriangle, AlertCircle, Info, Printer } from "lucide-react";

// ── Badges ──────────────────────────────────────────────────────────────────
function SevBadge({ level }: { level: "HIGH" | "MEDIUM" | "LOW" }) {
  const map = {
    HIGH:   "print-badge-high",
    MEDIUM: "print-badge-med",
    LOW:    "print-badge-low",
  };
  const icons = { HIGH: "▲", MEDIUM: "●", LOW: "ℹ" };
  return (
    <span className={`print-badge ${map[level]}`}>{icons[level]} {level}</span>
  );
}

function EffortBadge({ level }: { level: "LOW EFFORT" | "MED EFFORT" | "HIGH EFFORT" }) {
  const map = {
    "LOW EFFORT":  "print-badge-low",
    "MED EFFORT":  "print-badge-med",
    "HIGH EFFORT": "print-badge-high",
  };
  return <span className={`print-badge ${map[level]}`}>{level}</span>;
}

// ── Data ────────────────────────────────────────────────────────────────────
const heuristics = [
  { id: "H1", name: "Visibility of System Status",             finding: "Payment status shows a single static label with no lifecycle position, no time-in-state, and no blocking reason.", screen: "Results", severity: "HIGH" as const,   impact: "Approvers cannot diagnose delays or predict when a payment will complete." },
  { id: "H2", name: "Match Between System & Real World",       finding: "Column headers use internal shorthand — \"Paym Ref\", \"Acct Verification\", \"SWIFT Ref\" — that approvers may not recognise.", screen: "Results", severity: "MEDIUM" as const, impact: "Users misread or skip columns, reducing trust in the data shown." },
  { id: "H3", name: "User Control & Freedom",                  finding: "Filter form has no Clear All or per-field reset. Approval queue has no prioritisation or triage.", screen: "Both",    severity: "HIGH" as const,   impact: "Friction for frequent users who re-enter the same filters daily." },
  { id: "H4", name: "Consistency & Standards",                 finding: "Mix of UI patterns. Status labels inconsistent across Process Flow vs table (e.g. \"Needs Approval\" vs \"Pending\").", screen: "Both",    severity: "MEDIUM" as const, impact: "Users must learn two mental models for the same state." },
  { id: "H5", name: "Error Prevention",                        finding: "Bulk selection + approve has no fraud-awareness confirmation. High-risk payments can be batch-approved silently.", screen: "Results", severity: "HIGH" as const,   impact: "Financial loss risk. One click can approve flagged AML transactions." },
  { id: "H6", name: "Recognition Over Recall",                 finding: "14 visible columns with no priority hierarchy — every row looks equally important.", screen: "Results", severity: "HIGH" as const,   impact: "Critical items (overdue, high-risk) are buried in 9,177 rows of uniform data." },
  { id: "H7", name: "Flexibility & Efficiency of Use",         finding: "No saved filter presets. No keyboard shortcut for Search. No multi-select within filters.", screen: "Filter",  severity: "MEDIUM" as const, impact: "High-frequency approvers waste time repeating filter setup every session." },
  { id: "H8", name: "Aesthetic & Minimalist Design",           finding: "Table shows 14 columns by default, forcing horizontal scroll. 9,177 rows with no visual hierarchy.", screen: "Results", severity: "HIGH" as const,   impact: "Cognitive overload. Every row competes for attention equally." },
  { id: "H9", name: "Help Users Recognise, Diagnose & Recover","finding": "\"AML Possible Matches\" appears as a static label — no score, no reason, no next action guidance.", screen: "Results", severity: "HIGH" as const,   impact: "Approvers don't know what triggered the flag or what to do." },
  { id: "H10",name: "Help & Documentation",                    finding: "No tooltips on column headers, no risk score explanation, no onboarding, no empty-state guidance.", screen: "Both",    severity: "LOW" as const,    impact: "Higher support load. New approver onboarding takes longer." },
];

const backlog = [
  { item: "Add Transaction Number as filter",                                                          screen: "Filter",  effort: "LOW EFFORT" as const, impact: "HIGH" as const,   note: "Direct customer request. Allows searching for a specific transaction instantly." },
  { item: "Need a refresh button",                                                                     screen: "Results", effort: "LOW EFFORT" as const, impact: "MEDIUM" as const, note: "Approvers work in real-time. Without refresh, data staleness causes full page reloads." },
  { item: "Ability to add/remove columns (model group). Inconsistency between statuses.",              screen: "Results", effort: "MED EFFORT" as const, impact: "HIGH" as const,   note: "Aligns with H6 & H8 — reduces 14-column overload. Status inconsistency is a separate bug." },
  { item: "Add bulk void button (like existing bulk View/Approve)",                                    screen: "Results", effort: "LOW EFFORT" as const, impact: "MEDIUM" as const, note: "Parity with existing bulk actions. Common workflow missing." },
  { item: "More robust filtering — allow multi filters, multi selection within one filter, add ACCOUNT TREE", screen: "Filter", effort: "HIGH EFFORT" as const, impact: "HIGH" as const, note: "Power user need. Account Tree is a commonly used hierarchy filter in other modules." },
  { item: "Filter by Legal Entity Company does not work — autopopulates ID but user must type name",   screen: "Filter",  effort: "LOW EFFORT" as const, impact: "HIGH" as const,   note: "Defect causing filter to fail silently. Blocker for multi-entity approvers." },
  { item: "Allow user to skip payment type review (free form, semi) after clicking \"Review & Approve\"", screen: "Results", effort: "MED EFFORT" as const, impact: "MEDIUM" as const, note: "Unnecessary confirmation step adds friction for low-risk payment types." },
];

const priority = [
  { rank: "P1",  finding: "No visual triage — 9,177 rows all look equal",        source: "Both",      severity: "HIGH" as const,   effort: "MED EFFORT" as const },
  { rank: "P2",  finding: "Fraud signals are labels without context or CTA",       source: "Heuristic", severity: "HIGH" as const,   effort: "MED EFFORT" as const },
  { rank: "P3",  finding: "Payment status is static — no lifecycle visibility",    source: "Heuristic", severity: "HIGH" as const,   effort: "LOW EFFORT" as const },
  { rank: "P4",  finding: "Approval queue has no prioritisation or triage",        source: "Heuristic", severity: "HIGH" as const,   effort: "MED EFFORT" as const },
  { rank: "P5",  finding: "No error prevention on bulk approval",                  source: "Heuristic", severity: "HIGH" as const,   effort: "MED EFFORT" as const },
  { rank: "P6",  finding: "14-column table causes cognitive overload",             source: "Both",      severity: "HIGH" as const,   effort: "MED EFFORT" as const },
  { rank: "P7",  finding: "Filter form has no clear/reset or quick-selects",       source: "Both",      severity: "MEDIUM" as const, effort: "LOW EFFORT" as const },
  { rank: "P8",  finding: "Technical column labels don't match user language",     source: "Heuristic", severity: "MEDIUM" as const, effort: "LOW EFFORT" as const },
  { rank: "P9",  finding: "No saved filter presets for power users",               source: "Both",      severity: "MEDIUM" as const, effort: "HIGH EFFORT" as const },
  { rank: "P10", finding: "No contextual help, tooltips, or onboarding",           source: "Heuristic", severity: "LOW" as const,    effort: "LOW EFFORT" as const },
];

const requirements = [
  { id: "REQ-01", title: "Triage queue widget — overdue, high-risk, error counts above table",      screen: "Results", severity: "HIGH" as const,   effort: "MED EFFORT" as const,  source: "H3, H6, H8",    isBug: false, requirement: "The results table must be preceded by a triage summary showing counts of: Overdue approvals, High-Risk payments (score >70), and Payments with Errors. Each count must be a clickable chip that filters the table to that segment.", designChange: "Add an action bar above the results table with three priority chips — Overdue (red), High Risk (amber), Errors (muted red). Clicking a chip applies a filter. Default table sort: overdue → high-risk → upcoming → routine." },
  { id: "REQ-02", title: "Inline fraud risk score with colour ring and flag reason on every row",    screen: "Results", severity: "HIGH" as const,   effort: "MED EFFORT" as const,  source: "H1, H9",        isBug: false, requirement: "Every transaction row must display a risk score (0–100) with a colour-coded indicator: green <30, amber 30–70, red >70. A flag reason must be visible as secondary text. The score must require no click to see.", designChange: "Replace the \"AML Possible Matches\" static label with an inline FraudBadge on each row. Shows numeric score, colour ring, and flag reason. A View Detail hover action links to the full fraud report." },
  { id: "REQ-03", title: "Status pipeline chip showing current and next stage per row",              screen: "Results", severity: "HIGH" as const,   effort: "LOW EFFORT" as const,  source: "H1, H2",        isBug: false, requirement: "The Status column must show both the current stage and the next expected stage in one inline chip. Format: \"Screened → Approved\". Blocked payments must show a warning indicator and the reason on the chip.", designChange: "Replace single-word status label with a pipeline chip using an arrow separator. Current stage highlighted in teal; next stage in muted text. Blocked payments get a red left border and warning icon." },
  { id: "REQ-04", title: "Bulk approval fraud-awareness gate for high-risk selections",             screen: "Results", severity: "HIGH" as const,   effort: "MED EFFORT" as const,  source: "H5",            isBug: false, requirement: "When bulk approval is triggered and any selected payment has risk score >70 or an active AML flag, a confirmation dialog must intercept. Dialog must state the count of flagged payments and offer: Review Flagged or Approve All Anyway (requires second confirmation click).", designChange: "Add a pre-approval check on bulk approve. Show a warning dialog with risk count, primary CTA \"Review Flagged\" (filters table to risky subset), and destructive \"Approve All Anyway\" requiring double-confirm." },
  { id: "REQ-05", title: "Reduce default columns from 14 to 7 with column picker",                  screen: "Results", severity: "HIGH" as const,   effort: "MED EFFORT" as const,  source: "H8, H6, Backlog",isBug: false, requirement: "The default results table must display exactly 7 columns with no horizontal scrolling. Users must be able to add or remove columns via a single-click picker. Selections persist for the session.", designChange: "Default: Reference | Payee | Amount | Status | Risk Score | Account Verified | Actions. Hide remaining 7 columns. Add a Columns button opening a popover with checkboxes. Selections apply immediately." },
  { id: "REQ-06", title: "Default sort by urgency — overdue first, then high-risk",                 screen: "Results", severity: "HIGH" as const,   effort: "MED EFFORT" as const,  source: "H6, H3",        isBug: false, requirement: "On page load the table must be sorted: (1) Overdue, (2) Risk score >70, (3) Upcoming deadline, (4) Everything else. A visible indicator must explain the sort. Users can override by clicking column headers.", designChange: "Apply urgency sort on initial render. Add caption: \"Sorted by urgency + risk — click a column to change.\" Overdue rows get a 2px red left border. Active sort column shows directional indicator." },
  { id: "REQ-07", title: "Filter: Clear All, per-field dismiss, date quick-selects, Trn# field",   screen: "Filter",  severity: "MEDIUM" as const, effort: "LOW EFFORT" as const,  source: "H3, H7, Backlog",isBug: false, requirement: "The filter form must include: a Clear All action resetting all fields in one click; a × dismiss on each populated field; date quick-select pills (Today, This Week, This Month, This Quarter); a Transaction Number field. Enter must trigger search.", designChange: "Add \"Clear All\" ghost button top-right of filter. Add × dismiss on each populated field. Add date pills under date picker. Add Transaction Number input. Wire Enter key to Search button." },
  { id: "REQ-08", title: "Plain-English column labels with tooltip on every header",                 screen: "Results", severity: "MEDIUM" as const, effort: "LOW EFFORT" as const,  source: "H2",            isBug: false, requirement: "All column headers must use complete plain-English names. No abbreviations visible in the default view. Every header must show a one-sentence tooltip on hover explaining the field.", designChange: "Rename: \"Paym Ref\" → \"Payment Reference\", \"Acct Verification\" → \"Account Verified?\", \"SWIFT Ref\" → \"SWIFT Reference\". Add tooltip to every column header. Copy-only change — no layout modifications." },
  { id: "REQ-09", title: "Saved filter presets with built-in defaults and save current",            screen: "Filter",  severity: "MEDIUM" as const, effort: "HIGH EFFORT" as const, source: "H7, Backlog",   isBug: false, requirement: "The filter form must include a Saved Searches mechanism. Two built-in presets: \"My Daily Queue\" (Pending, assigned to me, today) and \"Overdue Only\". Users must be able to save current filters with a custom name. Selecting a preset auto-triggers search.", designChange: "Add a Saved Searches dropdown at the top of the filter panel with 2 built-in presets and a \"+ Save Current\" option. Use localStorage for persistence in v1. Teal accent for the Save CTA." },
  { id: "REQ-10", title: "Manual refresh button with last-updated timestamp",                        screen: "Results", severity: "MEDIUM" as const, effort: "LOW EFFORT" as const,  source: "Backlog",       isBug: false, requirement: "The results table must provide a manual refresh action that re-fetches data without a full page reload. A timestamp must show when data was last loaded.", designChange: "Add a Refresh icon button in the table toolbar. Show a muted \"Last updated: HH:MM\" label. On click, re-trigger the data fetch and update the timestamp." },
  { id: "REQ-11", title: "Bulk void/reject action — parity with existing bulk approve",             screen: "Results", severity: "MEDIUM" as const, effort: "LOW EFFORT" as const,  source: "Backlog",       isBug: false, requirement: "Approvers must be able to void or reject multiple transactions in one action, matching existing bulk approve. A confirmation step must list the count of selected items before proceeding.", designChange: "Add \"Void Selected\" button to the bulk action bar. Style as destructive outline button. On click, show confirmation dialog: \"Void X payments?\" with Cancel and Confirm Void." },
  { id: "REQ-12", title: "Fix Legal Entity filter — entity name must auto-populate on selection",   screen: "Filter",  severity: "HIGH" as const,   effort: "LOW EFFORT" as const,  source: "Backlog",       isBug: true,  requirement: "The Legal Entity Company filter currently autopopulates only the entity ID. The entity name must also populate automatically. Users must not need to manually type the name after selecting from search results.", designChange: "Fix the search/select component to return and display entity name (not just ID) on selection. Update data binding to store both ID (for query) and name (for display). Regression test required." },
  { id: "REQ-13", title: "Multi-select filters and Account Tree filter",                            screen: "Filter",  severity: "HIGH" as const,   effort: "HIGH EFFORT" as const, source: "Backlog",       isBug: false, requirement: "Users must be able to select multiple values within a single filter field (e.g. multiple statuses, currencies). An Account Tree hierarchy filter must be added, consistent with other GTreasury modules.", designChange: "Replace applicable single-select dropdowns with multi-select checkboxes (Status, Currency, Inst Type). Add Account Tree filter using the existing GTreasury tree-select component. OR logic within a field." },
  { id: "REQ-14", title: "Skip redundant payment type review step for low-risk types",              screen: "Results", severity: "MEDIUM" as const, effort: "MED EFFORT" as const,  source: "Backlog",       isBug: false, requirement: "When a user clicks \"Review & Approve\" for free-form or semi-structured payment types, the current workflow presents an unnecessary intermediate confirmation screen. Users must have an option to bypass this step.", designChange: "Add a \"Don't show for [payment type]\" checkbox on the intermediate review screen. Persist the preference per payment type in user settings." },
  { id: "REQ-15", title: "Contextual help — risk score explainer, tooltips, helpful empty states", screen: "Both",    severity: "LOW" as const,    effort: "LOW EFFORT" as const,  source: "H10",           isBug: false, requirement: "New users must be able to understand risk score methodology, column meanings, and Process Flow stages without support. When filters return no results, a helpful empty state must appear with a Clear Filters CTA.", designChange: "Add a ? icon next to Risk Score opening a popover with scoring table (0–30 Low, 31–70 Med, 71–100 High). Add tooltips to all headers. Replace blank empty state with helpful message and Clear Filters button." },
];

const specs = [
  { rank: "P1",  severity: "HIGH" as const,   effort: "MED EFFORT" as const,  heuristic: "H6, H8", title: "Intelligent Approval Queue",         problem: "\"17 Overdue Approvals\" is a raw count with no queue ordering by urgency or risk, and no visual differentiation between overdue, upcoming, and high-risk payments. Approvers must scroll 9,177 rows to find what needs action.", solution: "Add an Action Required triage widget above the transaction table with 3 priority chips: Overdue (rose), High Risk (amber), Errors (rose-faded). Clicking a chip filters the table. Default sort: overdue → high-risk → upcoming → routine.", tokens: ["--status-high (rose) for overdue chip", "--status-med (amber) for high-risk chip", "shadcn Badge + Card", "Lucide AlertTriangle icon"], criteria: ["Triage widget visible on page load above the table", "Clicking each chip filters the table and highlights the active filter", "Default sort is by urgency then risk score descending"] },
  { rank: "P2",  severity: "HIGH" as const,   effort: "MED EFFORT" as const,  heuristic: "H1, H9", title: "Inline Fraud Signal — Risk Score + Reason", problem: "\"AML Possible Matches\" appears as a static text label in the Process Flow section. No score, no explanation of what triggered the flag, and no call to action. Approvers have no idea what to do next.", solution: "Replace the static AML label with an inline FraudBadge on every row. Badge shows risk score (0–100) with colour ring (green <30, amber 30–70, red >70), a flag reason, and a View Detail action on hover.", tokens: ["--status-high/med/low for risk tiers", "shadcn Tooltip + Badge", "Lucide ShieldAlert icon", "Colour ring: border-rose-500 / amber-400 / emerald-500"], criteria: ["Risk score visible on every row without any click", "Colour ring reflects correct tier", "Flag reason shown as secondary line below the score"] },
  { rank: "P3",  severity: "HIGH" as const,   effort: "LOW EFFORT" as const,  heuristic: "H1, H2", title: "Status Pipeline Chip",               problem: "The Status column shows a single word (\"Screened\", \"Approved\"). Users cannot see where a payment is in the 7-stage lifecycle, what comes next, what is blocking it, or how long it has been in the current state.", solution: "Replace the status label with a mini pipeline chip showing current step (highlighted in teal) and next step (muted). Format: \"Screened → Approved\". Blocked payments show a warning indicator and reason inline.", tokens: ["--accent-teal for current stage", "--text-secondary for next stage (muted)", "shadcn Badge with border-l-2 accent", "Lucide ArrowRight between stages"], criteria: ["Every row shows current + next stage in a single inline chip", "Blocked payments show a rose warning indicator", "Chip truncates gracefully on narrow viewports"] },
  { rank: "P4",  severity: "HIGH" as const,   effort: "MED EFFORT" as const,  heuristic: "H5",     title: "Bulk Approval Fraud-Awareness Gate",  problem: "Bulk selection + approve has no fraud-awareness step. Approvers can bulk-approve high-risk payments in one click, even if several have risk scores above 70 or active AML flags. No warning is shown.", solution: "When bulk approval is triggered and any selected payment has risk >70 or an AML flag, intercept with a Dialog: \"2 of 14 selected payments have elevated risk.\" Primary CTA: \"Review Flagged\". Secondary: \"Approve All Anyway\" (requires second click).", tokens: ["--status-high (rose) for dialog border", "shadcn Dialog + destructive Button", "Lucide ShieldAlert in dialog header", "shadcn AlertDescription for risk count"], criteria: ["Dialog appears when any selected payment is HIGH risk or has AML flag", "\"Review Flagged\" filters to risky subset without closing modal", "\"Approve All Anyway\" requires a second click before proceeding"] },
  { rank: "P5",  severity: "HIGH" as const,   effort: "MED EFFORT" as const,  heuristic: "H8, H6", title: "Column Reduction + Customiser",       problem: "The table shows 14 columns by default, forcing horizontal scrolling. Rarely used columns (SWIFT Ref, Template, Type) take identical visual weight to critical ones (Amount, Status, Risk). Approvers cannot customise what they see.", solution: "Default to 7 priority columns: Reference | Payee | Amount | Status | Risk Score | Account Verified | Actions. Add a column picker (Popover triggered by Columns button) listing all columns with checkboxes. Persists for session.", tokens: ["shadcn Popover + Checkbox for column picker", "--navy-mid for picker panel background", "Lucide Columns3 icon for toggle", "shadcn Button (outline, sm)"], criteria: ["Default view renders exactly 7 columns — no horizontal scroll", "Column picker accessible via single button click", "Column visibility applies immediately and persists for session"] },
  { rank: "P6",  severity: "HIGH" as const,   effort: "MED EFFORT" as const,  heuristic: "H6, H3", title: "Priority Sort & Default Triage",      problem: "The table has no default sorting logic. Urgent, overdue, and high-risk payments appear in the same order as routine transactions. No \"start here\" signal. Approvers have no context for where to focus.", solution: "Default sort: (1) Overdue, (2) High risk (>70), (3) Upcoming deadline, (4) Everything else. Show a sort indicator and callout: \"Sorted by urgency + risk — click any column to change.\" Column headers sortable.", tokens: ["Lucide ArrowUpDown for sortable columns", "--status-high left border on overdue rows", "Lucide ChevronUp/Down for active sort", "shadcn TableHead with sort state"], criteria: ["First rows on load are always overdue or high-risk", "Callout explains default sort order", "Clicking any column header changes sort — active column is visually indicated"] },
  { rank: "P7",  severity: "MEDIUM" as const, effort: "LOW EFFORT" as const,  heuristic: "H3",     title: "Filter Clear All + Date Quick-Selects", problem: "The filter form has no way to clear all filters at once. Each field must be individually cleared. Date fields have no quick-select options. No keyboard shortcut to trigger search. Re-entering filters every session is high-frequency friction.", solution: "Add a \"Clear All\" ghost button at top-right of the filter form. Add × dismiss on each populated field. Add date quick-select pills: Today | This Week | This Month | This Quarter. Enter triggers search from any filter field.", tokens: ["shadcn Button (ghost, sm) for Clear All", "--text-secondary for clear button", "shadcn Badge for date pills", "Lucide X for per-field dismiss"], criteria: ["\"Clear All\" resets all fields in one click", "Each populated field shows a × that clears only that field", "Date quick-select populates both From and To correctly"] },
  { rank: "P8",  severity: "MEDIUM" as const, effort: "LOW EFFORT" as const,  heuristic: "H2",     title: "Plain-Language Column Labels + Tooltips", problem: "Column headers use internal shorthand: \"Paym Ref\", \"Acct Verification\", \"SWIFT Ref\" — terms approvers, especially new ones, may not recognise. No explanatory tooltips exist.", solution: "Rename all column headers to plain English. Add a shadcn Tooltip to every header displaying a one-sentence explanation on hover. No technical jargon in the default view. Copy + config change only — lowest implementation cost.", tokens: ["shadcn Tooltip (delayDuration=400) on TableHead", "Lucide HelpCircle (w-3 h-3) after label", "No colour or layout changes — copy only"], criteria: ["All 7 default headers use complete plain-English names", "Hovering any header shows tooltip within 400ms", "Zero abbreviations visible without tooltip interaction"] },
  { rank: "P9",  severity: "MEDIUM" as const, effort: "HIGH EFFORT" as const, heuristic: "H7",     title: "Saved Filter Presets",               problem: "High-frequency approvers apply the same filter combination every session. No mechanism to save or recall a preset. No keyboard shortcut for search. Repetitive setup is a daily friction point.", solution: "Add a \"Saved Searches\" dropdown at the top of the filter form with 2 built-in presets (\"My Daily Queue\", \"Overdue Only\") and a \"+ Save Current\" option. Selecting a preset populates filters and auto-triggers search. Enter key triggers search.", tokens: ["shadcn Select + DropdownMenu for preset picker", "--accent-teal for Save CTA", "shadcn Input with onKeyDown Enter", "localStorage for persistence (no backend in v1)"], criteria: ["\"My Daily Queue\" populates filters and auto-triggers search in one click", "\"+ Save Current\" prompts for a name and saves state", "Enter key triggers search from any filter input"] },
  { rank: "P10", severity: "LOW" as const,    effort: "LOW EFFORT" as const,  heuristic: "H10",    title: "Contextual Tooltips + In-App Help",  problem: "New users have no guidance on column meanings, risk score calculation, Process Flow stages, or what to do when an AML flag appears. No empty-state guidance when filters return no results. Support load for CS is elevated.", solution: "Add shadcn Tooltip to all column headers. Add a ? icon next to Risk Score that opens a Popover explaining the GSmart scoring model (0–30 Low, 31–70 Med, 71–100 High). Improve empty state: show \"No payments match these filters\" with Clear All CTA.", tokens: ["shadcn Popover + Tooltip for help overlays", "Lucide HelpCircle (text-slate-500)", "shadcn Card for risk score panel", "Empty state: SearchX icon + muted text + ghost Button"], criteria: ["? next to Risk Score opens popover with scoring breakdown", "Empty state renders helpful message with Clear Filters action", "All help interactions keyboard-accessible (Tab + Enter / Esc)"] },
];

// ── Main Component ───────────────────────────────────────────────────────────
export default function ExportReport() {
  return (
    <div className="export-root">

      {/* Print button — hidden on print */}
      <div className="no-print print-bar">
        <div className="print-bar-inner">
          <div>
            <p className="print-bar-title">PAYM · Transaction Status Workflow — Full Report</p>
            <p className="print-bar-sub">Research findings · Customer feedback · Design requirements · Annotated specs</p>
          </div>
          <button onClick={() => window.print()} className="print-btn">
            <Printer className="w-4 h-4" /> Export PDF
          </button>
        </div>
      </div>

      {/* ── Cover ── */}
      <div className="print-page cover-page">
        <div className="cover-inner">
          <p className="cover-tag">GTreasury · Ripple Treasury Product Design</p>
          <h1 className="cover-title">Transaction Status Workflow</h1>
          <p className="cover-subtitle">UX Audit & Design Requirements</p>
          <div className="cover-meta">
            <span>February 2026</span>
            <span>·</span>
            <span>10 Heuristic Findings</span>
            <span>·</span>
            <span>7 Customer Requests</span>
            <span>·</span>
            <span>15 Design Requirements</span>
            <span>·</span>
            <span>10 Annotated Specs</span>
          </div>
          <div className="cover-toc">
            <p className="toc-label">Contents</p>
            <ol className="toc-list">
              <li>Section A — Heuristic Evaluation (H1–H10)</li>
              <li>Section B — Customer Backlog & Enhancement Requests</li>
              <li>Section C — Combined Priority List (P1–P10)</li>
              <li>Section D — Design Requirements & Changes (REQ-01–15)</li>
              <li>Section E — Annotated Design Specifications (P1–P10)</li>
            </ol>
          </div>
        </div>
      </div>

      {/* ── Section A: Heuristic Findings ── */}
      <div className="print-page">
        <div className="section-header">
          <span className="section-badge">A</span>
          <div>
            <h2 className="section-title">Heuristic Evaluation — H1 to H10</h2>
            <p className="section-sub">Nielsen's 10 usability heuristics applied to the Transaction Status Workflow. Severity rated by frequency × impact.</p>
          </div>
        </div>
        <table className="data-table">
          <thead>
            <tr>
              <th style={{width:"4%"}}>ID</th>
              <th style={{width:"18%"}}>Heuristic</th>
              <th style={{width:"32%"}}>Finding</th>
              <th style={{width:"8%"}}>Screen</th>
              <th style={{width:"10%"}}>Severity</th>
              <th>Impact</th>
            </tr>
          </thead>
          <tbody>
            {heuristics.map(h => (
              <tr key={h.id}>
                <td className="mono bold blue">{h.id}</td>
                <td className="bold">{h.name}</td>
                <td>{h.finding}</td>
                <td><span className="screen-chip">{h.screen}</span></td>
                <td><SevBadge level={h.severity} /></td>
                <td>{h.impact}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* ── Section B: Customer Backlog ── */}
      <div className="print-page">
        <div className="section-header">
          <span className="section-badge teal">B</span>
          <div>
            <h2 className="section-title">Customer Backlog — Enhancement Requests</h2>
            <p className="section-sub">7 items from the product backlog reported by GTreasury customers on the Transaction Status Workflow.</p>
          </div>
        </div>
        <table className="data-table">
          <thead>
            <tr>
              <th style={{width:"4%"}}>#</th>
              <th style={{width:"35%"}}>Enhancement Request</th>
              <th style={{width:"8%"}}>Screen</th>
              <th style={{width:"11%"}}>Effort</th>
              <th style={{width:"10%"}}>Impact</th>
              <th>Design Note</th>
            </tr>
          </thead>
          <tbody>
            {backlog.map((b, i) => (
              <tr key={i}>
                <td className="mono bold muted">{i + 1}</td>
                <td>{b.item}</td>
                <td><span className="screen-chip">{b.screen}</span></td>
                <td><EffortBadge level={b.effort} /></td>
                <td><SevBadge level={b.impact} /></td>
                <td>{b.note}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* ── Section C: Priority List ── */}
      <div className="print-page">
        <div className="section-header">
          <span className="section-badge purple">C</span>
          <div>
            <h2 className="section-title">Combined Priority List — P1 to P10</h2>
            <p className="section-sub">Heuristic and backlog findings consolidated and ranked by severity × feasibility.</p>
          </div>
        </div>
        <table className="data-table">
          <thead>
            <tr>
              <th style={{width:"6%"}}>Rank</th>
              <th>Finding</th>
              <th style={{width:"12%"}}>Source</th>
              <th style={{width:"11%"}}>Severity</th>
              <th style={{width:"13%"}}>Effort</th>
            </tr>
          </thead>
          <tbody>
            {priority.map(p => (
              <tr key={p.rank}>
                <td className="mono bold">{p.rank}</td>
                <td>{p.finding}</td>
                <td><span className="source-chip">{p.source}</span></td>
                <td><SevBadge level={p.severity} /></td>
                <td><EffortBadge level={p.effort} /></td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* ── Section D: Requirements ── */}
      <div className="print-page">
        <div className="section-header">
          <span className="section-badge orange">D</span>
          <div>
            <h2 className="section-title">Design Requirements & Changes — REQ-01 to REQ-15</h2>
            <p className="section-sub">15 functional requirements derived from the heuristic evaluation and customer feedback. Each maps to a screen, source finding, and concrete design change.</p>
          </div>
        </div>
        <div className="req-list">
          {requirements.map(req => (
            <div key={req.id} className="req-card avoid-break">
              <div className="req-header">
                <span className="req-id">{req.id}</span>
                <span className="screen-chip">{req.screen}</span>
                <SevBadge level={req.severity} />
                <EffortBadge level={req.effort} />
                {req.isBug && <span className="print-badge print-badge-high">⚠ DEFECT</span>}
                <span className="source-chip">{req.source}</span>
                <span className="req-title">{req.title}</span>
              </div>
              <div className="req-body">
                <div className="req-col">
                  <p className="col-label">Requirement</p>
                  <p className="col-text">{req.requirement}</p>
                </div>
                <div className="req-col">
                  <p className="col-label teal-label">Design Change</p>
                  <p className="col-text">{req.designChange}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* ── Section E: Annotated Specs ── */}
      <div className="print-page">
        <div className="section-header">
          <span className="section-badge teal">E</span>
          <div>
            <h2 className="section-title">Annotated Design Specifications — P1 to P10</h2>
            <p className="section-sub">10 prioritised recommendations each with a problem statement, proposed solution, design tokens, and testable acceptance criteria.</p>
          </div>
        </div>
        <div className="specs-list">
          {specs.map((s, i) => (
            <div key={s.rank} className={`spec-card avoid-break ${i < 6 ? "spec-high" : i < 9 ? "spec-med" : "spec-low"}`}>
              <div className="spec-header">
                <span className="spec-rank">{s.rank}</span>
                <SevBadge level={s.severity} />
                <EffortBadge level={s.effort} />
                <span className="heuristic-chip">{s.heuristic}</span>
                <span className="spec-title">{s.title}</span>
              </div>
              <div className="spec-body">
                <div className="spec-col">
                  <p className="col-label red-label">⚠ Problem — Current State</p>
                  <p className="col-text">{s.problem}</p>
                </div>
                <div className="spec-col">
                  <p className="col-label teal-label">→ Solution — Proposed Design</p>
                  <p className="col-text">{s.solution}</p>
                </div>
              </div>
              <div className="spec-footer">
                <div className="spec-col">
                  <p className="col-label">Design Tokens & Components</p>
                  <ul className="token-list">
                    {s.tokens.map((t, ti) => <li key={ti}>› {t}</li>)}
                  </ul>
                </div>
                <div className="spec-col">
                  <p className="col-label">Acceptance Criteria</p>
                  <ol className="criteria-list">
                    {s.criteria.map((c, ci) => <li key={ci}>{c}</li>)}
                  </ol>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Footer */}
      <div className="export-footer no-print">
        <p>PAYM — UX Audit & Design Report · Ripple Treasury Product Design · Feb 2026</p>
      </div>

    </div>
  );
}
