import { useState } from "react";
import { ChevronRight, ShieldAlert, Download, Search, X, AlertTriangle, CheckCircle2, Ban } from "lucide-react";
import { Link } from "wouter";
import AppNav from "@/components/AppNav";

// ── Types ─────────────────────────────────────────────────────────────────────
interface FlaggedTxn {
  id: string;
  date: string;
  payee: string;
  amount: string;
  rule: string;
  riskLevel: "high" | "medium" | "low";
  status: "flagged" | "overridden" | "blocked" | "cleared";
  details: string;
}

// ── Mock data ──────────────────────────────────────────────────────────────────
const FLAGGED_TXNS: FlaggedTxn[] = [
  {
    id: "TXN-88412",
    date: "2026-02-24",
    payee: "Apex Capital Pte. Ltd.",
    amount: "$1,250,000.00",
    rule: "High-Risk Country Filter",
    riskLevel: "high",
    status: "blocked",
    details: "Payment destination matched Singapore entity flagged under enhanced due diligence. Beneficiary bank in secondary watch-list jurisdiction.",
  },
  {
    id: "TXN-88308",
    date: "2026-02-23",
    payee: "Sunrise Distribution LLC",
    amount: "$47,500.00",
    rule: "First-Time Payee Check",
    riskLevel: "medium",
    status: "overridden",
    details: "First payment to new vendor. Approved by J. Harrington after manual verification of vendor registration documents.",
  },
  {
    id: "TXN-88201",
    date: "2026-02-23",
    payee: "Meridian Logistics GmbH",
    amount: "$830,000.00",
    rule: "Amount Outlier Detection",
    riskLevel: "high",
    status: "flagged",
    details: "Payment is 340% above 90-day average for this payee ($244K). Awaiting reviewer sign-off.",
  },
  {
    id: "TXN-88005",
    date: "2026-02-22",
    payee: "Consolidated Freight Inc.",
    amount: "$12,100.00",
    rule: "Duplicate Payment Detection",
    riskLevel: "medium",
    status: "blocked",
    details: "Exact duplicate of TXN-87892 processed on 2026-02-20 for same payee, amount, and reference number.",
  },
  {
    id: "TXN-87940",
    date: "2026-02-21",
    payee: "Pacific Trade Partners",
    amount: "$67,800.00",
    rule: "Velocity Check",
    riskLevel: "high",
    status: "flagged",
    details: "Entity submitted 14 transactions in a 6-hour window, exceeding the 10-transaction velocity limit. Total value: $1.2M.",
  },
  {
    id: "TXN-87712",
    date: "2026-02-20",
    payee: "Eastern Alliance Corp.",
    amount: "$5,400.00",
    rule: "Off-Hours Transaction Alert",
    riskLevel: "low",
    status: "cleared",
    details: "Transaction submitted at 02:34 CST. Reviewed and cleared — initiator confirmed scheduled batch processing.",
  },
  {
    id: "TXN-87508",
    date: "2026-02-19",
    payee: "Global Ventures SA",
    amount: "$380,000.00",
    rule: "High-Risk Country Filter",
    riskLevel: "high",
    status: "overridden",
    details: "Payment to Uruguay entity. Manual review confirmed legitimate trade relationship with active contract on file.",
  },
  {
    id: "TXN-87301",
    date: "2026-02-18",
    payee: "NorthStar Imports",
    amount: "$22,750.00",
    rule: "First-Time Payee Check",
    riskLevel: "low",
    status: "cleared",
    details: "New payee approved after vendor onboarding checklist completion. Three prior internal approvals confirmed.",
  },
];

// ── Helpers ───────────────────────────────────────────────────────────────────
const RISK_META = {
  high:   { color: "text-red-400",     bg: "bg-red-500/10",     ring: "ring-red-500/20",     label: "High"   },
  medium: { color: "text-amber-400",   bg: "bg-amber-500/10",   ring: "ring-amber-500/20",   label: "Medium" },
  low:    { color: "text-emerald-400", bg: "bg-emerald-500/10", ring: "ring-emerald-500/20", label: "Low"    },
};

const STATUS_META = {
  flagged:    { icon: AlertTriangle,  color: "text-amber-400",   bg: "bg-amber-500/10",   label: "Flagged"    },
  overridden: { icon: CheckCircle2,   color: "text-blue-400",    bg: "bg-blue-500/10",    label: "Overridden" },
  blocked:    { icon: Ban,            color: "text-red-400",     bg: "bg-red-500/10",     label: "Blocked"    },
  cleared:    { icon: CheckCircle2,   color: "text-emerald-400", bg: "bg-emerald-500/10", label: "Cleared"    },
};

const DEFAULT_FROM = "2026-02-18";
const DEFAULT_TO   = "2026-02-24";

// ── Row detail dialog ─────────────────────────────────────────────────────────
function TxnDetailDialog({ txn, onClose }: { txn: FlaggedTxn; onClose: () => void }) {
  const [overrideReason,  setOverrideReason]  = useState("");
  const [overrideSuccess, setOverrideSuccess] = useState(false);
  const canOverride = overrideReason.trim().length > 0;

  const riskMeta   = RISK_META[txn.riskLevel];
  const statusMeta = STATUS_META[txn.status];
  const StatusIcon = statusMeta.icon;

  const handleOverride = () => {
    if (!canOverride) return;
    setOverrideSuccess(true);
    setTimeout(() => onClose(), 1500);
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70"
      onClick={e => { if (e.target === e.currentTarget) onClose(); }}
    >
      <div className="w-full max-w-lg bg-[#0d1c30] rounded-2xl border border-[#1a3455] shadow-2xl overflow-hidden">
        {/* Dialog header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-[#1a3455]">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg bg-orange-500/10 flex items-center justify-center">
              <ShieldAlert className="w-4 h-4 text-orange-400" />
            </div>
            <div>
              <h2 className="text-sm font-bold text-white">{txn.id}</h2>
              <p className="text-[11px] text-slate-400">{txn.payee}</p>
            </div>
          </div>
          <button
            onClick={onClose}
            aria-label="Close"
            className="text-slate-500 hover:text-slate-300 transition-colors focus:outline-none focus:ring-1 focus:ring-orange-500/40 rounded"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Dialog body */}
        <div className="px-6 py-5 space-y-4">
          {/* Key facts */}
          <div className="grid grid-cols-2 gap-3">
            {[
              ["Transaction ID",  txn.id],
              ["Date",           txn.date],
              ["Amount",         txn.amount],
              ["Payee",          txn.payee],
            ].map(([label, value]) => (
              <div key={label}>
                <p className="text-[10px] text-slate-500 uppercase tracking-wider">{label}</p>
                <p className="text-xs font-semibold text-white mt-0.5">{value}</p>
              </div>
            ))}
          </div>

          {/* Rule + badges */}
          <div className="flex items-center gap-2 flex-wrap">
            <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded text-[10px] font-semibold ring-1 ${riskMeta.bg} ${riskMeta.color} ${riskMeta.ring}`}>
              {riskMeta.label} Risk
            </span>
            <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded text-[10px] font-semibold ring-1 ${statusMeta.bg} ${statusMeta.color}`}>
              <StatusIcon className="w-3 h-3" />
              {statusMeta.label}
            </span>
            <span className="text-xs text-slate-400">{txn.rule}</span>
          </div>

          {/* Details */}
          <div>
            <p className="text-[10px] text-slate-500 uppercase tracking-wider mb-1">Flag Details</p>
            <p className="text-xs text-slate-300 leading-relaxed bg-[#0a1628] rounded-lg p-3 border border-[#1a3455]">
              {txn.details}
            </p>
          </div>

          {/* Override reason (only for active flags/blocks) */}
          {(txn.status === "flagged" || txn.status === "blocked") && (
            <div>
              <label className="block text-[10px] text-slate-500 uppercase tracking-wider mb-1">
                Override / Action Reason <span className="text-red-400">*</span>
              </label>
              <textarea
                value={overrideReason}
                onChange={e => setOverrideReason(e.target.value)}
                placeholder="Provide justification for override or additional action…"
                rows={3}
                disabled={overrideSuccess}
                className="w-full bg-[#162a47] border border-[#1a3455] text-slate-300 text-xs rounded-lg px-3 py-2 resize-none focus:outline-none focus:ring-1 focus:ring-orange-500/40 placeholder:text-slate-600 disabled:opacity-50"
              />
              {!canOverride && !overrideSuccess && (
                <p className="text-[10px] text-slate-500 mt-1">
                  A reason is required before an override can be submitted.
                </p>
              )}
            </div>
          )}
        </div>

        {/* Dialog footer */}
        <div className="px-6 py-4 border-t border-[#1a3455] space-y-3">
          {overrideSuccess && (
            <div className="flex items-center gap-2 px-3 py-2 bg-emerald-500/10 border border-emerald-500/20 rounded-lg text-xs text-emerald-400">
              <CheckCircle2 className="w-3.5 h-3.5 shrink-0" />
              Override recorded — payment released for processing
            </div>
          )}
          <div className="flex justify-end gap-3">
            <button
              onClick={onClose}
              className="px-4 py-2 text-xs font-medium text-slate-400 hover:text-slate-200 transition-colors focus:outline-none focus:ring-1 focus:ring-orange-500/40 rounded-lg"
            >
              Close
            </button>
            {(txn.status === "flagged" || txn.status === "blocked") && !overrideSuccess && (
              <>
                <button
                  className="px-4 py-2 text-xs font-semibold bg-red-500/20 text-red-400 hover:bg-red-500/30 rounded-lg transition-colors focus:outline-none focus:ring-1 focus:ring-red-500/40"
                  onClick={onClose}
                >
                  Confirm Block
                </button>
                <button
                  disabled={!canOverride}
                  onClick={handleOverride}
                  className={`px-4 py-2 text-xs font-semibold rounded-lg transition-colors focus:outline-none ${
                    canOverride
                      ? "bg-orange-500 text-white hover:bg-orange-400 focus:ring-2 focus:ring-orange-500/50"
                      : "bg-orange-500/30 text-orange-300/50 cursor-not-allowed"
                  }`}
                >
                  Override & Allow
                </button>
              </>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

// ── Page ──────────────────────────────────────────────────────────────────────
export default function FraudReports() {
  const [fromDate,     setFromDate]     = useState(DEFAULT_FROM);
  const [toDate,       setToDate]       = useState(DEFAULT_TO);
  const [search,       setSearch]       = useState("");
  const [statusFilter, setStatusFilter] = useState<string>("all");
  const [riskFilter,   setRiskFilter]   = useState<string>("all");
  const [selected,     setSelected]     = useState<FlaggedTxn | null>(null);

  const setQuickRange = (days: number) => {
    const to   = new Date(2026, 1, 24); // Feb 24 2026
    const from = new Date(to);
    from.setDate(to.getDate() - days + 1);
    setToDate(to.toISOString().split("T")[0]);
    setFromDate(from.toISOString().split("T")[0]);
  };

  const hasActiveFilters =
    search || statusFilter !== "all" || riskFilter !== "all" ||
    fromDate !== DEFAULT_FROM || toDate !== DEFAULT_TO;

  const clearFilters = () => {
    setSearch(""); setStatusFilter("all"); setRiskFilter("all");
    setFromDate(DEFAULT_FROM); setToDate(DEFAULT_TO);
  };

  const filtered = FLAGGED_TXNS.filter(t => {
    if (statusFilter !== "all" && t.status !== statusFilter) return false;
    if (riskFilter   !== "all" && t.riskLevel !== riskFilter)   return false;
    if (fromDate && t.date < fromDate) return false;
    if (toDate   && t.date > toDate)   return false;
    if (search) {
      const q = search.toLowerCase();
      if (!t.id.toLowerCase().includes(q) && !t.payee.toLowerCase().includes(q) && !t.rule.toLowerCase().includes(q)) return false;
    }
    return true;
  });

  const counts = {
    flagged:    FLAGGED_TXNS.filter(t => t.status === "flagged").length,
    blocked:    FLAGGED_TXNS.filter(t => t.status === "blocked").length,
    overridden: FLAGGED_TXNS.filter(t => t.status === "overridden").length,
    cleared:    FLAGGED_TXNS.filter(t => t.status === "cleared").length,
  };

  return (
    <div className="min-h-screen flex flex-col bg-[#0f1e35] text-white">
      <AppNav />

      {/* Breadcrumb */}
      <nav aria-label="Breadcrumb" className="breadcrumb-bar bg-[#0d1c30] border-b border-[#1a3455] px-6 py-3 flex items-center gap-2 text-xs shrink-0">
        <Link href="/fraud-rules" className="text-white/50 font-medium hover:text-white/80 transition-colors">Anti Fraud</Link>
        <ChevronRight className="w-3 h-3 text-white/30" />
        <span className="text-white/50 font-medium">Setup</span>
        <ChevronRight className="w-3 h-3 text-white/30" />
        <span className="text-white/90 font-semibold" aria-current="page">Reports</span>
      </nav>

      <main id="main-content" className="flex-1 p-6 space-y-6 overflow-y-auto">
        {/* Page header */}
        <div className="flex items-center justify-between">
          <div>
            <div className="flex items-center gap-3 mb-1">
              <div className="w-8 h-8 rounded-lg bg-red-500/10 flex items-center justify-center">
                <ShieldAlert className="w-4 h-4 text-red-400" />
              </div>
              <h1 className="text-xl font-bold text-white tracking-tight">Audit Logs &amp; Reporting</h1>
            </div>
            <p className="text-xs text-slate-400 ml-11">
              Review flagged transactions, override decisions, and export audit trails.
            </p>
          </div>
          <button className="flex items-center gap-2 px-4 py-2 bg-[#162a47] border border-[#1a3455] text-slate-300 text-xs font-medium rounded-lg hover:border-slate-500 hover:text-white transition-all focus:outline-none focus:ring-2 focus:ring-orange-500/50">
            <Download className="w-3.5 h-3.5" />
            Export CSV
          </button>
        </div>

        {/* Summary KPI strip — click to quick-filter by status */}
        <div className="grid grid-cols-4 gap-3">
          {[
            { label: "Flagged",    status: "flagged",    count: counts.flagged,    color: "text-amber-400",   bg: "bg-amber-500/[0.14]",   border: "border-amber-500/30",   activeRing: "ring-amber-500/50"   },
            { label: "Blocked",    status: "blocked",    count: counts.blocked,    color: "text-red-400",     bg: "bg-red-500/[0.14]",     border: "border-red-500/30",     activeRing: "ring-red-500/50"     },
            { label: "Overridden", status: "overridden", count: counts.overridden, color: "text-blue-400",    bg: "bg-blue-500/[0.14]",    border: "border-blue-500/30",    activeRing: "ring-blue-500/50"    },
            { label: "Cleared",    status: "cleared",    count: counts.cleared,    color: "text-emerald-400", bg: "bg-emerald-500/[0.14]", border: "border-emerald-500/30", activeRing: "ring-emerald-500/50" },
          ].map(({ label, status, count, color, bg, border, activeRing }) => {
            const isActive = statusFilter === status;
            return (
              <button
                key={label}
                onClick={() => setStatusFilter(isActive ? "all" : status)}
                title={isActive ? `Clear ${label} filter` : `Show ${label} only`}
                className={`rounded-xl p-4 text-left w-full transition-all ${bg} border ${border} ${
                  isActive ? `ring-2 ${activeRing}` : "hover:ring-1 hover:ring-white/10"
                }`}
              >
                <p className="text-xs text-slate-400">{label}</p>
                <p className={`text-2xl font-bold mt-1 ${color}`}>{count}</p>
              </button>
            );
          })}
        </div>

        {/* Filters — date range + search + status/risk in one card */}
        <div className="bg-[#162a47] rounded-xl border border-[#1a3455] px-5 py-4 space-y-3">
          {/* Date range row */}
          <div className="flex items-center gap-3 flex-wrap">
            <span className="text-[10px] text-slate-500 uppercase tracking-wider font-medium w-12 shrink-0">Period</span>
            <input
              type="date"
              value={fromDate}
              onChange={e => setFromDate(e.target.value)}
              className="bg-[#0d1c30] border border-[#1a3455] text-slate-300 text-xs rounded-lg px-3 py-1.5 focus:outline-none focus:ring-1 focus:ring-orange-500/40"
            />
            <span className="text-slate-600 text-xs">→</span>
            <input
              type="date"
              value={toDate}
              onChange={e => setToDate(e.target.value)}
              className="bg-[#0d1c30] border border-[#1a3455] text-slate-300 text-xs rounded-lg px-3 py-1.5 focus:outline-none focus:ring-1 focus:ring-orange-500/40"
            />
            <div className="flex items-center gap-1.5 ml-1">
              {[7, 30, 90].map(days => (
                <button
                  key={days}
                  onClick={() => setQuickRange(days)}
                  className="px-2.5 py-1 bg-[#0d1c30] border border-[#1a3455] text-slate-400 hover:text-slate-200 hover:border-slate-500 text-xs rounded-lg transition-colors focus:outline-none focus:ring-1 focus:ring-orange-500/40"
                >
                  {days}d
                </button>
              ))}
            </div>
          </div>

          <div className="border-t border-[#1a3455]" />

          {/* Search + filters row */}
          <div className="flex items-center gap-3 flex-wrap">
            <div className="relative flex-1 min-w-[180px] max-w-xs">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-slate-500" />
              <input
                value={search}
                onChange={e => setSearch(e.target.value)}
                placeholder="Search ID, payee, or rule…"
                className="w-full bg-[#0d1c30] border border-[#1a3455] text-slate-300 text-xs rounded-lg pl-8 pr-3 py-1.5 focus:outline-none focus:ring-1 focus:ring-orange-500/40 placeholder:text-slate-600"
              />
            </div>
            <select
              value={statusFilter}
              onChange={e => setStatusFilter(e.target.value)}
              className="bg-[#0d1c30] border border-[#1a3455] text-slate-300 text-xs rounded-lg px-3 py-1.5 focus:outline-none focus:ring-1 focus:ring-orange-500/40"
            >
              <option value="all">All Statuses</option>
              <option value="flagged">Flagged</option>
              <option value="blocked">Blocked</option>
              <option value="overridden">Overridden</option>
              <option value="cleared">Cleared</option>
            </select>
            <select
              value={riskFilter}
              onChange={e => setRiskFilter(e.target.value)}
              className="bg-[#0d1c30] border border-[#1a3455] text-slate-300 text-xs rounded-lg px-3 py-1.5 focus:outline-none focus:ring-1 focus:ring-orange-500/40"
            >
              <option value="all">All Risk Levels</option>
              <option value="high">High Risk</option>
              <option value="medium">Medium Risk</option>
              <option value="low">Low Risk</option>
            </select>
            {hasActiveFilters && (
              <button
                onClick={clearFilters}
                className="flex items-center gap-1.5 px-2.5 py-1.5 text-xs text-slate-400 hover:text-slate-200 transition-colors focus:outline-none focus:ring-1 focus:ring-orange-500/40 rounded"
              >
                <X className="w-3 h-3" /> Clear
              </button>
            )}
            <span className="text-xs text-slate-500 ml-auto">
              {filtered.length} result{filtered.length !== 1 ? "s" : ""}
            </span>
          </div>
        </div>

        {/* Flagged transactions table */}
        <div className="rounded-xl border border-[#1a3455] overflow-hidden bg-[#0d1c30]">
          {/* Table header */}
          <div className="grid grid-cols-[100px_1fr_140px_110px_120px_100px] gap-4 px-5 py-3 bg-[#0a1628] border-b border-[#1a3455] text-[10px] font-bold uppercase tracking-wider text-slate-500">
            <span>Txn ID</span>
            <span>Payee</span>
            <span>Rule Triggered</span>
            <span className="text-right">Amount</span>
            <span>Risk Level</span>
            <span>Status</span>
          </div>

          {/* Rows */}
          {filtered.length === 0 ? (
            <div className="py-12 text-center">
              <ShieldAlert className="w-8 h-8 text-slate-600 mx-auto mb-2" />
              <p className="text-sm text-slate-500">No flagged transactions match your filters.</p>
            </div>
          ) : (
            filtered.map((txn, i) => {
              const riskMeta   = RISK_META[txn.riskLevel];
              const statusMeta = STATUS_META[txn.status];
              const StatusIcon = statusMeta.icon;
              return (
                <button
                  key={txn.id}
                  onClick={() => setSelected(txn)}
                  className={`w-full grid grid-cols-[100px_1fr_140px_110px_120px_100px] gap-4 px-5 py-3.5 text-left transition-colors hover:bg-[#162a47] focus:outline-none focus:bg-[#162a47] ${
                    i < filtered.length - 1 ? "border-b border-[#1a3455]" : ""
                  }`}
                >
                  <span className="text-xs font-mono text-orange-400 truncate">{txn.id}</span>
                  <div className="min-w-0">
                    <p className="text-xs font-medium text-white truncate">{txn.payee}</p>
                    <p className="text-[10px] text-slate-500 truncate">{txn.date}</p>
                  </div>
                  <span className="text-[11px] text-slate-300 truncate self-center">{txn.rule}</span>
                  <span className="text-xs font-semibold text-white tabular-nums text-right self-center">{txn.amount}</span>
                  <span className={`inline-flex items-center gap-1 self-center px-2 py-0.5 rounded text-[10px] font-semibold ring-1 w-fit ${riskMeta.bg} ${riskMeta.color} ${riskMeta.ring}`}>
                    {riskMeta.label}
                  </span>
                  <span className={`inline-flex items-center gap-1 self-center px-2 py-0.5 rounded text-[10px] font-semibold w-fit ${statusMeta.bg} ${statusMeta.color}`}>
                    <StatusIcon className="w-3 h-3" />
                    {statusMeta.label}
                  </span>
                </button>
              );
            })
          )}
        </div>

        <p className="text-[11px] text-slate-500 text-center">
          Showing {filtered.length} of {FLAGGED_TXNS.length} flagged transactions from {fromDate} to {toDate}
        </p>
      </main>

      <footer className="shrink-0 py-2 px-4 border-t border-slate-800/60 bg-[#0f1e35] flex items-center justify-between">
        <span className="text-[11px] text-slate-400">©2026 G TREASURY SS, LLC. All rights reserved · 26.1.0421</span>
        <span className="text-[11px] text-slate-400">Anti Fraud · Audit Logs · Feb 2026</span>
      </footer>

      {/* Row detail dialog */}
      {selected && (
        <TxnDetailDialog txn={selected} onClose={() => setSelected(null)} />
      )}
    </div>
  );
}
