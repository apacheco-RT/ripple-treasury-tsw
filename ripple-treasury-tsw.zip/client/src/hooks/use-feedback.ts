import { useMutation } from "@tanstack/react-query";
import { api } from "@shared/routes";
import { type InsertFeedback } from "@shared/schema";
import { useToast } from "@/hooks/use-toast";

export function useCreateFeedback() {
  const { toast } = useToast();

  return useMutation({
    mutationFn: async (data: InsertFeedback) => {
      const res = await fetch(api.feedback.create.path, {
        method: api.feedback.create.method,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data),
      });

      if (!res.ok) {
        const errorData = await res.json().catch(() => ({}));
        throw new Error(errorData.message || 'Failed to submit feedback');
      }

      return res.json();
    },
    onSuccess: () => {
      toast({
        title: "Feedback Received",
        description: "Thank you for your thoughts on the design strategy.",
      });
    },
    onError: (error) => {
      toast({
        title: "Submission Failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });
}
