# Ripple Treasury — TSW Prototype

## Overview
Interactive prototype for Ripple Treasury's Transaction Status Workflow (TSW) redesign. Includes heuristic evaluation, annotated specs, interactive prototype, fraud protection config, and audit logs.

## Tech Stack
- **Frontend**: React 18, Vite 7, Tailwind CSS 3, shadcn/ui, Framer Motion, Wouter (routing), TanStack Query
- **Backend**: Express 5, Node.js
- **Database**: PostgreSQL 16 via Drizzle ORM
- **Validation**: Zod (shared schemas)
- **Runtime**: tsx for TypeScript execution

## File Structure
- `client/src/` — React frontend
  - `pages/` — Route components (Landing, Prototype, Home, FraudRulesConfig, FraudReports, etc.)
  - `components/` — Reusable UI components + shadcn `ui/` folder
  - `hooks/` — Custom hooks (use-feedback, use-theme, use-toast)
  - `lib/` — Utilities (queryClient, design-tokens, utils)
- `server/` — Express backend (index.ts, routes.ts, storage.ts, db.ts, vite.ts, static.ts)
- `shared/` — Shared TypeScript (schema.ts, routes.ts)
- `attached_assets/` — Design documents

## Routes
- `/` — Landing page (Hub)
- `/research` — Research Report
- `/specs` — Annotated Specs
- `/prototype` — Interactive TSW Prototype
- `/strategy` — Design Strategy (Home)
- `/fraud-rules` — GSmart Fraud Rules Config
- `/fraud-reports` — Audit Logs & Reporting
- `/export` — Export Report (print-friendly)

## Development
- `npm run dev` — Start dev server on port 5000
- `npm run build` — Build for production
- `npm run db:push` — Sync Drizzle schema to database

## Database
Single table: `feedback` (id, name, email, message, isRead)
API endpoint: `POST /api/feedback`
